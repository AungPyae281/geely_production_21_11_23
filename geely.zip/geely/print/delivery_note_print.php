<!DOCTYPE html>
<?php include '../config/_globle.php'; ?>
<html>
<head>
	<meta charset="utf-8">
	<link rel="shortcut icon" type="image/x-icon" href="<?=$app_url;?>img/logo_sm.png" />
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>Geely</title>
	<meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
	<link rel="stylesheet" href="../plugins/bootstrap/bootstrap.min.css">
	<link rel="stylesheet" href="../plugins/fontawesome-free/css/all.min.css">
	<link rel="stylesheet" href="../plugins/icheck-bootstrap/icheck-bootstrap.min.css">	
	<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
	<style type="text/css">
	@media print and (color)
	{
		table { page-break-inside:auto }
		tr    { page-break-inside:avoid; page-break-after:auto }
		thead { display:table-header-group;}
		tfoot { display:table-footer-group }
	}
	@page {
        size: auto;
        margin: 0;
    }
    html, body {
        width: 183mm !important;
        height: 127mm !important;
        margin-left: 25px;
        margin-top: 5px;;
    }
    
	body{
		width: 100%;
        height: 100%;
		font-size: 12px;
		font-family: 'Century Gothic';
		font-weight: normal;
		/*color: red;*/
		/*padding: 20px;*/
		/*color-adjust: exact;  -webkit-print-color-adjust: exact; print-color-adjust: exact;*/
	}
	.page-header {
	    border-bottom: 1px solid #eee0 !important;
	} 
	.table, .table-bordered th, .table-bordered td, th, td{
		border-color: #000 !important;
	}

	th, td{
		line-height: 1.5 !important;
	}
	table{
		border: 2px solid #eee !important;
		border-collapse: collapse;
	}
</style>
</head>
<?php
$oc_no = "";
if(isset($_GET['oc_no'])){
	if(!empty($_GET['oc_no'])){
		$oc_no = $_GET['oc_no'];
	}
}
?>
<body>
	<div class="wrapper">
		<section>
			<div class="col-xs-12" style="padding-left:0px; padding-right: 0px;padding-top: 20px;padding-bottom: 9px;">
				<center>
					<h2 class="page-header" style="margin:0px;"> 
						<div style="margin-bottom:12px; font-size:22px; font-weight: bold;"><span style="color: #0070b7; font-weight: bold;">Premier Automotive Ltd.</span></div>
						<div style="margin-top:4px; font-size:12px; line-height:18px; font-weight: bold;">Yangon Office: No.3, 12 Ward, Insein Road, Hlaing Township, Yangon  </div>
						<div style="margin-top:4px; font-size:12px; line-height:18px; font-weight: bold;border-bottom: 2px solid red !important;">Mandalay Office: No.40,41,42,43,73 Street, Between 27th and 28th Street, Chan Aye Thar Zan Township, Mandalay</div>
						<div style="margin-top:6px; font-size:18px; font-weight: bold;"><span style="border-bottom: 4px double #000 !important;">Vehicle Delivery Form</span></div>
					</h2>
				</center> 
			</div>
			<div class="col-xs-12" style="padding-left:0px; padding-bottom:15px;padding-right: 0px;">
				<div class="col-xs-8" style="padding-left: 0px;">
					<table class="table" id="myTable1" style="margin-bottom:0px;border: 1px solid #000;">
						<thead>
							<tr>
								<td style="width: 25%;">Delivery To <span style="float:right;">:</span></td>
								<td  id="txtDeliveryTo"></td>
							</tr>
							<tr>
								<td style="width: 25%;">Phone No. <span style="float:right;">:</span></td>
								<td  id="txtPhoneNo"></td>
							</tr>
							<tr style="height: 45px;">
								<td style="width: 25%;">Address <span style="float:right;">:</span></td>
								<td id="txtAddress" style="line-height: 16px !important; padding-top: 4px;"></td>
							</tr>
						</thead>
						<tbody id="fbody">
						</tbody>
					</table>
				</div>
				<div class="col-xs-4" style="padding-left: 0px;">
					<table class="table" id="myTable2" style="margin-bottom:0px;border: 1px solid #000;">
						<thead>
							<tr>
								<td style="width: 37%;">Date <span style="float:right;">:</span></td>
								<td  id="txtDate"></td>
							</tr>
							<tr>
								<td style="width: 37%;">Order No.<span style="float:right;">:</span></td>
								<td  id="txtOrderNo"></td>
							</tr>
						</thead>
						<tbody id="fbody">
						</tbody>
					</table>
				</div>
			</div>
			<div class="col-xs-12" style="padding-left:0px; padding-bottom:15px;padding-right: 0px;">
				<table class="table table-bordered" id="myTable3" style="margin-bottom:0px;">
					<thead>
						<tr style="background-color: #ddd;">
						    <th style="font-size: 12px;text-align: center;" colspan="2">Product Description</th>
						</tr>
						<tr>
							<td style="width: 25%;">Model Name</td>
							<td id="txtModel"></td>
						</tr>
						<tr>
							<td style="width: 25%;">Grade</td>
							<td id="txtGrade"></td>
						</tr>
						<tr>
							<td style="width: 25%;">Engine</td>
							<td id="txtEngine"></td>
						</tr>
						<tr>
							<td style="width: 25%;">Colour(Ext/Int)</td>
							<td id="txtColourExtInt"></td>
						</tr>
						<tr>
							<td style="width: 25%;">Vin No.</td>
							<td id="txtVinNo"></td>
						</tr>
						<tr>
							<td style="width: 25%;">Registration No.</td>
							<td id="txtRegistrationNo"></td>
						</tr>
						<tr>
							<td style="width: 25%;">Invoice No.</td>
							<td id="txtInvoiceNo"></td>
						</tr>
						<tr>
							<td style="width: 25%;">Sales Person</td>
							<td id="txtSalesPerson"></td>
						</tr>
					</thead>
				</table>
			</div>
			<div class="col-xs-12" style="padding-left:0px; padding-right: 15px;">
				<p>We, Premier Automotive Ltd. informed you that the above described Geely vehicle has carefully been inspected and tested the quality and specification in accordance with the manu facturer's standard procedures of iinspection method. After overall inspection, we herewith delivered the car to <b id="txtDeliveryToName"></b> who duly accepted all process of inspection and received this car.</p>
			</div>
			<div class="col-xs-12" style="padding-left:0;padding-right:0;line-height:18px;">
				<div class="col-xs-3">	
					<div class="row">
						<div class="col-xs-10" style="text-align: center;">
							<img id="imgSESignature" src="<?=$app_url;?>img/transparent.png" style="height:140px; cursor:pointer;">
						</div>
					</div>
					<div class="row" style="padding-left: 25px;">
						<div class="col-xs-8" style="text-align:center;border-top:1px solid black;padding-left: 0px;padding-right: 0px;">Delivered by (Sales Executive)</div>
					</div>
				</div>
				<div class="col-xs-3">	
					<div class="row">
						<div class="col-xs-10" style="text-align: center;">
							<img id="imgSMSignature" src="<?=$app_url;?>img/transparent.png" style="height:140px; cursor:pointer;">
						</div>
					</div>
					<div class="row" style="padding-left: 25px;">
						<div class="col-xs-8" style="text-align:center;border-top:1px solid black;padding-left: 0px;padding-right: 0px;">Checked by (Sales Manager)</div>
					</div>
				</div>
				<div class="col-xs-3" style="padding-right: 0px;">
					<div class="row">
						<div class="col-xs-10" style="text-align: center;">
							<img id="imgFMSignature" src="<?=$app_url;?>img/transparent.png" style="height:140px; cursor:pointer;">
						</div>
					</div>
					<div class="row" style="padding-left: 25px;">
						<div class="col-xs-8" style="text-align:center;border-top:1px solid black;padding-left: 0px;padding-right: 0px;">Approved by (Finance Manager)</div>
					</div>
				</div>
				<div class="col-xs-3" style="padding-right: 0px;">
					<div class="row">
						<div class="col-xs-10" style="text-align: center;">
							<img id="imgCustomerSignature" src="<?=$app_url;?>img/transparent.png" style="height:140px; cursor:pointer;">
						</div>
					</div>
					<div class="row" style="padding-left: 25px;">
						<div class="col-xs-8" style="text-align:center;border-top:1px solid black;padding-left: 0px;padding-right: 0px;">Received by</div>
					</div>
					<div class="row">
						<div class="col-xs-5" style="padding-left:0;padding-right:0;">Customer:</div>
						<div class="col-xs-7" style="padding-left:0; padding-right:0;"><p style="border-bottom: 1px solid #000; height: 19px;" id="txtCustomerName"></p></div>
					</div>
					<div class="row">
						<div class="col-xs-5" style="padding-left:0;padding-right:0;">NRC No.:</div>
						<div class="col-xs-7" style="padding-left:0; padding-right:0;"><p style="border-bottom: 1px solid #000; height: 19px;" id="txtCustomerNRCNo"></p></div>
					</div>
					<div class="row">
						<div class="col-xs-5" style="padding-left:0;padding-right:0;">Phone No.:</div>
						<div class="col-xs-7" style="padding-left:0; padding-right:0;"><p style="border-bottom: 1px solid #000; height: 19px;" id="txtCustomerPhoneNo"></p></div>
					</div>
				</div>
			</div>
		</section>
	</div>
	<div style="page-break-before: always;"></div>
</body>
<script src="../plugins/jquery/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.10.1/html2pdf.bundle.min.js" integrity="sha512-GsLlZN/3F2ErC5ifS5QtgpiJtWd43JWSuIgh7mbzZ8zBps+dvLusV+eNQATqgA/HdeKFVgA5v3S/cIrLF7QnIg==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
</html>	

<script type="text/javascript">
	var APP_URL = '<?=$app_url;?>';
	var oc_no = "<?=$oc_no;?>";
	$(function(){ 
		if(oc_no){
			getOnePrint();
		}
	});

	function getOnePrint(){
		$("#myTable").find("tbody").find("tr").remove();
		$.ajax({
			url: APP_URL + "api/sales/delivery_note/get_one_delivery_note.php",
			type: "POST",
			data: JSON.stringify({ oc_no: oc_no })
		}).done(function(data) {	
			$("#txtDate").text(data.date);
			$("#txtDeliveryTo").text(data.delivery_to);
			$("#txtPhoneNo").text(data.phone_no);
			$("#txtAddress").text(data.address);
			$("#txtOrderNo").text(data.oc_no);
			$("#txtModel").text(data.model);
			$("#txtGrade").text(data.grade);
			$("#txtEngine").text(data.engine);
			$("#txtColourExtInt").text(data.colour_ext_int);
			$("#txtVinNo").text(data.vin_no);
			$("#txtRegistrationNo").text(data.registration_no);
			$("#txtInvoiceNo").text(data.invoice_no);
			$("#txtSalesPerson").text(data.sales_person);

			$("#txtDeliveryToName").text(data.delivery_to);

			if(data.name){
				$("#txtCustomerName").text(data.name);
			}

			if(data.nrc_no){
				$("#txtCustomerNRCNo").text(data.nrc_no);
			}

			if(data.phone_no){
				$("#txtCustomerPhoneNo").text(data.phone_no);
			}

			if(data.se_sig && ImageExist(data.se_sig)) $("#imgSESignature").attr('src', data.se_sig + "?d=" + Math.random()); 
			if(data.cust_sig && ImageExist(data.cust_sig)) $("#imgCustomerSignature").attr('src', data.cust_sig + "?d=" + Math.random()); 
			window.print();
		});
	} 

	function ImageExist(url){
		var img = new Image();
		img.src = url;
		return img.height != 0;
	}
</script>
