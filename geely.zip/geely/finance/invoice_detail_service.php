<?php include '../header.php'; ?>
<?php
	$id = "";
	if(isset($_GET['id'])){
		if(!empty($_GET['id'])){
			$id = $_GET['id'];
		}
	}
?>
<style>
	.form-group{
		font-size: 13px !important;
		margin-bottom: 6px !important;
	}

	.col-form-label {
		padding-top: calc(0.20rem + 1px);
		padding-bottom: calc(0.375rem + 1px);
		margin-bottom: 0;
		font-size: 13px;
		line-height: 1.2;
	}

	.form-control:disabled {
		background-color: #f8f8f9;
	}

	.form-control {
		display: block;
		width: 100%;
		height: calc(1.11rem + 11px);
		padding: 0.375rem 0.75rem;
		font-size: 0.9rem;
		font-weight: 400;
		line-height: 1.2;
		color: #495057;
		background-color: #ffffff;
		background-clip: padding-box;
		border: 1px solid #ced4da;
		border-radius: 0.25rem;
		box-shadow: inset 0 0 0 rgba(0, 0, 0, 0);
		transition: border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out;
	}

	.card-header {
		background-color: transparent;
		border-bottom: 1px solid rgba(0, 0, 0, 0.125);
		position: relative;
		padding: 0.35rem 1.10rem;
		border-top-left-radius: 0.25rem;
		border-top-right-radius: 0.25rem;
	}

	.btn{
		font-size: 13px;
		line-height: 1.4;
	}

	.table th, .table td {
		padding: 0.40rem;
	}

	.badge{
		padding: 5px 12px;
		font-size: 11px;
		margin-right: 3px;
	}

	select{
		padding-top: 1px !important;
	}
</style>
<div class="content-wrapper" style="min-height: 1203.6px;"> 
	<section class="content-header">
		<div class="container-fluid">
			<div class="row mb-2">
				<div class="col-md-6">
					<h1>Invoice Detail</h1>
				</div>
				<div class="col-md-6"></div>
			</div>
		</div>
	</section>
	<section class="content">
		<div class="container-fluid">
			<div class="row">
				<div class="col-md-12">
					<div class="card card-outline card-primary">
						<div class="card-header">
							<button type="button" class="btn btn-primary" style="height: 33px; line-height: 0px; font-weight: bold; font-size: 16px; min-width: 65px; background-color: #fff; color: #000; border-color: #007bff;" id="btnGoBack" onclick="goToInvoices();"><i class="fas fa-arrow-left" style="margin-right: 6px;"></i> Go Back</button>
							<button type="button" class="btn btn-success" style="float: right; font-weight: bold;" onclick="goToPayment();" id="btnPayment">Add Payment</button>
						</div>
						<div class="card-body">	
							<div class="row">
								<div class="col-md-6">
									<div class="form-group row">
										<label class="col-md-4 col-form-label" style="text-align: right;">Invoice Date: </label>
										<div class="col-md-8">
											<input class="form-control" id="txtInvoiceDate" value="" disabled>
										</div>
									</div>
								</div>	
								<div class="col-md-6">
									<div class="form-group row">
										<label class="col-md-4 col-form-label" style="text-align: right;">Due Date/Time: </label>
										<div class="col-md-8">
											<input class="form-control" id="txtPaymentDueDateTime" value="" disabled>
										</div>
									</div>
								</div>	
							</div>

							<hr>

							<div class="row">
								<div class="col-md-6">
									<div class="form-group row">
										<label class="col-md-4 col-form-label" style="text-align: right;">Service Center: </label>
										<div class="col-md-8">
											<input class="form-control" id="txtServiceCenter" value="" disabled>
										</div>
									</div>
									<div class="form-group row">
										<label class="col-md-4 col-form-label" style="text-align: right;">Registration No.: </label>
										<div class="col-md-8">
											<input class="form-control" id="txtServiceRegistrationNo" value="" disabled>
										</div>
									</div>
									<div class="form-group row">
										<label class="col-md-4 col-form-label" style="text-align: right;">Owner Name: </label>
										<div class="col-md-8">
											<input class="form-control" id="txtOwnerName" value="" disabled>
										</div>
									</div>
									<div class="form-group row">
										<label class="col-md-4 col-form-label" style="text-align: right;">Owner Phone: </label>
										<div class="col-md-8">
											<input class="form-control" id="txtOwnerPhone" value="" disabled>
										</div>
									</div>
									<div class="form-group row">
										<label class="col-md-4 col-form-label" style="text-align: right;">Appt. Contact Person: </label>
										<div class="col-md-8">
											<input class="form-control" id="txtApptContactPerson" value="" disabled>
										</div>
									</div>
									<div class="form-group row">
										<label class="col-md-4 col-form-label" style="text-align: right;">Appt. Contact Phone: </label>
										<div class="col-md-8">
											<input class="form-control" id="txtApptContactPhone" value="" disabled>
										</div>
									</div>
									<div class="form-group row">
										<label class="col-md-4 col-form-label" style="text-align: right;">Service Contact Person: </label>
										<div class="col-md-8">
											<input class="form-control" id="txtServiceContactPerson" value="" disabled>
										</div>
									</div>
									<div class="form-group row">
										<label class="col-md-4 col-form-label" style="text-align: right;">Service Contact Phone: </label>
										<div class="col-md-8">
											<input class="form-control" id="txtServiceContactPhone" value="" disabled>
										</div>
									</div>
								</div>
								<div class="col-md-6">
									<div class="form-group row">
										<label class="col-md-4 col-form-label" style="text-align: right;">Plate No.: </label>
										<div class="col-md-8">
											<input class="form-control" id="txtPlateNo" value="" disabled>
										</div>
									</div>
									<div class="form-group row">
										<label class="col-md-4 col-form-label" style="text-align: right;">Model Name: </label>
										<div class="col-md-8">
											<input class="form-control" id="txtModelName" value="" disabled>
										</div>
									</div>
									<div class="form-group row">
										<label class="col-md-4 col-form-label" style="text-align: right;">Vin No.: </label>
										<div class="col-md-8">
											<input class="form-control" id="txtVinNo" value="" disabled>
										</div>
									</div>
									<div class="form-group row" style="display:none;">
										<label class="col-md-4 col-form-label" style="text-align: right;">Valid Warranty: </label>
										<div class="col-md-8" id="ValidWarranty"></div>
									</div>
									<div class="form-group row">
										<label class="col-md-4 col-form-label" style="text-align: right;">Main Technician: </label>
										<div class="col-md-8">
											<input class="form-control" id="txtMainTechnician" value="" disabled>
										</div>
									</div>
									<div class="form-group row">
										<label class="col-md-4 col-form-label" style="text-align: right;">Visit Type: </label>
										<div class="col-md-8">
											<input class="form-control" id="txtVisitType" value="" disabled>
										</div>
									</div>
									<div class="form-group row">
										<label class="col-md-4 col-form-label" style="text-align: right;">Promotion: </label>
										<div class="col-md-8">
											<input class="form-control" id="txtServicePromotion" value="" disabled>
										</div>
									</div>
									<div class="form-group row">
										<label class="col-md-4 col-form-label" style="text-align: right;">SA Name: </label>
										<div class="col-md-8">
											<input class="form-control" id="txtSA" value="" disabled>
										</div>
									</div>
								</div>
							</div> 

							<div class="card-body p-0" style="max-height:250px; overflow-y: auto; margin-top: 20px;">
								<table class="table table-bordered" id="myTableServiceItem">
									<thead>                  
										<tr> 
											<th style="width: 15%">Service Type</th>
											<th style="width: 15%">Package Name</th>
											<th style="width: 15%">Code</th>
											<th>Name</th>
											<th style="width: 15%">Waiting Time</th>
											<th style="width: 15%">Price</th>
											<th style="width: 10%">Warranty</th>
										</tr>
									</thead>
									<tbody></tbody>
								</table>
							</div>

							<div class="card-body p-0" style="max-height:192px; overflow-y: auto; margin-top: 40px; margin-bottom: 20px;">
								<table class="table table-bordered" id="myTableSparepart">
									<thead>                  
										<tr> 
											<th style="width: 12%;">Code</th>
											<th>Name</th>
											<th style="width: 10%">Warranty</th> 
											<th style="width: 15%">Price</th>
											<th style="width: 9%">Quantity</th>
											<th style="width: 15%">Amount</th>
										</tr>
									</thead>
									<tbody></tbody>
								</table>
							</div>

							<div class="row" style="padding-top:9px;"> 
								<div class="col-md-4"></div>
								<div class="col-md-4">
									<div class="form-group row">
										<label class="col-md-4 col-form-label" style="text-align: right;">Total Waiting Time: </label>
										<div class="col-md-8">
											<input type="text" class="form-control" id="txtTotalWaitingTime" value="" disabled>
										</div>
									</div>
									<div class="form-group row" style="margin-bottom: 3px !important;">
										<label class="col-md-4 col-form-label" style="text-align: right;">Remark: </label>
										<div class="col-md-8">
											<textarea class="form-control" id="txtServiceRemark" rows="2" disabled></textarea>
										</div>
									</div>
									<div class="form-group row">
										<label class="col-md-4 col-form-label" style="text-align: right; padding-top: 7px;">Test Drive Agree:</label>
										<div class="col-md-8 icheck-success d-inline">
											<input id="chkTestDriveAgree" type="checkbox" disabled>
											<label for="chkTestDriveAgree"></label>
										</div>
									</div>
								</div>
								<div class="col-md-4">
									<div class="form-group row">
										<label class="col-md-4 col-form-label" style="text-align: right;">Total Amount: </label>
										<div class="col-md-8">
											<input type="text" class="form-control" id="txtTotalAmount" value="0" style="text-align:right;" disabled>
										</div>
									</div>
									<div class="form-group row">
										<label class="col-md-4 col-form-label" style="text-align: right;">Discount: </label>
										<div class="col-md-8">
											<input type="text" class="form-control" id="txtDiscount" value="0" style="text-align:right;" disabled>
										</div>
									</div>
									<div class="form-group row">
										<label class="col-md-4 col-form-label" style="text-align: right;">Net Amount: </label>
										<div class="col-md-8">
											<input type="text" class="form-control" id="txtNetAmount" value="0" style="text-align:right;" disabled>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div> 


					<center>
						<div class="modal fade" id="myModalPayment">
							<div class="modal-dialog" style="max-width: 100% !important;">
								<div class="modal-content" style="width: 580px; top: 29px;">
									<div class="modal-header" style="padding: 12px;">
										<h4 class="modal-title" style="font-weight: bold;">Payment - Entry</h4>
										<button type="button" class="close" data-dismiss="modal" aria-label="Close">
											<span aria-hidden="true">&times;</span>
										</button>
									</div>
									<div class="modal-body">
										<form role="form" id="frmEntry">
											<div class="row">
												<div class="col-md-12">
													<div class="form-group row">
														<label class="col-md-4 col-form-label" style="text-align: right;">Date: </label>
														<div class="col-md-7">  
															<div class="input-group input-append date" id="datePicker" data-date="2020-02-04" data-date-format="yyyy-mm-dd">
																<div class="input-group-prepend">
																	<span class="input-group-addon input-group-text" style="width: 40px; display: table-cell;">
																		<i class="far fa-calendar-alt"></i>
																	</span>
																</div>
																<input type="text" class="form-control float-right" id="txtDatePicker" value="1982-06-15" readonly>
															</div>
														</div>
														<div class="col-md-1"></div>
													</div>
													<div class="form-group row">
														<label class="col-md-4 col-form-label" style="text-align: right;">G/L Code: </label>
														<div class="col-md-7">
															<select class="form-control" id="cboGLCode"></select>
														</div>
														<div class="col-md-1"></div>
													</div>
													<div class="form-group row">
														<label class="col-md-4 col-form-label" style="text-align: right;">Account: </label>
														<div class="col-md-7">
															<select class="form-control" id="cboBankCashAccount"></select>
														</div>
														<div class="col-md-1"></div>
													</div>
													<div class="form-group row">
														<label class="col-md-4 col-form-label" style="text-align: right;">Amount: </label>
														<div class="col-md-7">
															<input type="text" class="form-control" id="txtPayAmount" value="0" style="text-align:right;" disabled>
														</div> 
														<div class="col-md-1"></div>
													</div>
													<div class="form-group row">
														<label class="col-md-4 col-form-label" style="text-align: right;">Paid By: </label>
														<div class="col-md-7">
															<input type="text" class="form-control" id="txtPaidBy">
														</div>
														<div class="col-md-1"></div>
													</div>
													<div class="form-group row">
														<label class="col-md-4 col-form-label" style="text-align: right;">Description:</label>
														<div class="col-md-7">
															<textarea class="form-control" id="txtDescription" rows="2"></textarea>
														</div>
														<div class="col-md-1"></div>
													</div>
													<div class="form-group row">
														<label class="col-md-4 control-label" style="text-align: right;">Upload Receipt:</label>
														<div class="col-md-7" style="text-align: left;">
															<input style="display:none" name="file" id="input-image-hidden" onchange="document.getElementById('previewing').src = window.URL.createObjectURL(this.files[0])" type="file" accept="image/jpeg, image/png" >
															<img id="previewing" name="previewing" src="<?=$app_url;?>img/no_image.jpg" style="height:133px; width:auto;cursor:pointer;"onclick="HandleBrowseClick('input-image-hidden');" title="Click to Change the Photo."> 
														</div>
														<div class="col-md-1"></div>
													</div>
													<div class="form-group row">
														<div class="col-md-4"></div>
														<div class="col-md-7" style="text-align: left;">
															<button type="button" class="btn btn-success" style="min-width: 140px;" id="btnSubmit">Make Payment</button>
														</div>
														<div class="col-md-1"></div>
													</div>
												</div>
											</div>
										</form>
									</div>
								</div>
							</div>
						</div>
					</center>
				</div>
			</div>
		</div>
	</section>
</div>
<?php include '../footer.php'; ?>
<script>
    var id = '<?= $id ?>';
	var d = new Date();
	var mm = (d.getMonth("MM") + 1);
	var dd = d.getDate();
	var yyyy = d.getFullYear();
	var customDate = d.getFullYear() + "-" + ((mm<10)?"0" + mm:mm) + "-" +  ((dd<10)?"0" + dd:dd);
	$('#datePicker').attr("data-date",customDate);
	$("#txtDatePicker").val(customDate);

	$(function() {
		$("body").addClass("sidebar-collapse"); 
		$('#datePicker').datepicker();
        getAllGLCode();
        getAllBankAndCashAccount();
		getOneService();
	}); 

	function getAllGLCode(){
        $("#cboGLCode").find("option").remove();
        $("#cboGLCode").append("<option value=''></option>");
        $.ajax({
            url: APP_URL + "api/finance/gl_account/get_all_rows.php",
            type: "POST",
            data: JSON.stringify({ category: 'Customer' })
        }).done(function(data) {
            $.each(data.records, function(i, v) {
            	if(v.name=="Payment"){
               		$("#cboGLCode").append("<option value='" + v.gl_code + "' selected>" + v.gl_code + " (" + v.name + ")</option>");
            	}
            });
        });
    }

    function getAllBankAndCashAccount(){ 
        $("#cboBankCashAccount").find("option").remove();
        $("#cboBankCashAccount").append("<option value=''></option>");

        $.ajax({
            url: APP_URL + "api/finance/bank_account/get_all_bank_and_cash_account.php"
        }).done(function(data) {
            $.each(data.records, function(i, v) {
                $("#cboBankCashAccount").append("<option value = '" + v.gl_code + "'>" + v.gl_code + " (" + v.name + ")</option>");
            });
        });
    }

	function getOneService(){
		$("#ValidWarranty").empty();
		$.ajax({
			url: APP_URL + "api/service/service/get_one_service_invoice.php",
			type: "POST",
			data: JSON.stringify({ id: id })
		}).done(function(data) {
			$("#txtInvoiceDate").val(data.invoice_date);
			$("#txtPaymentDueDateTime").val(data.payment_due_date_time);

			$("#txtServiceCenter").val(data.service_center);
			$("#txtServiceRegistrationNo").val(data.registration_no);
			$("#txtOwnerName").val(data.owner_name);
			$("#txtOwnerPhone").val(data.owner_phone);
			$("#txtApptContactPerson").val(data.appt_contact_person);
			$("#txtApptContactPhone").val(data.appt_contact_phone);
			$("#txtServiceContactPerson").val(data.contact_person);
			$("#txtServiceContactPhone").val(data.contact_phone);

			$("#txtPaidBy").val(data.contact_person);

			$("#txtPlateNo").val(data.plate_no);
			$("#txtModelName").val(data.model);
			$("#txtVinNo").val(data.vin_no);
			$("#txtMainTechnician").val(data.main_technician_name);
			$("#txtVisitType").val(data.visit_type);
			$("#txtServicePromotion").val(data.promotion);
			$("#txtSA").val(data.sa_name);

			if(data.valid_warranty.length>0){
				$("#ValidWarranty").parent().css("display", "");
				$.each(data.valid_warranty, function(i, v){
					$("#ValidWarranty").append('<span class="badge bg-primary">' + v + '</span>');
				});
			}else{
				$("#ValidWarranty").parent().css("display", "none");
			}

			var package_id = 0;
			var x = 1;
			$.each(data.service_items, function(i, v) {
				if(v.service_type=="Package"){
					$("#myTableServiceItem").find("tbody")
					.append($('<tr class="svpk' + v.package_id + '" data-service-type="' + v.service_type + '" data-package-name="' + v.package_name + '" data-item-code="' + v.item_code + '" data-item-name="' + v.item_name + '" data-item-wt="' + v.item_wt + '" data-item-price="0" data-package-price="' + v.package_price + '" data-technician-id="' + v.technician_id + '" data-bay-no="' + v.bay_no + '" data-start-time="' + v.start_time + '" data-end-time="' + v.end_time + '" data-warranty="' + v.warranty + '">')
						.append((package_id!=v.package_id)?("<td rowspan='' class='package" + v.package_id + "' style='vertical-align: middle;'>" + v.service_type + "</td>"):"")
						.append((package_id!=v.package_id)?("<td rowspan='' class='package" + v.package_id + "' style='vertical-align: middle;'>" + v.package_name + "</td>"):"")
						.append("<td style='padding: 0.40rem !important;'>" + v.item_code + "</td>")
						.append("<td style='padding: 0.40rem !important;'>" + v.item_name + "</td>")
						.append("<td style='padding: 0.40rem !important;'>" + v.item_wt + "</td>")
						.append((package_id!=v.package_id)?("<td rowspan='' class='package" + v.package_id + "' style='text-align:right; padding-right: 20px; vertical-align: middle;'>" + v.package_price + "</td>"):"")
						.append("<td>" + ((v.warranty==1)?"Yes":"No") + "</td>")
					);
					if(v.package_id==package_id){
						++x;
						$("#myTableServiceItem .package" + package_id).attr("rowspan", x);
					}else{
						x = 1;
					}
					if(v.technician_id!=0){
						$(".btn" + v.package_id).remove();
					}
					package_id = v.package_id;
				}else{
					$("#myTableServiceItem").find("tbody")
					.append($('<tr class="svpk' + v.package_id + '" data-service-type="' + v.service_type + '" data-package-name="' + v.package_name + '" data-item-code="' + v.item_code + '" data-item-name="' + v.item_name + '" data-item-wt="' + v.item_wt + '" data-item-price="' + v.item_price + '" data-package-price="0" data-technician-id="' + v.technician_id + '" data-bay-no="' + v.bay_no + '" data-start-time="' + v.start_time + '" data-end-time="' + v.end_time + '" data-warranty="' + v.warranty + '">')
						.append("<td>" + v.service_type + "</td>")
						.append("<td data-package-id=''></td>")
						.append("<td>" + v.item_code + "</td>")
						.append("<td>" + v.item_name + "</td>")
						.append("<td>" + v.item_wt + "</td>")
						.append("<td style='text-align:right; padding-right: 20px;'>" + v.item_price + "</td>")
						.append("<td>" + ((v.warranty==1)?"Yes":"No") + "</td>")
					);
				}
			});

			$.each(data.spareparts, function(i, v) { 
				$("#myTableSparepart").find("tbody")
				.append($('<tr>')
					.append("<td>" + v.code + "</td>")
					.append("<td>" + v.name + "</td>")
					.append("<td data-warranty='" + v.warranty + "'>" + ((v.warranty==1)?"Yes":"No") + "</td>") 
					.append("<td style='text-align:right; padding-right: 20px;'>" + v.price + "</td>")
					.append("<td style='text-align:right; padding-right: 20px;'>" + v.qty + "</td>")
					.append("<td style='text-align:right; padding-right: 20px;'>" + v.amount + "</td>") 
				);
			});

			$("#txtTotalWaitingTime").val(data.total_waiting_time);	
			$("#txtServiceRemark").val(data.service_remark);
			$("#chkTestDriveAgree").prop("checked", data.test_drive_agree); 
			$("#txtDiscount").val(data.discount); 
			calculate();
		});
	}

	function calculate(){
		var discount = (($("#txtDiscount").val()!="" && $("#txtDiscount").val()!=null)?parseInt($("#txtDiscount").val().replace(/,/g, '')):0);
		var total_service_item = total_sparepart = total_amount = net_amount = 0;

		$("#myTableServiceItem tbody tr").each(function (i,v){
			if($(this).find("td").length>4){
				total_service_item += parseInt($(this).find("td").eq(5).text().replace(/,/g, ''));
			}
		});
		$("#txtServiceItemTotalAmount").val(total_service_item.toLocaleString());

		$("#myTableSparepart tbody tr").each(function (i,v){
			total_sparepart += parseInt($(this).find("td").eq(5).text().replace(/,/g, ''));
		});
		$("#txtSparepartTotalAmount").val(total_sparepart.toLocaleString());

		total_amount = (total_service_item + total_sparepart);
		net_amount = (total_amount - discount);

		$("#txtTotalAmount").val(total_amount.toLocaleString());
		$("#txtNetAmount").val(net_amount.toLocaleString());
		$("#txtPayAmount").val(net_amount.toLocaleString());
	}  

	$("#btnSubmit").click(function() {
		$("#frmEntry").submit();
	});

	$("#frmEntry").on('submit', (function(e) {
		e.preventDefault();
		var fileInput = $('#input-image-hidden')[0];
		var file = fileInput.files[0];
		var date = $("#txtDatePicker").val();
		var gl_code = $("#cboGLCode").val();
        var gl_code_bank_or_cash = $("#cboBankCashAccount").val();
		var amount = parseInt($("#txtPayAmount").val().replace(/,/g, ''));
        var paid_by = $("#txtPaidBy").val();
		var description = $("#txtDescription").val();

		if(gl_code=="") {
			bootbox.alert("Please choose G/L code.");
		}else if(gl_code_bank_or_cash=="") {
			bootbox.alert("Please choose account.");
		}else if(paid_by.trim()==""){
            bootbox.alert("Please fill paid by.");
        }else{
    		$("#btnSubmit").attr("disabled", true);
		    var formData = new FormData();
		    var objArr = [];
		    objArr.push({
		    	"id" : id,
		    	"date" : date,
		    	"gl_code" : gl_code,
		    	"gl_code_bank_or_cash" : gl_code_bank_or_cash,
		    	"amount" : amount,
		    	"paid_by": paid_by,
		    	"description": description
		    });

		    formData.append('file', file);
		    formData.append('objArr', JSON.stringify(objArr));
		    $.ajax({
		    	url : APP_URL + "api/service/service_payment/create.php",
		    	type : "POST",
		    	processData : false,
		    	contentType : false,
		    	data : formData,
		    	success: function(data) {
    				$("#btnSubmit").attr("disabled", false);
		    		if(data.message == "created") {
		    			bootbox.confirm({
							message: "<h4>Successfully make payment. Do you want to print exit form?</h4>",
							buttons: {
								confirm: {
									label: '<span class="glyphicon glyphicon-ok"></span> Yes',
									className: 'btn-primary'
								},
								cancel: {
									label: '<span class="glyphicon glyphicon-remove"></span> No',
									className: 'btn-danger'
								}
							},
							callback: function (result) {
								if(result){
									document.location = APP_URL + "finance/invoices.php";
									window.open(APP_URL + "print/exit_form.php?act=print&id=" + id);
								}else{
									document.location = APP_URL + "finance/invoices.php";
								}
							}
						});
		    		}else if(data.message=="session expire"){
						bootbox.alert("Session Expire! Please refresh the browser and login again.");
					}else{
		    			bootbox.alert("Error on server side.");
		    		}
		    	}
		    });
	  	}
	}));

	function goToInvoices(){
		document.location = APP_URL + "finance/invoices.php";
	}

	function goToPayment(){
		$("#myModalPayment").modal("show");
	}

	function HandleBrowseClick(input_image){
		var fileinput = document.getElementById(input_image);
		fileinput.click();
	}
</script>	
