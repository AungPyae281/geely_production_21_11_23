<?php include '../header.php'; ?>
<style>
	#myTable tbody td{
		padding-top: 9px;
		padding-bottom: 9px;
	}
	select {
		padding-top: 1px !important;
	}
</style>
<div class="content-wrapper" style="min-height: 1203.6px;"> 
	<section class="content-header">
		<div class="container-fluid">
			<div class="row mb-2">
				<div class="col-md-6">
					<h1>Sparepart Pre Order</h1>
				</div>
				<div class="col-md-6"></div>
			</div>
		</div>
	</section>
	<section class="content">
		<div class="container-fluid">
			<div class="row">
				<div class="col-md-12">
					<div class="card card-outline card-primary">
						<div class="card-header">
							<h3 class="card-title">Search</h3>
						</div>
						<div class="overlay white" id="loading" style="display:none;position: absolute;width: 100%;height: 100%;z-index: 1000;">
							<i class="fas fa-3x fa-sync-alt rotate360"  style="margin: 70px 45%;"></i>
						</div>
						<form role="form">
							<div class="card-body">
								<div class="row">
									<div class="col-md-6">
										<div class="form-group row">
											<label class="col-md-4 col-form-label" style="text-align: right;">Date (From):</label>
											<div class="col-md-1 icheck-success d-inline">
												<input id="chkDateFrom" type="checkbox" style="margin: 8px 0px">
												<label for="chkDateFrom"></label>
											</div>
											<div class="col-md-7">  
												<div class="input-group input-append date" id="datePicker1" data-date="2020-02-04" data-date-format="yyyy-mm-dd">
													<div class="input-group-prepend">
														<span class="input-group-addon input-group-text" style="width: 40px; display: table-cell;">
															<i class="far fa-calendar-alt"></i>
														</span>
													</div>
													<input type="text" class="form-control float-right" id="txtDatePicker1" value="1982-06-15" readonly disabled>
												</div>
											</div>
										</div>
										<div class="form-group row">
											<label class="col-md-4 col-form-label" style="text-align: right;">Date (To):</label>
											<div class="col-md-1"></div>
											<div class="col-md-7">  
												<div class="input-group input-append date" id="datePicker2" data-date="2020-02-04" data-date-format="yyyy-mm-dd">
													<div class="input-group-prepend">
														<span class="input-group-addon input-group-text" style="width: 40px; display: table-cell;">
															<i class="far fa-calendar-alt"></i>
														</span>
													</div>
													<input type="text" class="form-control float-right" id="txtDatePicker2" value="1982-06-15" readonly disabled>
												</div>
											</div>
										</div>
									</div>		
									<div class="col-md-6">
										<div class="form-group row">
											<label class="col-md-4 col-form-label" style="text-align: right;">Deposit:</label>
											<div class="col-md-8">
												<div class="radio" style="padding-top: 7px;">
													<label class="col-md-3"  style="padding-left: 0px;">
														<input value="" id="optAll" name="optDeposit" type="radio" checked>
														All
													</label>
													<label class="col-md-3" style="padding-left: 0px;">
														<input value="Yes" id="optYes" name="optDeposit" type="radio">
														Yes
													</label>
													<label class="col-md-3" style="padding-left: 0px;">
														<input value="No" id="optNo" name="optDeposit" type="radio">
														No
													</label>
												</div>
											</div>
										</div>
										<div class="form-group row">
											<div class="col-md-4"></div>
											<div class="col-md-4">
												<button type="button" class="btn btn-primary btn-block" onclick="search()">Search</button>
											</div>
											<div class="col-md-4">
												<button type="button" id="btnExport" value=" Export Table data into Excel " datafrom="myTable" class="btn btn-success btn-block exportToExcel">Export Data</button> 
											</div>
										</div>
									</div>
								</div>	
							</div>
						</form>
					</div>
				</div>
			</div>
			<div class="card card-outline card-primary">
				<div class="card-header">
					<h3 class="card-title">Sparepart Pre Order List <span id="total_records" style="font-weight:bold;"> </span></h3>
					<div class="card-tools">
						<button type="button" class="btn btn-tool" data-card-widget="collapse"><i class="fas fa-minus"></i></button>
						<button type="button" class="btn btn-tool" data-card-widget="remove"><i class="fas fa-remove"></i></button>
					</div>
				</div>
				<div class="card-body p-0">
					<table class="table table-responsive table-striped table-bordered" id="myTable">
						<thead>                  
							<tr>
								<th style="width: 3%">#</th>
								<th>Pre Order ID</th>
								<th>Date</th>
								<th>Service Center</th>
								<th>Customer Name</th>
								<th>Customer Phone</th>
								<th>Plate No.</th>
								<th>Total Items</th>
								<th>Total Quantity</th>
								<th>Amount</th>
								<th>Payment</th>
								<th>Balance</th>
							</tr>
						</thead>
						<tbody></tbody>
					</table>
				</div>
			</div>
		</div>
	</section>
</div>
<?php include '../footer.php'; ?>
<script>
	var d = new Date();
	var mm = (d.getMonth("MM") + 1);
	var dd = d.getDate();
  	var yyyy = d.getFullYear();
	var customDate = d.getFullYear() + "-" + ((mm<10)?"0" + mm:mm) + "-" +  ((dd<10)?"0" + dd:dd);
	$('#datePicker1').attr("data-date", customDate);
	$("#txtDatePicker1").val(customDate);
	$('#datePicker2').attr("data-date",customDate);
	$("#txtDatePicker2").val(customDate);

	$(function(){
		$("body").addClass("sidebar-collapse");	
		$('#datePicker1').datepicker();
		$('#datePicker2').datepicker(); 
		search();
	});	

	$(".exportToExcel").click(function(){
		exportExcel("#myTable");
	});

	$("#chkDateFrom").change(function() {
		if ($('#chkDateFrom').prop('checked')){
			$("#txtDatePicker1").prop("disabled", false);
			$("#txtDatePicker1").css("cursor", "pointer");

			$("#txtDatePicker2").prop("disabled", false);
			$("#txtDatePicker2").css("cursor", "pointer");
		}else{
			$("#txtDatePicker1").prop("disabled", true);
			$("#txtDatePicker1").val(customDate);
			$("#datePicker1").datepicker("setDate", customDate);

			$("#txtDatePicker2").prop("disabled", true);
			$("#txtDatePicker2").val(customDate);
			$("#datePicker2").datepicker("setDate", customDate);
		}
	}); 

	function search(){
		$("#loading").css("display","block");
		var df = ($("#chkDateFrom").prop("checked"))?$("#txtDatePicker1").val():"";
		var dt = ($("#chkDateFrom").prop("checked"))?$("#txtDatePicker2").val():"";
		var deposit = $("input[name='optDeposit']:checked").val();

		$("#myTable").find("tbody").find("tr").remove(); 
		$.ajax({
			type: "POST",
			url: APP_URL + "api/sparepart/pre_order/get_all_pre_order_payment_remain.php",
			data: JSON.stringify({ df: df, dt: dt, deposit: deposit })
		}).done(function(data) {	
			$("#loading").css("display","none");
			if(data.records.length>1){
				$("#total_records").text(" - " + data.records.length + " records found.");
			}else{
				$("#total_records").text(" - " + data.records.length + " record found.");
			}
			$.each(data.records, function(i, v) {
				$("#myTable").find("tbody")
				.append($('<tr>')
					.append("<td>" + (i + 1) + "</td>")
					.append("<td><span style='text-decoration: underline; color: blue; cursor: pointer;' onclick='goToDetail(this);' data-id='" + v.id + "'>" + v.pre_order_id + "</span></td>")
					.append("<td>" + v.date + "</td>")
					.append("<td>" + v.service_center + "</td>")
					.append("<td>" + v.customer_name + "</td>")
					.append("<td>" + v.customer_phone + "</td>")
					.append("<td>" + v.plate_no + "</td>")
					.append("<td style='text-align: right; padding-right: 20px;'>" + v.total_items + "</td>")
					.append("<td style='text-align: right; padding-right: 20px;'>" + v.total_quantity + "</td>")
					.append("<td style='text-align: right; padding-right: 20px;'>" + v.amount + "</td>")
					.append("<td style='text-align: right; padding-right: 20px;'>" + v.payment + "</td>")
					.append("<td style='text-align: right; padding-right: 20px;'>" + v.balance + "</td>")
				);
			});
       });
	}

	function goToDetail(obj){
		document.location = APP_URL + "finance/sparepart_pre_order_payment.php?act=entry&id=" + $(obj).attr("data-id");
	}
</script>
