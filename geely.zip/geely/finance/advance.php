<?php include '../header.php'; ?>
<style>
	select{
		padding-top: 1px !important;
	}
</style>
<div class="content-wrapper" style="min-height: 1203.6px;"> 
	<section class="content-header">
		<div class="container-fluid">
			<div class="row mb-2">
				<div class="col-md-6">
					<h1>Advance - Entry</h1>
				</div>
				<div class="col-md-6"></div>
			</div>
		</div>
	</section>
	<section class="content">
		<div class="container-fluid">
			<div class="row">
				<div class="col-md-12">
					<div class="card card-outline card-primary">
						<div class="card-header">
							<h3 class="card-title">Info</h3>
						</div>
						<div class="overlay white" id="loading" style="display:none;position: absolute;width: 100%;height: 100%;z-index: 1000;">
							<i class="fas fa-3x fa-sync-alt rotate360"  style="margin: 70px 45%;"></i>
						</div>
						<form role="form" id="frmEntry">
							<div class="card-body">
								<div class="row">
									<div class="col-md-6">
										<div class="form-group row">
											<label class="col-md-4 col-form-label" style="text-align: right;">Date: </label>
											<div class="col-md-4">  
												<div class="input-group input-append date" id="datePicker" data-date="2020-02-04" data-date-format="yyyy-mm-dd">
													<div class="input-group-prepend">
														<span class="input-group-addon input-group-text" style="width: 40px; display: table-cell;">
															<i class="far fa-calendar-alt"></i>
														</span>
													</div>
													<input type="text" class="form-control float-right" id="txtDatePicker" value="1982-06-15" readonly>
												</div>
											</div>
											<label class="col-md-2 col-form-label" style="text-align: right;">Due Days: </label>
											<div class="col-md-2">  
												<input type="number" class="form-control" id="txtDueDays" value="7" style="text-align: right;" onkeypress="return isNumber(event)" onkeyup="btozero(this);">
											</div>
										</div>
										<div class="form-group row">
											<label class="col-md-4 col-form-label" style="text-align: right;">G/L Code: </label>
											<div class="col-md-8">
												<select class="form-control" id="cboGLCode"></select>
											</div>
										</div>
										<div class="form-group row">
											<label class="col-md-4 col-form-label" style="text-align: right;">Name: </label>
											<div class="col-md-8">
												<textarea class="form-control" id="txtName" rows="2" disabled></textarea>
											</div>
										</div>
										<div class="form-group row">
											<label class="col-md-4 col-form-label" style="text-align: right;">Amount (MMK): </label>
											<div class="col-md-8">
												<input type="text" class="form-control" id="txtAmount" value="0" style="text-align:right;" onkeypress="return isNumber(event)" onkeyup="btozero(this);AddComma(this);">
											</div>
										</div>
										<div class="form-group row">
											<label class="col-md-4 col-form-label" style="text-align: right;">Description: </label>
											<div class="col-md-8">
												<textarea class="form-control" id="txtDescription" rows="2"></textarea>
											</div>
										</div>
										<div class="form-group row">
											<label class="col-md-4 col-form-label" style="text-align: right;">By: </label>
											<div class="col-md-8">
												<input type="text" class="form-control" id="txtBy">
											</div>
										</div>
									</div>
									<div class="col-md-6">
										<div class="form-group row">
											<label class="col-md-4 col-form-label" style="text-align: right;">Account (From): </label>
											<div class="col-md-8">
												<select class="form-control" id="cboAccount"></select>
											</div>
										</div>
										<div class="form-group row">
											<label class="col-md-4 col-form-label" style="text-align: right;">Balance: </label>
											<div class="col-md-8">
												<input type="text" class="form-control" id="txtBalance" disabled style="text-align:right;" value="0">
											</div> 
										</div>
										<div class="form-group row">
											<label class="col-md-4 control-label" style="text-align: right;">Upload Receipt:</label>
											<div class="col-md-8">
												<input style="display:none" name="file" id="input-image-hidden" onchange="document.getElementById('previewing').src = window.URL.createObjectURL(this.files[0])" type="file" accept="image/jpeg, image/png" >
												<img id="previewing" name="previewing" src="<?=$app_url;?>img/no_image.jpg" style="height:133px; width:auto;cursor:pointer;"onclick="HandleBrowseClick('input-image-hidden');" title="Click to Change the Photo."> 
											</div>
											
										</div>
										<div class="form-group row">
											<div class="col-md-4"></div>
											<div class="col-md-3">
												<button type="button" class="btn btn-success btn-block" id="btnSubmit">Add</button>
											</div>
										</div>
									</div>
								</div>
							</div>
						</form>
					</div>
				</div>
			</div>
		</div>
	</section>
</div>
<?php include '../footer.php'; ?>
<script>
	var d = new Date();
	var mm = (d.getMonth("MM") + 1);
	var dd = d.getDate();
	var yyyy = d.getFullYear();
	var customDate = d.getFullYear() + "-" + ((mm<10)?"0" + mm:mm) + "-" +  ((dd<10)?"0" + dd:dd);
	$('#datePicker').attr("data-date",customDate);
	$("#txtDatePicker").val(customDate);

	$(function() {
		$("body").addClass("sidebar-collapse");
		$('#datePicker').datepicker();
		getAdvanceGL();
		getBankAndCashAccount(); 
	});

	$('#cboGLCode').on('change',function(){
		if($("#cboGLCode").val()!=""){
			$("#txtName").val($('#cboGLCode option:selected').attr('data-name'));
		}else{
			$("#txtName").val("");
		}
	});

	$('#cboAccount').on('change',function(){
		if($("#cboAccount").val()!=""){
			$("#txtBalance").val(parseFloat($("#cboAccount option:selected").attr("data-balance")).toLocaleString());
		}else{
			$("#txtBalance").val(0);
		}
	});

	function getAdvanceGL(){
		$("#cboGLCode").find("option").remove();
		$("#cboGLCode").append("<option value='' data-name=''></option>");
		$.ajax({
			url: APP_URL + "api/finance/gl_account/get_all_rows.php",
			type: "POST",
			data: JSON.stringify({ category: 'Advance' })
		}).done(function(data) {
			$.each(data.records, function(i, v) {
				$("#cboGLCode").append("<option value='" + v.gl_code + "' data-name='" + v.name + "'>" + v.gl_code + "</option>");
			});
		});
	}

	function getBankAndCashAccount(){ 
		$("#cboAccount").find("option").remove();
		$("#cboAccount").append("<option value='' data-balance=''></option>");

		$.ajax({
			url: APP_URL + "api/finance/bank_account/get_all_bank_and_cash_account.php"
		}).done(function(data) {
			$.each(data.records, function(i, v) {
				$("#cboAccount").append("<option value = '" + v.gl_code + "' data-balance = '" + v.balance + "'>" + v.gl_code + " (" + v.name + ")</option>");
			});
		});
	}

	$("#btnSubmit").click(function() {
		$("#frmEntry").submit();
	});

	$("#frmEntry").on('submit', (function(e) {
		e.preventDefault();
		var fileInput = $('#input-image-hidden')[0];
		var file = fileInput.files[0];
		var date = $("#txtDatePicker").val();
		var due_days = $("#txtDueDays").val();
		var gl_code_to = $("#cboGLCode").val();
		var amount = parseFloat($("#txtAmount").val().replace(/,/g, ''));
		var description = $("#txtDescription").val();
		var advance_by = $("#txtBy").val();
		var gl_code_from = $("#cboAccount").val();
		var balance = parseFloat($("#txtBalance").val().replace(/,/g, ''));

		if (!file){
			bootbox.alert("Please upload receipt.");
		}else if(gl_code_to == "") {
			bootbox.alert("Please choose account (to).");
		}else if(gl_code_from == "") {
			bootbox.alert("Please choose account (from).");
		}else if(balance < amount) {
			bootbox.alert("Balance insufficient.");
		}else{
    		$("#loading").css("display", "block");
		    var formData = new FormData(); // Declare the formData variable
		    var objArr = [];
		    objArr.push({
		    	"date": date,
		    	"due_days": due_days,
		    	"gl_code_to": gl_code_to,
		    	"amount": amount,
		    	"description": description,
		    	"advance_by": advance_by,
		    	"gl_code_from": gl_code_from
		    });

		    formData.append('file', file);
		    formData.append('objArr', JSON.stringify(objArr));
		    $.ajax({
		    	url: APP_URL + "api/finance/advance/create.php",
		    	type: "POST",
		    	processData: false,
		    	contentType: false,
		    	data: formData,
		    	success: function(data) {
		    		$("#loading").css("display", "none");
		    		if (data.message == "created") {
		    			bootbox.alert("Successfully Added.");
		    			$("#frmEntry")[0].reset();
		    			$("#txtDatePicker").val(customDate);
		    			$("#datePicker").datepicker("setDate", customDate);
		    			document.getElementById('previewing').src = APP_URL + "img/no_image.jpg";
		    			getAdvanceGL();
		    			getBankAndCashAccount();
		    		} else {
		    			bootbox.alert("Error on server side.");
		    		}
		    	}
		    });
	  	}
	}));

	function HandleBrowseClick(input_image){
		var fileinput = document.getElementById(input_image);
		fileinput.click();
	}

	function btozero(obj){
		if($(obj).val() == "")$(obj).val(0);
	}

	function isNumber(evt) {
		evt = (evt) ? evt : window.event;
		var charCode = (evt.which) ? evt.which : evt.keyCode;
		if ( (charCode > 31 && charCode < 48) || charCode > 57) {
			return false;
		}
		return true;
	}

	function AddComma(obj) {
		var amount = $(obj).val().replace(/,/g, '');
		$(obj).val(parseInt(amount).toLocaleString());
	} 
</script>	
