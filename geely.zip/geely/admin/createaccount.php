<?php include '../header.php'; ?>
<?php
$id = "";
if(isset($_GET['id'])){
	if(!empty($_GET['id'])){
		$id = $_GET['id'];
	}
}
?>	
<style>
	select{
		padding-top: 1px !important;
	}
</style>
<div class="content-wrapper">
	<section class="content-header">
		<div class="container-fluid">
			<div class="row mb-2">
				<h1>
					<?php if($id==""){ ?>
					Create User Account
					<?php }else{ ?>
					Edit User Account
					<?php } ?>
				</h1>
			</div>
		</div>
	</section>
	<section class="content">
		<div class="container-fluid">
			<div class="card card-outline card-primary">
				<div class="card-header">
					<h3 class="card-title">User Account Detail</h3>
				</div>
				<form role="form" id="frmCreateUser">
					<div class="card-body">
						<div class="row">
							<div class="col-md-3"></div>
							<div class="col-md-6">
								<div class="form-group" style="text-align: center;">
									<input type="hidden" id="txtFormState" name="formState" value=<?=(($id=="")?"Create":"Edit")?>>
									<input style="display:none" name="file" id="input-image-hidden" onchange="document.getElementById('previewing').src = window.URL.createObjectURL(this.files[0])" type="file" accept="image/jpeg, image/png" >
									<img id="previewing" name="previewing" src="<?=$app_url;?>img/dummy_user.png" style="height:128px; width:128px;cursor:pointer;" onclick="HandleBrowseClick('input-image-hidden');" title="Click to Change the Photo." class="profile-user-img img-responsive img-circle" alt="User profile picture">
									<div><center>128 X 128</center></div>
								</div>
								<div class="form-group row">
									<label class="col-md-4 col-form-label" style="text-align: right;">Department:</label>
									<div class="col-md-6">
										<select class="form-control" id="cboDepartment" style=" display: inline-block !important;" <?=(($id=="")?"":"disabled")?>></select>
									</div>
								</div>	
								<div class="form-group row">
									<label class="col-md-4 col-form-label" style="text-align: right;">Position:</label>
									<div class="col-md-6">
										<select class="form-control" id="cboPosition" style=" display: inline-block !important;" <?=(($id=="")?"":"disabled")?>></select>
									</div>
								</div>
								<div class="form-group row">
									<label class="col-md-4 col-form-label" style="text-align: right;">Staff:</label>
									<div class="col-md-6">
										<select class="form-control" id="cboStaff" name="cboStaff" <?=(($id=="")?"":"disabled")?>></select>
										<input type="hidden" id="txtStaffID" name="txtStaffID" class="form-control">
									</div>
									<div class="col-md-2"></div>
								</div> 
								<div class="form-group row">
									<label class="col-md-4 col-form-label" style="text-align: right;">User Name:</label>
									<div class="col-md-6">
										<input class="form-control" id="txtUserName" name="txtUserName" type="text"/>
									</div>
									<div class="col-md-2"></div>
								</div>

								<div class="form-group row">
									<label class="col-md-4 col-form-label" style="text-align: right;">Dashboard:</label>
									<div class="col-md-6">
										<select class="form-control" id="cboDashboard" name="cboDashboard"></select>
									</div>
									<div class="col-md-2"></div>
								</div>
								<div class="form-group row">
									<label class="col-md-4 col-form-label" style="text-align: right;">User Role:</label>
									<div class="col-md-6">
										<select class="form-control" id="cboUserRole" name="cboUserRole"></select>
									</div>
									<div class="col-md-2"></div>
								</div>
								<?php if($id==""){ ?>
								<div class="form-group row">
									<label class="col-md-4 col-form-label" style="text-align: right;">Password:</label>
									<div class="col-md-6">
										<input type="password" id="txtPassword"  name="txtPassword" class="form-control" minlength="4"  maxlength="16">
									</div>
									<div class="col-md-2"></div>
								</div>
								<div class="form-group row">
									<label class="col-md-4 col-form-label" style="text-align: right;">Confirm Password:</label>
									<div class="col-md-6">
										<input type="password" id="txtConfirmPassword"  name="txtConfirmPassword" class="form-control"  maxlength="16">
									</div>
									<div class="col-md-2"></div>
								</div>
								<div class="form-group row">
									<label class="col-md-4 col-form-label"></label>
									<div class="col-md-6">
										<button class="btn btn-info col-md-5" type="button" onclick="clearForm()">Clear</button>
										<button id="btnSubmit" class="btn btn-success col-md-5" type="button" value="Create" style="float: right;">Create</button>
									</div>
									<div class="col-md-2"></div>
								</div>
								<?php }else{ ?>
								<div class="form-group row">
									<label class="col-md-4 col-form-label"></label>
									<div class="col-md-6">
										<button id="btnUpdate" class="btn btn-success" type="button" value="Update" style="float: right;">Update</button>
									</div>
									<div class="col-md-2"></div>
								</div>
								<?php } ?>
							</div>
							<div class="col-md-3"></div>
						</div>
					</div>
				</form>
			</div>
		</div>
	</section>
</div>
<?php include '../footer.php'; ?>
<script>
	var id = '<?=$id;?>';

	$(function() {
		if(id!=""){
			$("#txtUserName").attr("disabled", true);
			getOneRow();
		}else{
			getAllDepartment(); 
			getAllDashboard();
		}
		$("#txtUserName").val("");
		$("#txtPassword").val("");
	});

	$("#cboDepartment").change(function(){
		getPositionbyDepartment();
	});

	$("#cboPosition").change(function(){
		getStaffByPosition();
	});

	$("#cboDashboard").change(function(){
		fillRole();
	});

	$("#cboStaff").change(function(){ 
		$("#txtStaffID").val($("#cboStaff option:selected").attr('data-id'));
		setAbbr($("#cboStaff" ).val());
	});

	$("#btnSubmit").click(function(){
		$("#frmCreateUser").submit();
	});

	$("#btnUpdate").click(function(){
		$("#frmCreateUser").submit();
	});  

	function HandleBrowseClick(input_image)
	{
		var fileinput = document.getElementById(input_image);
		fileinput.click();
	}  

	function getAllDepartment(dept, position, eid){
		$("#cboDepartment").find("option").remove();
		$("#cboDepartment").append("<option value = '' data-id = ''></option>");
		$.ajax({
			url: APP_URL + "api/hr/department/get_all_rows.php",
			type: "POST"
		}).done(function(data) {
			$.each(data.records, function(i, v) {
				if(v.department==dept){
					$("#cboDepartment").append("<option value= '" + v.department + "' data-id = '"+ v.id + "' selected>" + v.department + "</option>");
				}else{
					$("#cboDepartment").append("<option value= '" + v.department + "' data-id = '"+ v.id + "'>" + v.department + "</option>");
				}
			});
			getPositionbyDepartment(position, eid);
		});
	}

	function getPositionbyDepartment(position, eid){ 
		var department = $("#cboDepartment").val();

		$("#cboPosition").find("option").remove();
		$("#cboStaff").find("option").remove(); 
		if(department){
			$.ajax({
				type: "POST",
				url: APP_URL + "api/hr/position/get_all_rows_by_department.php",
				data: JSON.stringify({ department: department })
			}).done(function(data) {
				$.each(data.records, function(i, v) {
					if(v.position==position){
						$("#cboPosition").append("<option value= '" + v.position + "' data-id = '"+ v.id + "' selected>" + v.position + "</option>");
					}else{
						$("#cboPosition").append("<option value= '" + v.position + "' data-id = '"+ v.id + "'>" + v.position + "</option>");
					}				
				});
				getStaffByPosition(eid);
			});
		}
	}

	function getStaffByPosition(eid){
		var department = $("#cboDepartment").val();
		var position = $("#cboPosition").val();

		$("#cboStaff").find("option").remove(); 
		if(department && position){
			$.ajax({
				type: "POST",
				url: APP_URL + "api/hr/staff/get_staff_by_position.php",
				data: JSON.stringify({ department: department, position: position })
			}).done(function(data) {
				$.each(data.records, function(i, v) {
					if(v.id==eid){
						$("#cboStaff").append("<option value='" + v.name + "' data-id = '"+ v.id +"' selected>" + v.name + "</option>");
					}else{
						$("#cboStaff").append("<option value='" + v.name + "' data-id = '"+ v.id +"' >" + v.name + "</option>");
					}
				});
				$("#txtStaffID").val($("#cboStaff option:selected").attr("data-id"));
				if(!eid){
					$("#txtUserName").val(""); 
					setAbbr($("#cboStaff" ).val());
				}
			});
		}
	}

	function getAllDashboard(dhb, userrole){
		$("#cboDashboard").find("option").remove();
		$.ajax({
	        url: APP_URL + "api/process/get_all_dashboard.php"
	    }).done(function(data) {
	        $.each(data.records, function(i, v) {
		    	var dashb = "";
		    	if(v.dashboard=="hr"){
		    		dashb = "HR";
		    	}else{
		    		var arrD = v.dashboard.split("_");
		    		for (var x = 0; x < arrD.length; x++) {
		    			dashb += ((dashb!="")?" ":"") + arrD[x].charAt(0).toUpperCase() + arrD[x].slice(1);
		    		}
		    	}
		    	if(v.dashboard==dhb){
					$("#cboDashboard").append("<option value='" + v.dashboard + "' selected>" + dashb + "</option>");
		    	}else{
					$("#cboDashboard").append("<option value='" + v.dashboard + "'>" + dashb + "</option>");
		    	}
	        });
			fillRole(userrole);
	    }); 
	}

	function fillRole(userrole){
		var dashboard = $("#cboDashboard").val();
		$("#cboUserRole").find("option").remove();
		if(dashboard){
			$.ajax({
				url: APP_URL + "api/userrole/get_roles_by_dashboard.php",
				type: "POST",
				data: JSON.stringify({ dashboard: dashboard })
			}).done(function(data) {	
				$.each(data.records, function(i, v) {
					if(v.role_name==userrole){
						$("#cboUserRole").append("<option value= '" + v.role_name + "' selected>" + v.role_name + "</option>");
					}else{
						$("#cboUserRole").append("<option value= '" + v.role_name + "'>" + v.role_name + "</option>");
					}
				});
			});
		}
	}

	function setAbbr(name){
		if(!name){
			$("#txtUserName").val("");	
		}else{
			var matches = name.match(/\b(\w)/g);
			if(matches){
				var abbr = matches.join('');
				$("#txtUserName").val(abbr.toLowerCase());	
			}
		}	
	}

	$("#frmCreateUser").on('submit',(function(e) {
		e.preventDefault();
		var formState = $("#txtFormState").val();
		var username = $("#txtUserName").val();
		var userrole = $('#cboUserRole').val();
		var password = $("#txtPassword").val();
		var confirmpassword = $("#txtConfirmPassword").val();

		if($("#cboDepartment").val()==null || $("#cboDepartment").val()==""){
			bootbox.alert("Please choose department.");
		}else if($("#cboPosition").val()==null || $("#cboPosition").val()==""){
			bootbox.alert("Please choose position.");
		}else if($("#cboDashboard").val()==null || $("#cboDashboard").val()==""){
			bootbox.alert("Please choose dashboard.");
		}else if(userrole==null || userrole==""){
			bootbox.alert("Please choose userrole.");
		}else if(formState=="Create" && (username.trim()=="" || password.trim()=="" || confirmpassword.trim()=="" || userrole.trim()=="") ){
			bootbox.alert("Please fill the boxes.");
		}else if(formState=="Create" && (password.trim() != confirmpassword.trim())){
			bootbox.alert("Passwords are unmatch! Please enter again.");
		}else if(formState=="Create" && password.trim().length<5){
			bootbox.alert("Password should be at least 5.");
		}else if(formState=="Edit" && userrole.trim()==""){
			bootbox.alert("Please fill User Role.");
		}else{

			if(formState=="Edit"){	
				$("#txtUserName").prop("disabled", false);
			}
			
			$.ajax({
				url: APP_URL + "api/user/create.php",
				type: "POST",             
				data: new FormData(this),
				contentType: false,       
				cache: false,             
				processData:false,        
				success: function(data)   
				{
					if(data.message=="created"){
						bootbox.alert("Successfully Created.");
						clearForm();
						document.getElementById('previewing').src = "<?=$app_url;?>/img/dummy_user.png";
					}else if(data.message=="updated"){
						bootbox.alert("Successfully Updated."); 
						document.location = APP_URL + "admin/userlist.php";
					}else if(data.message=="duplicate"){
						bootbox.alert("Not allow dupulicate username.");
					}else{
						bootbox.alert("Error on server side.");
					}
				}
			});
		}
	}));

	function getOneRow(){
		$.ajax({
			url: APP_URL + "api/user/get_one_row.php",
			type: "POST",
			data: JSON.stringify({ id: id })
		}).done(function(data){
			if(data.username){
				var profilepicture = (data.profilepicture)?APP_URL + "api/user/" + data.profilepicture:APP_URL + "img/dummy_user.png";
				$("#previewing").attr('src', profilepicture);
				getAllDepartment(data.department, data.position, data.staff_id);
				getAllDashboard(data.dashboard, data.userrole);
				$("#txtUserName").val(data.username);
			}
		});
	} 

	function clearForm(){
		$("#frmCreateUser")[0].reset();
		getAllDepartment();
		getAllDashboard();
	} 
</script>