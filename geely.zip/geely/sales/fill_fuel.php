<?php include '../header.php'; ?>
<?php
    $oc_no = "";
    if(isset($_GET['oc_no'])){
        if(!empty($_GET['oc_no'])){
            $oc_no = $_GET['oc_no'];
        }
    }
?>
<style>
    .card{
        margin-bottom: 10px !important;
    }
    .card-header{
        padding: 8px 2px 8px 15px;
    }
    .card-body{
        padding: 15px 20px 5px 20px;
    }
    .nav-tabs{
        display: inline-flex;
    }
    .form-group{
        margin-bottom: 5px !important;
    }
    .form-control{
        border: 1px solid #d4d6d8ba !important;
    }
    .form-control:disabled, .form-control[readonly]{
        background-color: #e6e8ea9e !important;
    }
    input, textarea{
        font-size: 14px !important;
    }
</style>
<div class="content-wrapper" style="min-height: 1203.6px;"> 
    <section class="content-header">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                </div>
            </div>
        </div>
    </section>
    <section class="content"> 
    	<div class="container-fluid">
    		<div class="row">
                <div class="col-md-12" id="SummaryPanel">
                    <div class="card card-outline card-primary">
                        <div class="card-header">
                            <h3 class="card-title" id="txtProcessing"></h3>
                            <div class="card-tools">
                                <button type="button" class="btn btn-tool" data-card-widget="collapse"><i class="fas fa-minus"></i></button>
                                <button type="button" class="btn btn-tool" data-card-widget="remove"><i class="fas fa-remove"></i></button>
                            </div>
                        </div>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group row">
                                        <label class="col-md-4 col-form-label" style="text-align: right;">OC No.:</label>
                                        <div class="col-md-8">
                                            <input type="text" class="form-control" id="txtOCNo" disabled value="<?=$oc_no?>">
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group row">
                                        <label class="col-md-4 col-form-label" style="text-align: right;">Sales Center:</label>
                                        <div class="col-md-8">
                                            <input type="text" class="form-control" id="txtSalesCenter" disabled>
                                        </div>
                                    </div>
                                </div> 
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-md-12">
                    <div class="card card-outline card-outline-tabs collapsed-card">
                        <div class="card-header p-0 border-bottom-0">
                            <ul class="nav nav-tabs" id="custom-tabs-tab" role="tablist">
                                <li class="nav-item">
                                    <a class="nav-link active" id="custom-tabs-customer-tab" data-toggle="pill" href="#custom-tabs-customer" role="tab" aria-controls="custom-tabs-customer" aria-selected="true">Customer Info</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" id="custom-tabs-vehicle-tab" data-toggle="pill" href="#custom-tabs-vehicle" role="tab" aria-controls="custom-tabs-vehicle" aria-selected="false">Vehicle Info</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" id="custom-tabs-payment-tab" data-toggle="pill" href="#custom-tabs-payment" role="tab" aria-controls="custom-tabs-payment" aria-selected="false">Payment Info</a>
                                </li>
                            </ul>
                            <div class="card-tools" style="padding-top: 10px;">
                                <button type="button" class="btn btn-tool" data-card-widget="collapse"><i class="fas fa-plus"></i></button>
                                <button type="button" class="btn btn-tool" data-card-widget="remove"><i class="fas fa-remove"></i></button>
                            </div>
                        </div>
                        <div class="card-body">
                            <div class="tab-content" id="custom-tabs-tabContent">
                                <div class="tab-pane fade active show" id="custom-tabs-customer" role="tabpanel" aria-labelledby="custom-tabs-customer-tab">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group row">
                                                <label class="col-md-4 col-form-label" style="text-align: right;">Name:</label>
                                                <div class="col-md-8">
                                                    <input type="text" class="form-control" id="txtCustomerName" disabled>
                                                </div>
                                            </div>
                                            <div class="form-group row">
                                                <label class="col-md-4 col-form-label" style="text-align: right;">NRC No.:</label>
                                                <div class="col-md-8">
                                                    <input type="text" class="form-control" id="txtCustomerNRCNo" disabled>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group row">
                                                <label class="col-md-4 col-form-label" style="text-align: right;">Mobile No.:</label>
                                                <div class="col-md-8">
                                                    <input type="text" class="form-control" id="txtCustomerMobileNo" disabled>
                                                </div>
                                            </div>
                                            <div class="form-group row">
                                                <label class="col-md-4 col-form-label" style="text-align: right;">Township:</label>
                                                <div class="col-md-8">
                                                    <input type="text" class="form-control" id="txtCustomerTownship" disabled>
                                                </div>
                                            </div>
                                        </div> 
                                    </div>
                                </div>
                                <div class="tab-pane fade" id="custom-tabs-vehicle" role="tabpanel" aria-labelledby="custom-tabs-vehicle-tab">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group row">
                                                <label class="col-md-4 col-form-label" style="text-align: right;">Vin No.:</label>
                                                <div class="col-md-8">
                                                    <input type="text" class="form-control" id="txtVinNo" disabled>
                                                </div>
                                            </div>
                                            <div class="form-group row">
                                                <label class="col-md-4 col-form-label" style="text-align: right;">Engine No.:</label>
                                                <div class="col-md-8">
                                                    <input type="text" class="form-control" id="txtEngineNo" disabled>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group row">
                                                <label class="col-md-4 col-form-label" style="text-align: right;">Particular:</label>
                                                <div class="col-md-8">
                                                    <textarea class="form-control" id="txtParticular" rows="4" style="height: 100px;" disabled></textarea>
                                                </div>
                                            </div>
                                        </div> 
                                    </div>
                                </div>
                                <div class="tab-pane fade" id="custom-tabs-payment" role="tabpanel" aria-labelledby="custom-tabs-payment-tab">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group row">
                                                <label class="col-md-4 col-form-label" style="text-align: right;">Total Payment:</label>
                                                <div class="col-md-8">
                                                    <input type="text" class="form-control" id="txtTotalPayment" disabled style="text-align:right;">
                                                </div>
                                            </div>
                                            <div class="form-group row">
                                                <label class="col-md-4 col-form-label" style="text-align: right;">Total Payment (%):</label>
                                                <div class="col-md-8">
                                                    <input type="text" class="form-control" id="txtTotalPaymentPercent" disabled style="text-align:right;">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group row">
                                                <label class="col-md-4 col-form-label" style="text-align: right;">Deposit Amount:</label>
                                                <div class="col-md-8">
                                                    <input type="text" class="form-control" id="txtDeposit" disabled style="text-align:right;">
                                                </div>
                                            </div>
                                            <div class="form-group row">
                                                <label class="col-md-4 col-form-label" style="text-align: right;">Remaining Balance:</label>
                                                <div class="col-md-8">
                                                    <input type="text" class="form-control" id="txtRemainingBalance" disabled style="text-align:right;">
                                                </div>
                                            </div>
                                        </div> 
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-md-12" id="FillTheFuel">
                    <div class="card card-outline card-primary">
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-3"></div>
                                <div class="col-md-4">
                                    <div class="form-group row">
                                        <label class="col-md-4 col-form-label" style="text-align: right;">Amount: </label>
                                        <div class="col-md-8"> 
                                            <input type="text" class="form-control float-right ff-info" id="txtFFAmount" onkeypress="return isNumber(event)" onkeyup="btozero(this);AddComma(this);" value="0" style="text-align:right;">
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label class="col-md-4 col-form-label" style="text-align: right;"></label>
                                        <label class="col-md-8 col-form-label" style="text-align: right; padding-top: 6px;" id="ffDone">
                                            Done
                                            <div class="icheck-success d-inline" style="padding-left: 3px;">
                                                <input type="checkbox" id="chkFFDone" style="padding-top: 6px;">
                                                <label for="chkFFDone" style="margin-top: 6px;"></label>
                                            </div>
                                            <button type="button" class="btn btn-success" id="btnFFSubmit" onclick="submitFuel();">Submit</button>
                                        </label>
                                    </div>                                        
                                </div> 
                                <div class="col-md-4"></div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
    	</div>
    </section> 
</div>
<?php include '../footer.php'; ?>
<script>
    var oc_no = "<?= $oc_no ?>";

    var d = new Date();
    var mm = (d.getMonth("MM")+1);
    var dd = d.getDate();
    var customDate = d.getFullYear() + "-" + ((mm<10)?"0" + mm:mm) + "-" +  ((dd<10)?"0" + dd:dd);

	$(function(){
        $("body").addClass("sidebar-collapse");  
        getSalesDetail();

        // Fill the Fuel
        $('#datePickerFF').attr("data-date", customDate);
        $("#txtDatePickerFF").val(customDate);
        $('#datePickerFF').datepicker();
        // Fill the Fuel
    });

    function HandleBrowseClick(obj){
        var inputID = $(obj).parent().find("input[type='file']").attr("id");
        var file = document.getElementById(inputID);
        file.click();
    }

    function getSalesDetail(){
        $.ajax({
            url: APP_URL + "api/sales/sales/get_sales_detail.php",
            type: "POST",
            data: JSON.stringify({ oc_no: oc_no })
        }).done(function(data) {    
            $("#txtProcessing").text(data.processing);
            $("#txtSalesCenter").val(data.sales_center);

            $("#txtCustomerName").val(data.c_name);
            $("#txtCustomerNRCNo").val(data.c_nrc_no);
            $("#txtCustomerMobileNo").val(data.c_mobile_no);
            $("#txtCustomerTownship").val(data.c_township);

            $("#txtVinNo").val(data.vin_no);
            $("#txtEngineNo").val(data.engine_no);
            $("#txtParticular").val(data.particular);

            $("#txtTotalPayment").val(data.total_payment);
            $("#txtTotalPaymentPercent").val(data.payment_percent);
            $("#txtDeposit").val(data.deposit);
            $("#txtRemainingBalance").val(data.remaining_balance);

            // Fill the Fuel
            if(data.ff_done==1){
                $("#ffDone").css("display", "none");
                $("#PDICheckList").css("display", "");
                $(".ff-info").attr("disabled", true);
            }

            $("#txtFFAmount").val(data.fuel_amount);
            // Fill the Fuel
        });
    } 

    // Fill the Fuel
    function submitFuel(){
        var fuel_amount = parseInt($("#txtFFAmount").val().replace(/,/g, ''));
        var ff_done = ($("#chkFFDone").prop("checked"))?1:0;

        if(fuel_amount==0){
            bootbox.alert("Please fill fuel amount.");
        }else{
            $("#btnFFSubmit").attr("disabled", true);
            $.ajax({
                url: APP_URL + "api/sales/sales/update_fuel.php",
                type: "POST",
                data: JSON.stringify({ oc_no: oc_no, fuel_amount: fuel_amount, ff_done: ff_done })
            }).done(function(data){ 
                $("#btnFFSubmit").attr("disabled", false);
                if(data.message=="updated"){
                    bootbox.alert("Successfully submitted.");
                    getSalesDetail();
                    if(ff_done){
                        document.location = APP_URL + "sales/sales_list.php";
                    }
                }else if(data.message=="session expire"){
                    bootbox.alert("Session Expire! Please refresh the browser and login again.");
                }else{
                    bootbox.alert("Error on server side.");
                }
            });
        }
    }
    // Fill the Fuel

    function btozero(obj){
        if($(obj).val() == "")$(obj).val(0);
    }

    function isNumber(evt) {
        evt = (evt) ? evt : window.event;
        var charCode = (evt.which) ? evt.which : evt.keyCode;
        if ( (charCode > 31 && charCode < 48) || charCode > 57) {
            return false;
        }
        return true;
    }

    function AddComma(obj) {
        var amount = $(obj).val().replace(/,/g, '');
        $(obj).val(parseInt(amount).toLocaleString());
    }
</script>