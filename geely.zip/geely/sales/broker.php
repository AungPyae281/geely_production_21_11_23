<?php include '../header.php'; ?> 
<?php
	$bid = "";
	if(isset($_GET['bid'])){
		if(!empty($_GET['bid'])){
			$bid = $_GET['bid'];
		}
	}
?>
<style>
    .form-group{
        margin-bottom: 5px !important;
    }
    .col-form-label{
        padding-top: 0px !important;
        padding-bottom: 2px !important;
    }
    .notEssential{
        padding-top: 5px !important;
    }
    #tblBankInfo{
        max-height: 150px;
        overflow-y: auto;
    }
    #tblBankAccountList{
        height: 150px;
        background-color: #f2f2f2;
        margin-bottom: 0px;
    }
    #tblBankAccountList tbody tr td{
        padding: 10px;
    }
    #tblBankAccountList tbody tr td:nth-child(3){
        text-align: right;
    }
</style>

<div class="content-wrapper" style="min-height: 1203.6px;"> 
	<section class="content-header">
		<div class="container-fluid">
			<div class="row mb-2">
				<div class="col-md-6">
					<h1>Broker - Entry</h1>
				</div>
				<div class="col-md-6"></div>
			</div>
		</div>
	</section> 
	<section class="content"> 
        <div class="container-fluid">
			<div class="row">
				<div class="col-md-12">
                    <div class="card card-outline card-primary">
                        <div class="overlay white" id="loading" style="display: none; position: absolute; width: 100%; height: 100%; z-index: 1000;">
                            <i class="fas fa-3x fa-sync-alt rotate360"  style="margin: 70px 45%;"></i>
                        </div>
                        <form role="form" id="frmEntry">
                            <div class="card-header">
                                <h3 class="card-title">Info</h3>
                            </div>
                            <div class="card-body" style="padding-top: 10px;">
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group row">
                                            <label class="col-md-4 col-form-label notEssential" style="text-align: right;">Registration No. :</label>
                                            <div class="col-md-8">
                                                <input type="text" class="form-control" id="txtRegistrationNo" disabled>
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label class="col-md-4 col-form-label" style="text-align: right;">Name <span style="color: red; font-size: 20px;">*</span>:</label>
                                            <div class="col-md-8">
                                                <div class="input-group mb-3" style="margin-bottom: 0px !important;">   
                                                    <div class="checkbox">
                                                        <label class="checkbox-inline"  style="padding-left: 20px;">
                                                            <input type="checkbox" data-toggle="toggle" id="chkGender" data-on="M" data-off="F" data-onstyle="success" checked>
                                                        </label>
                                                    </div>
                                                    <input type="text" class="form-control" id="txtName">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label class="col-md-4 col-form-label" style="text-align: right;">DOB <span style="color: red; font-size: 20px;">*</span>:</label>
                                            <div class="col-md-8" style="padding-right: 0px;">
                                                <select class="form-control" id="cboDays" style="padding-left: 5px; width: 30%; display: inline-block !important;"></select>
                                                <select class="form-control" id="cboMonths" style="padding-left: 5px; width: 37%; display: inline-block !important;">
                                                    <option value="">Month</option>
                                                    <option value="01">Jan</option>
                                                    <option value="02">Feb</option>
                                                    <option value="03">Mar</option>
                                                    <option value="04">Apr</option>
                                                    <option value="05">May</option>
                                                    <option value="06">Jun</option>
                                                    <option value="07">Jul</option>
                                                    <option value="08">Aug</option>
                                                    <option value="09">Sep</option>
                                                    <option value="10">Oct</option>
                                                    <option value="11">Nov</option>
                                                    <option value="12">Dec</option>
                                                </select>
                                                <select class="form-control" id="cboYears" style="padding-left: 5px; width: 30%; display: inline-block !important;"></select>
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label class="col-md-4 col-form-label" style="text-align: right;">NRC No. <span style="color: red; font-size: 20px;">*</span>:</label>
                                            <div class="col-md-8" style="padding-right: 0px;">
                                                <select class="form-control" id="cboNRCStatesDivisionsCode" style="padding-left: 5px; width: 17%; display: inline-block !important;">
                                                    <option value=""></option>
                                                    <option value="1">1</option>
                                                    <option value="2">2</option>
                                                    <option value="3">3</option>
                                                    <option value="4">4</option>
                                                    <option value="5">5</option>
                                                    <option value="6">6</option>
                                                    <option value="7">7</option>
                                                    <option value="8">8</option>
                                                    <option value="9">9</option>
                                                    <option value="10">10</option>
                                                    <option value="11">11</option>
                                                    <option value="12">12</option>
                                                    <option value="13">13</option>
                                                    <option value="14">14</option>
                                                </select>
                                                <select class="form-control" id="cboNRCTownshipCode" style="display: inline-block !important; width: 31%;">
                                                </select>
                                                <select class="form-control" id="cboNRCType" style="display: inline-block !important; width: 17%; padding-left: 5px;">
                                                    <option value=""></option>
                                                    <option value="(N)">(N)</option>
                                                    <option value="(P)">(P)</option>
                                                    <option value="(A)">(A)</option>
                                                </select>
                                                <input type="text" class="form-control" id="txtNRCNo" onkeypress="return isNumber(event);" maxlength="6" style="text-align: right; padding-left: 0px; width: 31%; display: inline-block !important;">
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label class="col-md-4 col-form-label" style="text-align: right;">Phone No. <span style="color: red; font-size: 20px;">*</span>:</label>
                                            <div class="col-md-8">
                                                <input type="text" class="form-control" id="txtPhoneNo" onkeypress="return isNumber(event);">
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label class="col-md-4 col-form-label notEssential" style="text-align: right;">Email :</label>
                                            <div class="col-md-8">
                                                <input type="text" class="form-control" id="txtEmail">
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label class="col-md-4 col-form-label" style="text-align: right;">Address <span style="color: red; font-size: 20px;">*</span>:</label>
                                            <div class="col-md-8">
                                                <textarea class="form-control" id="txtAddress" rows="3"></textarea>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-6"> 
                                        <div class="form-group row">
                                            <label class="col-md-4 col-form-label notEssential" style="text-align: right;">Register Date :</label>
                                            <div class="col-md-8">
                                                <div class="input-group input-append date" id="datePicker" data-date="2020-02-04" data-date-format="yyyy-mm-dd">
                                                    <div class="input-group-prepend">
                                                        <span class="input-group-addon input-group-text" style="width: 40px; display: table-cell;">
                                                            <i class="far fa-calendar-alt"></i>
                                                        </span>
                                                    </div>
                                                    <input type="text" class="form-control float-right" id="txtDatePicker" value="1982-06-15">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label class="col-md-4 col-form-label" style="text-align: right;">Bank Account <span style="color: red; font-size: 20px;">*</span>:</label>
                                            <div class="col-md-8">
                                                <input type="text" class="form-control" id="txtBankName" placeholder="Name">
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label class="col-md-4 col-form-label"></label>
                                            <div class="col-md-6">
                                                <input type="text" class="form-control" id="txtBankAccountNo" placeholder="Account No." onkeypress="return /[0-9a-zA-Z]/i.test(event.key)">
                                            </div>
                                            <div class="col-md-2" style="padding-left: 0px;">
                                                <button type="button" class="btn btn-success pull-right" onclick="addList();" style="width: 100%; font-size: 12px;"><i class="fa fa-plus" aria-hidden="true"></i></button>
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label class="col-md-4 col-form-label" style="text-align: right;"></label>
                                            <div class="col-md-8" id="tblBankInfo">
                                                <table class="table table-responsive-sm" id="tblBankAccountList">
                                                    <tbody></tbody>
                                                </table>
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label class="col-md-4 col-form-label notEssential" style="text-align: right;">Company :</label>
                                            <div class="col-md-8">
                                                <input type="text" class="form-control" id="txtCompany">
                                            </div>
                                        </div> 
                                        <?php if($bid==""){ ?>
                                            <div class="form-group row" style="margin-bottom: 7px;">
                                                <label class="col-md-8 col-form-label" style="text-align: right;"></label>
                                                <div class="col-md-4">
                                                    <button type="button" class="btn btn-success btn-block" onclick="validateAndSave()">Add</button>
                                                </div>
                                            </div>
                                        <?php }else {?>
                                            <div class="form-group row" style="margin-bottom: 7px;">
                                                <label class="col-md-8 col-form-label" style="text-align: right;"></label>
                                                <div class="col-md-4">
                                                    <button type="button" class="btn btn-primary btn-block" onclick="validateAndUpdate()">Update</button>
                                                </div>
                                            </div>
                                        <?php } ?>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div> 
	</section>
</div>
<?php include '../footer.php'; ?>
<script>
	var bid = '<?=$bid;?>';
    var d = new Date();
    var mm = (d.getMonth("MM")+1);
    var dd = d.getDate();
    var customDate = d.getFullYear() + "-" + ((mm<10)?"0" + mm:mm) + "-" +  ((dd<10)?"0" + dd:dd);

    $('#datePicker').attr("data-date",customDate);
    $("#txtDatePicker").val(customDate);

	$(function(){
		$("body").addClass("sidebar-collapse");  
        $('#datePicker').datepicker(); 
        fillNumbers();
        if(bid){
            getOneRow();
        }
	});

    $("#cboNRCStatesDivisionsCode").change(function(){    
        getNRCTownshipCode();
    });

    function fillNumbers(){
        $("#cboDays").find("option").remove();
        $("#cboYears").find("option").remove();
        $("#cboDays").append("<option value= ''>Day</option>");
        for (var a = 1; a <= 31; a++){
            if(a==1 || a==2 || a==3 || a==4 || a==5 || a==6 || a==7 || a==8 || a==9){
                var aa = '0' + a;
                $("#cboDays").append("<option value= '" + aa + "'>" + a + "</option>");
            }else{
                $("#cboDays").append("<option value= '" + a + "'>" + a + "</option>");
            }
        }
        var yy = d.getFullYear();
        $("#cboYears").append("<option value= ''>Year</option>");
        for (var i = yy; i >= 1920; i--){
            $("#cboYears").append("<option value= '" + i + "'>" + i + "</option>");
        }
    }  

    function getNRCTownshipCode(tc){
        var states_divisions_code = $("#cboNRCStatesDivisionsCode").val(); 
        $("#cboNRCTownshipCode").find("option").remove();
        $("#cboNRCTownshipCode").append("<option value = '' data-id = ''></option>");
        $.ajax({
            url: APP_URL + "api/nrc_code/get_nrc_by_sd_code.php",
            type: "POST",
            data: JSON.stringify({ states_divisions_code: states_divisions_code })
        }).done(function(data) {    
            $.each(data.records, function(i, v) {   
                if(v.townships_code==tc){
                    $("#cboNRCTownshipCode").append("<option value= '" + v.townships_code + "' data-id = '"+ v.id +"' selected>" + v.townships_code + "</option>");
                }else{
                    $("#cboNRCTownshipCode").append("<option value= '" + v.townships_code + "' data-id = '"+ v.id +"' >" + v.townships_code + "</option>");
                }
            });
        });
    }

    function addList(){
        if ($('#txtBankName').val()!="" && $('#txtBankAccountNo').val()!="" && !checkList($('#txtBankName').val(), $('#txtBankAccountNo').val())){
            $("#tblBankAccountList").find("tbody")
            .append($("<tr data-name='" + $("#txtBankName").val() + "' data-number='" + $("#txtBankAccountNo").val() + "'>")
                .append('<td>' + $('#txtBankName').val() + '</td>')
                .append('<td>' + $('#txtBankAccountNo').val() + '</td>') 
                .append('<td><button type="button" class="btn btn-sm btn-danger" onclick="delList(this)" style="z-index: 2; font-size: 18px; padding-top: 0px; padding-bottom: 0px; height: 26px; line-height: 26px; width: 45px;">&times;</button></td>') 
            );
            $("#txtBankName").val("");
            $("#txtBankAccountNo").val("");
        }
    }

    function checkList(name, number){
        var exist = false;
        $("#tblBankAccountList tbody tr").each(function(){
            if($(this).find("td").eq(0).text()==name && $(this).find("td").eq(1).text()==number){
                exist = true;
                return false;
            }
        });
        return exist;
    }

    function delList(obj){
        $(obj).parent().parent().remove();
    }   

    function getOneRow(){
        $.ajax({
            url: APP_URL + "api/sales/broker/get_one_row.php",
            type: "POST",
            data: JSON.stringify({ id: bid })
        }).done(function(data) {
            $("#txtRegistrationNo").val(data.registration_no);
            if(data.gender==1){
                $("#chkGender").parent().addClass("off");
            }else{
                $("#chkGender").parent().removeClass("off");
            } 
            $("#txtName").val(data.name);

            if(data.dob){
                var dob = data.dob.split('-');
                $("#cboDays").val(dob[2]);
                $("#cboMonths").val(dob[1]);
                $("#cboYears").val(dob[0]);
            }

            if(data.nrc_no){
                var nrc = data.nrc_no.split("/");
                $("#cboNRCStatesDivisionsCode").val(nrc[0]);
                var tc = nrc[1].split("(");
                getNRCTownshipCode(tc[0]);
                var type = tc[1].split(")");
                $("#cboNRCType").val("(" + type[0] + ")");
                $("#txtNRCNo").val(type[1]);
            }

            $("#txtPhoneNo").val(data.phone);
            $("#txtEmail").val(data.email);
            $("#txtAddress").val(data.address);

            $("#txtDatePicker").val(data.register_date); 
            $("#datePicker").datepicker("setDate", data.register_date);

            $.each(data.broker_bank_info, function(i, v) {
                $("#tblBankAccountList").find("tbody")
                .append($("<tr data-name='" + v.name + "' data-number='" + v.account_no + "'>")
                    .append('<td>' + v.name + '</td>')
                    .append('<td>' + v.account_no + '</td>') 
                    .append('<td><button type="button" class="btn btn-sm btn-danger" onclick="delList(this)" style="z-index: 2; font-size: 18px; padding-top: 0px; padding-bottom: 0px; height: 26px; line-height: 26px; width: 45px;">&times;</button></td>') 
                );
            });

            $("#txtCompany").val(data.company); 
        });
    }

    function validateAndSave(){
        $("#loading").css("display","block");
        var name = $("#txtName").val();
        var gender = ($("#chkGender").parent().hasClass("off"))?1:0;
        var dob = (($("#cboYears").val()!="" && $("#cboMonths").val()!="" && $("#cboDays").val())?$("#cboYears").val() + "-" + $("#cboMonths").val() + "-" + $("#cboDays").val():"");

        var nrc_no = "";
        var nrc_no_scode = (($("#cboNRCStatesDivisionsCode").val())?($("#cboNRCStatesDivisionsCode").val()):"");
        var nrc_no_tcode = (($("#cboNRCTownshipCode").val())?($("#cboNRCTownshipCode").val()):"");
        var nrc_no_type = (($("#cboNRCType").val())?($("#cboNRCType").val()):"");
        var nrc_no_seq = $("#txtNRCNo").val();
        if(nrc_no_scode!="" && nrc_no_tcode!="" && nrc_no_type!="" && nrc_no_seq!=""){
            nrc_no = nrc_no_scode + "/" + nrc_no_tcode + nrc_no_type + nrc_no_seq;
        }

        var phone = $("#txtPhoneNo").val();
        var email = $("#txtEmail").val();
        var register_date = $("#txtDatePicker").val();  
        var company = $("#txtCompany").val();
        var address = $("#txtAddress").val();

        var bankInfo = [];
        $("#tblBankAccountList tbody tr" ).each(function() {
            var detail = {
                "name": $(this).find("td").eq(0).text(),
                "account_no": $(this).find("td").eq(1).text()
            }
            bankInfo.push(detail);
        });

        if(name.trim()==""){
            bootbox.alert("Please fill name.");
            $("#loading").css("display","none");
            return false;
        }

        if($("#cboYears").val()==""){
            bootbox.alert("Please choose dob year.");
            $("#loading").css("display","none");
            return false;
        }

        if($("#cboMonths").val()==""){
            bootbox.alert("Please choose dob month.");
            $("#loading").css("display","none");
            return false;
        }

        if($("#cboDays").val()==""){
            bootbox.alert("Please choose dob day.");
            $("#loading").css("display","none");
            return false;
        }

        if($("#cboNRCStatesDivisionsCode").val()==""){
            bootbox.alert("Please choose nrc state/division code.");
            $("#loading").css("display","none");
            return false;
        }

        if($("#cboNRCTownshipCode").val()==""){
            bootbox.alert("Please choose nrc township code.");
            $("#loading").css("display","none");
            return false;
        }

        if($("#cboNRCType").val()==""){
            bootbox.alert("Please choose nrc type.");
            $("#loading").css("display","none");
            return false;
        }

        if($("#txtNRCNo").val()==""){
            bootbox.alert("Please fill nrc no.");
            $("#loading").css("display","none");
            return false;
        }

        if($("#txtPhoneNo").val()==""){
            bootbox.alert("Please fill phone no.");
            $("#loading").css("display","none");
            return false;
        }

        if(email==""){
            bootbox.alert("Please fill the email.");
            $("#loading").css("display","none");
            return false;
        }

        if(IsEmail(email)==false){
            bootbox.alert("Email format is wrong.");
            $("#loading").css("display","none");
            return false;
        }

        if(bankInfo.length==0){
            bootbox.alert("Please fill bank account.");
            $("#loading").css("display","none");
            return false;
        }

        if(address.trim()==""){
            bootbox.alert("Please fill address.");
            $("#loading").css("display","none");
            return false;
        } 

        $.ajax({
            type: "POST",
            url: APP_URL + "api/sales/broker/create.php",
            data: JSON.stringify({ name: name, gender: gender, dob: dob, nrc_no: nrc_no, phone: phone, email: email, register_date: register_date, company: company, address: address, bankInfo: bankInfo })
        }).done(function(data){
            $("#loading").css("display","none");
            if(data.message=="created"){
                bootbox.alert("Successfully Added.");
                clearForm();
            }else if(data.message=="duplicate"){
                bootbox.alert("This broker has already been registered!");
            }else{
                bootbox.alert("Error on server side.");
            }
        });
    }

    function validateAndUpdate(){
        $("#loading").css("display","block");
        var name = $("#txtName").val();
        var gender = ($("#chkGender").parent().hasClass("off"))?1:0;
        var dob = (($("#cboYears").val()!="" && $("#cboMonths").val()!="" && $("#cboDays").val())?$("#cboYears").val() + "-" + $("#cboMonths").val() + "-" + $("#cboDays").val():"");

        var nrc_no = "";
        var nrc_no_scode = (($("#cboNRCStatesDivisionsCode").val())?($("#cboNRCStatesDivisionsCode").val()):"");
        var nrc_no_tcode = (($("#cboNRCTownshipCode").val())?($("#cboNRCTownshipCode").val()):"");
        var nrc_no_type = (($("#cboNRCType").val())?($("#cboNRCType").val()):"");
        var nrc_no_seq = $("#txtNRCNo").val();
        if(nrc_no_scode!="" && nrc_no_tcode!="" && nrc_no_type!="" && nrc_no_seq!=""){
            nrc_no = nrc_no_scode + "/" + nrc_no_tcode + nrc_no_type + nrc_no_seq;
        }

        var phone = $("#txtPhoneNo").val();
        var email = $("#txtEmail").val();
        var register_date = $("#txtDatePicker").val(); 
        var company = $("#txtCompany").val();
        var address = $("#txtAddress").val();

        var bankInfo = [];
        $("#tblBankAccountList tbody tr").each(function() {
            var detail = {
                "name": $(this).find("td").eq(0).text(),
                "account_no": $(this).find("td").eq(1).text()
            }
            bankInfo.push(detail);
        });

        if(name.trim()==""){
            bootbox.alert("Please fill name.");
            $("#loading").css("display","none");
            return false;
        }

        if($("#cboYears").val()==""){
            bootbox.alert("Please choose dob year.");
            $("#loading").css("display","none");
            return false;
        }

        if($("#cboMonths").val()==""){
            bootbox.alert("Please choose dob month.");
            $("#loading").css("display","none");
            return false;
        }

        if($("#cboDays").val()==""){
            bootbox.alert("Please choose dob day.");
            $("#loading").css("display","none");
            return false;
        }

        if($("#cboNRCStatesDivisionsCode").val()==""){
            bootbox.alert("Please choose nrc state/division code.");
            $("#loading").css("display","none");
            return false;
        }

        if($("#cboNRCTownshipCode").val()==""){
            bootbox.alert("Please choose nrc township code.");
            $("#loading").css("display","none");
            return false;
        }

        if($("#cboNRCType").val()==""){
            bootbox.alert("Please choose nrc type.");
            $("#loading").css("display","none");
            return false;
        }

        if($("#txtNRCNo").val()==""){
            bootbox.alert("Please fill nrc no.");
            $("#loading").css("display","none");
            return false;
        }

        if(email==""){
            bootbox.alert("Please fill the email.");
            $("#loading").css("display","none");
            return false;
        }

        if(IsEmail(email)==false){
            bootbox.alert("Email info. is wrong.");
            $("#loading").css("display","none");
            return false;
        }

        if(bankInfo.length==0){
            bootbox.alert("Please fill bank account.");
            $("#loading").css("display","none");
            return false;
        }

        if(address.trim()==""){
            bootbox.alert("Please fill address.");
            $("#loading").css("display","none");
            return false;
        }

        $.ajax({
            type: "POST",
            url: APP_URL + "api/sales/broker/update.php",
            data: JSON.stringify({ id: bid, name: name, gender: gender, dob: dob, nrc_no: nrc_no, phone: phone, email: email, register_date: register_date, company: company, address: address, bankInfo: bankInfo })
        }).done(function(data){
            $("#loading").css("display","none");
            if(data.message=="updated"){
                bootbox.alert("Successfully Updated.");
                document.location = APP_URL + "sales/broker.php";
            }else{
                bootbox.alert("Error on server side.");
            }
        });
    }

    function clearForm(){
        $("#txtName").val("");
        $("#chkGender").parent().removeClass("off");
        $("#cboDays").val("");
        $("#cboMonths").val("");
        $("#cboYears").val("");
        $("#cboNRCStatesDivisionsCode").val("");
        $("#cboNRCTownshipCode").find("option").remove();
        $("#cboNRCType").val("");
        $("#txtNRCNo").val("");
        $("#txtPhoneNo").val("");
        $("#txtEmail").val("");
        $("#txtDatePicker").val(customDate);
        $("#datePicker").datepicker("setDate", customDate);
        $("#txtBankName").val("");
        $("#txtBankAccountNo").val("");
        $("#tblBankAccountList").find("tbody").find("tr").remove();
        $("#txtCompany").val("");
        $("#txtAddress").val("");
    }

    function btozero(obj){
        if($(obj).val() == "" || $(obj).val() == "0")$(obj).val(0);
    }

    function isNumber(evt) {
        evt = (evt) ? evt : window.event;
        var charCode = (evt.which) ? evt.which : evt.keyCode;
        if ( (charCode > 31 && charCode < 48) || charCode > 57) {
            return false;
        }
        return true;
    } 

    function IsEmail(email) {
        var regex = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
        if(!regex.test(email)) {
             return false;
        }else{
             return true;
        }
    }
</script>   