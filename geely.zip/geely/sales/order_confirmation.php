<?php include '../header.php'; ?>
<?php
	$oc_no = "";
	if(isset($_GET['oc_no'])){
		if(!empty($_GET['oc_no'])){
			$oc_no = $_GET['oc_no'];
		}
	}
?>

<style>
	.col-form-label{
		padding-top: 4px !important;
	} 
	.toggle{
		min-height: 31px !important;
	}
	.content-wrapper{
		line-height: 6px !important;
	}

	.toggle-group{
		width: 203% !important;
	}
</style>

<div class="content-wrapper" style="min-height: 1203.6px;"> 
	<section class="content-header">
		<div class="container-fluid">
			<div class="row">
				<div class="col-md-12">
					<h1 style="text-align: center;">Order Confirmation</h1>
				</div>
			</div>
		</div>
	</section>
	<section class="content">
		<div class="container-fluid">
			<div class="row">
				<div class="col-md-12">
					<div class="card card-outline card-primary">
						<div class="card-header">
							<div class="card-tools">
								<button type="button" class="btn btn-tool" data-card-widget="collapse"><i class="fas fa-minus"></i></button>
								<button type="button" class="btn btn-tool" data-card-widget="remove"><i class="fas fa-remove"></i></button>
							</div> 
						</div> 
						<div class="card-body">
							<div class="row">
								<div class="col-md-8" style="padding-top: 5px;">
									<table class="table" id="myTable1" style="margin-bottom: 0px; border: 1px solid #dee2e6;">
										<thead>
											<tr style="background-color: #7faad3;">
											    <th colspan="2" style="font-size: 15px; text-align: center;">Buyer Information</th>
											</tr>
											<tr>
												<td style="width: 31%;">Attendion To <span style="float:right;">:</span></td>
												<td  id="txtCustomerName"></td>
											</tr>
											<tr>
												<td style="width: 31%;">NRC No. <span style="float:right;">:</span></td>
												<td  id="txtNRCNO"></td>
											</tr>
											<tr style="line-height: 16px !important;">
												<td style="width: 31%;">Address <span style="float:right;">:</span></td>
												<td id="txtAddress"></td>
											</tr>
											<tr>
												<td style="width: 31%;">Email <span style="float:right;">:</span></td>
												<td id="txtEmail"></td>
											</tr>
											<tr>
												<td style="width: 31%;">Contact Number <span style="float:right;">:</span></td>
												<td id="txtContactNumber"></td>
											</tr>
										</thead>
										<tbody></tbody>
									</table>
								</div>
								<div class="col-md-4" style="padding-top: 5px;">
									<table class="table table-bordered" id="myTable2" style="margin-bottom: 0px; border: 1px solid #000;">
										<thead>
											<tr>
												<td style="width: 10%;font-weight: bold;">Reference</td>
												<td id="txtReferenceNo"></td>
											</tr>
											<tr>
												<td style="width: 10%;">O.C No.</td>
												<td id="txtOrderConfirmationNo"></td>
											</tr>
											<tr>
												<td style="width: 10%;">Date</td>
												<td id="txtOrderDate"></td>
											</tr>
											<tr>
												<td style="width: 10%;">Updated</td>
												<td id="txtUpdatedDate"></td>
											</tr>
										</thead>
										<tbody></tbody>
									</table>
									<table class="table table-bordered" id="myTableSE" style="margin-bottom: 0px; border: 1px solid #000; margin-top: 6px;">
										<thead>
											<tr>
												<td style="font-weight: bold;">Sales Executive:</td>
											</tr>
											<tr>
												<td id="txtSalesExecutive" style="background-color: #ccd8e4;"></td>
											</tr>
										</thead>
										<tbody></tbody>
									</table>
								</div>
							</div>
							<div class="row" style="padding-top: 9px;">
								<div class="col-md-12">
									<table class="table table-bordered" id="myTable3" style="margin-bottom: 0px;">
										<thead>
											<tr style="background-color: #7faad3;">
											    <th style="font-size: 13px; text-align: center;">No.</th>
											    <th style="font-size: 13px; text-align: center; line-height: 1.42857143 !important;">Product Description</th>
											    <th style="font-size: 13px; padding-left: 0px; padding-right: 0px; text-align: center; line-height: 1.42857143 !important;">Unit Price (MMK)</th>
											    <th style="font-size: 13px; padding-left: 0px; padding-right: 0px; text-align: center; line-height: 1.42857143 !important;">No. of Unit</th>
											    <th style="font-size: 13px; padding-left: 0px; padding-right: 0px; text-align: center; width: 15%; line-height: 1.42857143 !important;">Total Price (MMK)</th>
											</tr> 
										</thead>
										<tbody>
											<tr>
												<td rowspan="15" style="vertical-align: middle; text-align: center;">1</td>
												<td>
													<div style="width: 40%; display: inline-block;">Brand Name</div>
													<div style="width: 3%; display: inline-block;">:</div>
													<div style="width: 45%; display: inline-block;" id="txtBrandName"></div>
												</td>
												<td rowspan="9" style="vertical-align: middle; text-align: right;" id="txtUnitPrice">0</td>
												<td rowspan="9" style="vertical-align: middle; text-align: right;" id="txtNoOfUnit">1</td>
												<td rowspan="9" style="vertical-align: middle; text-align: right;" id="txtTotalPrice">0</td>
											</tr>
											<tr>
												<td>
													<div style="width: 40%; display: inline-block;">Model Name</div>
													<div style="width: 3%; display: inline-block;">:</div>
													<div style="width: 45%; display: inline-block;" id="txtModelName"></div>
												</td>
											</tr>
											<tr>
												<td>
													<div style="width: 40%; display: inline-block;">VIN No.</div>
													<div style="width: 3%; display: inline-block;">:</div>
													<div style="width: 45%; display: inline-block;" id="txtProductVin"></div>
												</td>
											</tr>
											<tr>
												<td>
													<div style="width: 40%; display: inline-block;">Drive</div>
													<div style="width: 3%; display: inline-block;">:</div>
													<div style="width: 45%; display: inline-block;" id="txtDrive"></div>
												</td>
											</tr>
											<tr>
												<td>
													<div style="width: 40%; display: inline-block;">Grade</div>
													<div style="width: 3%; display: inline-block;">:</div>
													<div style="width: 45%; display: inline-block;" id="txtGrade"></div>
												</td>
											</tr>
											<tr>
												<td>
													<div style="width: 40%; display: inline-block;">Model Year</div>
													<div style="width: 3%; display: inline-block;">:</div>
													<div style="width: 45%; display: inline-block;" id="txtModelYear"></div>
												</td>
											</tr>
											<tr>
												<td>
													<div style="width: 40%; display: inline-block;">Engine Power</div>
													<div style="width: 3%; display: inline-block;">:</div>
													<div style="width: 45%; display: inline-block;" id="txtEnginePower"></div>
												</td>
											</tr>
											<tr>
												<td>
													<div style="width: 40%; display: inline-block;">Body Color</div>
													<div style="width: 3%; display: inline-block;">:</div>
													<div style="width: 45%; display: inline-block;" id="txtBodyColor"></div>
												</td>
											</tr>
											<tr>
												<td>
													<div style="width: 40%; display: inline-block;">Lot No.</div>
													<div style="width: 3%; display: inline-block;">:</div>
													<div style="width: 45%; display: inline-block;" id="txtLotNo"></div>
												</td>
											</tr>
											<tr>
												<td colspan="3" style="text-align: right; font-weight: bold;background-color: #f5eeca;">Commercial Tax </td>
												<td style="text-align: right; font-weight: bold;" id="txtCommercialTax">0</td>
											</tr>
											<tr style="background-color: #ccd8e4;">
												<td colspan="3" style="text-align: right; font-weight: bold;">Retail Price </td>
												<td style="text-align: right; font-weight: bold;" id="txtRetailPrice">0</td>
											</tr>
											<tr>
												<td colspan="3" style="text-align: right; font-weight: bold;">Registration Tax & Fees </td>
												<td style="text-align: right; font-weight: bold;" id="txtRegistrationTaxFees">0</td>
											</tr>
											<tr>
												<td colspan="3" style="text-align: right; font-weight: bold;">Total Price </td>
												<td style="text-align: right; font-weight: bold;" id="txtTotalPriceC">0</td>
											</tr>
											<tr>
												<td colspan="3" style="text-align: right; font-weight: bold;">Promotion </td>
												<td style="text-align: right; font-weight: bold;" id="txtPromotion">0</td>
											</tr>
											<tr style="background-color: #7faad3;line-height: 1.42857143;">
												<td colspan="3" style="text-align: right; font-weight: bold;">Selling Price </td>
												<td style="text-align: right; font-weight: bold;" id="txtSellingPrice">0</td>
											</tr>
											<tr>
												<td colspan="2" style="text-align: right; padding-right: 15px; vertical-align: middle;">
													<div>Payment Method:</div>
												</td>
												<td><input type="checkbox" id="chkCash" value="Cash" onclick="return false;"> Cash</td>
												<td><input type="checkbox" id="chkHP" value="Finance" onclick="return false;"> Finance</td>
											</tr>
											<tr>
												<td></td>
												<td style="text-align: right; padding-right: 15px;">
													<div>1st Deposit Amount:</div>
												</td>
												<td style="background-color: #ccd8e4; text-align: right;" id="txtpayment1ExchangeRate"></td>
												<td style="text-align: right;" id="txtDepositAmountUSD"></td>
												<td style="background-color: #d6d4d4; text-align: right;" id="txtDepositAmountMMK">0</td>
											</tr>
											<tr>
												<td></td>
												<td style="text-align: right; padding-right: 15px;">
													<div>2nd Payment Amount:</div>
												</td>
												<td style="background-color: #ccd8e4; text-align: right;" id="txtpayment2ExchangeRate"></td>
												<td style="text-align: right;" id="txtSecondPaymentAmountUSD"></td>
												<td style="background-color: #ccd8e4; text-align: right;" id="txtSecondPaymentAmountMMK">0</td>
											</tr>
											<tr>
												<td></td>
												<td style="text-align: right; padding-right: 15px;">
													<div>Final Payment Amount:</div>
												</td>
												<td style="background-color: #ccd8e4; text-align: right;" id="txtpayment2ExchangeRate"></td>
												<td style="text-align: right;" id="txtFinalPaymentAmountUSD"></td>
												<td style="background-color: #d6d4d4; text-align: right;" id="txtFinalPaymentAmountMMK">0</td>
											</tr>
											<tr>
												<td></td>
												<td style="text-align: right; padding-right: 15px;">
													<div>Total Paid:</div>
												</td>
												<td colspan="2" style="text-align: right;" id="txtTotalPaidUSD">-</td>
												<td style="text-align: right;" id="txtTotalPaidMMK">0</td>
											</tr>
											<tr>
												<td></td>
												<td style="text-align: right; padding-right: 15px; font-weight: bold;">
													<div>Balance to Pay:</div>
												</td>
												<td colspan="2" style="text-align: right; background-color: #7faad3; font-weight: bold;">$ <span id="txtBalanceToPayUSD">0</span></td>
												<td style="text-align: right; background-color: #7faad3; font-weight: bold;" id="txtBalance"><span id="txtBalanceToPayMMK">0</span></td>
											</tr>
										</tbody>
									</table>
								</div>
							</div>
							<div class="row" style="padding-top: 15px;">
								<div class="col-md-12" style="opacity: 0.4;">
									<p style="margin-bottom: 5px; font-style: italic; font-weight: bold;">Following cost are buyer's responsibility and is not included in the Vehicle price</p>
									<table class="table table-bordered" id="myTable6" style="margin-bottom:0px;border: 1px solid #000;">
										<thead>
											<tr>
												<td style="text-align: right;">Estimate Income Tax:</td>
												<td id="txtEstimateIncomeTax"></td>
												<td>Mandatory (according per Income Tax policy)</td>
											</tr>
											<tr>
												<td style="text-align: right;">Insurance:</td>
												<td>1% on total vehicle price</td>
												<td>If needed</td>
											</tr>
										</thead>
										<tbody></tbody>
									</table>
								</div>
							</div>
							<div class="row" style="padding-top: 9px;">
								<div class="col-md-8">
									<table class="table" id="myTableRTAD" style="margin-bottom: 0px; border: 1px solid #dee2e6;">
										<thead>
											<tr style="background-color: #7faad3;">
											    <th colspan="2" style="font-size: 15px; text-align: center;">RTAD Register Information</th>
											</tr>
											<tr>
												<td>Sames as buyer <input type="checkbox" id="chkSameAsBuyer" onclick="return false;"></td>
												<td></td>
											</tr>
											<tr>
												<td style="width: 31%;">Name <span style="float: right;">:</span></td>
												<td id="txtRTADName" style="padding-right: 100px;"></td>
											</tr>
											<tr>
												<td style="width: 31%;">NRC No. <span style="float: right;">:</span></td>
												<td  id="txtRTADNRCNo" style="padding-right: 100px;"></td>
											</tr>
											<tr>
												<td style="width: 31%;">Contact No. <span style="float: right;">:</span></td>
												<td id="txtRTADContactNo" style="padding-right: 100px;"></td>
											</tr>
											<tr>
												<td style="width: 31%;">Address <span style="float: right;">:</span></td>
												<td id="txtRTADAddress" style="padding-right: 100px;"></td>
											</tr>
										</thead>
										<tbody></tbody>
									</table>
								</div>
								<div class="col-md-4">
									<table class="table table-bordered" id="myTable4" style="margin-bottom: 0px; border: 1px solid #000;">
										<thead>
											<tr>
												<td>Reference</td>
												<td id="txtReference"></td>
											</tr>
											<tr>
												<td>VIN No.</td>
												<td id="txtVinNo"></td>
											</tr>
										</thead>
										<tbody></tbody>
									</table>
								</div>
							</div>
							<div class="row" style="padding-top: 9px;">
								<div class="col-md-12">
									<table class="table table-bordered" id="myTable5" style="margin-bottom: 0px;">
										<thead>
											<tr>
											    <th colspan="2" style="font-size: 14px; text-align: center; line-height: 1.42857143 !important; background-color: #7faad3;">Terms and Condition of Vehicle Order</th>
											</tr>
											<tr style="font-size: 14px; line-height: 1.42857143 !important;">
												<td style="width: 16%;">Sales Term</td>
												<td>
													<p>
														<span style="width: 2%; float: left;">:</span>
														<span style="width: 98%; display: inline-block;">Prices are included Custom Duty, Commercial Tax and RTAD tax.</span>
													</p>
													<p>
														<span style="width: 2%; float: left;">:</span>
														<span style="width: 98%; display: inline-block;">Income Tax and Commercial Insurance is the Buyer's responsibility and is not included in the vehicle price.</span>
													</p>
													<p>
														<span style="width: 2%; float: left;">:</span>
														<span style="width: 98%; display: inline-block;">If the buyer required Yangon license and needed  PAL' service, the cost (which should use latest of market price) will be add in vehicle price as an additionally. Or if buyer will handle by him/herself, the Yangon license should provide to PAL within a reasonable time to proceed RTA register in time.</span>
													</p>
													<p>
														<span style="width: 2%; float: left;">:</span>
														<span style="width: 98%; display: inline-block;">Vehicle Registration will be processed on behalf of the Buyer by Premier Automotive Ltd as the Buyer's request.</span>
													</p>
												</td>
											</tr>
											<tr style="font-size: 14px; line-height: 1.42857143 !important;">
												<td style="width: 16%;">Payment Term </td>
												<td>
													<p>
														<span style="width: 2%; float: left;">:</span>
														<span style="width: 98%; display: inline-block;">50% upon sales contract, 50% before RTA registration</span>
													</p>
													<p>
														<span style="width: 2%; float: left;">:</span>
														<span style="width: 98%; display: inline-block;">All prices are based on a USD value that will be converted to MMK at the exchange rate on date/s of the signing this order or payment and the invoices will be in MMK.</span>
													</p>
													<p>
														<span style="width: 2%; float: left;">:</span>
														<span style="width: 98%; display: inline-block;">Customers using Hire Purchase agreements and any other forms of Bank Financing where the bank pays Premier Automotive the vehicle price, are required to pay PAL prior to delivery,  the difference between the payment from the finance company at the exchange rate applied in the financing agreement and the Vehicle Price calculated using the PAL' Exchange Rate on the date of delivery.In the event of an exchange rate reduction, PAL will refund the Buyer the difference between the exchange rates.</span>
													</p>
												</td>
											</tr>
											<tr style="font-size: 14px; line-height: 1.42857143 !important;">
												<td style="width: 16%;">Delivery</td>
												<td>
													<p>
														<span style="width: 2%; float: left;">:</span>
														<span style="width: 98%; display: inline-block;">Vehicle delivery to the Buyer will only take place after full payment for the vehicle is received in Premier Automotive' bank account.</span>
													</p>
												</td>
											</tr>
											<tr style="font-size: 14px; line-height: 1.42857143 !important;">
												<td style="width: 16%;">Warranty</td>
												<td>
													<p>
														<span style="width: 2%; float: left;">:</span>
														<span style="width: 98%; display: inline-block;">5 years (or) 150,000 km after delivery date whichever comes first depend on Manufacture’s standard warranty terms & conditions.</span>
													</p>
												</td>
											</tr>
											<tr style="font-size: 14px; line-height: 1.42857143 !important;">
												<td style="width: 16%;">Cancellation</td>
												<td>
													<p>
														<span style="width: 2%; float: left;">:</span>
														<span style="width: 98%; display: inline-block;">If Premier Automotive didn't received full payment in within 30 days of signing this Vehicle Order, the order will be cancel automotivelly.</span>
													</p>
													<p>
														<span style="width: 2%; float: left;">:</span>
														<span style="width: 98%; display: inline-block;">If the buyer cancels the motor vehicle sales agreement on any cause, it is known and accepted, the seller shall not return the advance deposit as compensation.</span>
													</p>
												</td>
											</tr>
											<tr style="font-size: 14px; line-height: 1.42857143 !important;">
												<td style="width: 16%;">Remark</td>
												<td>
													<p>
														<span style="width: 2%; float: left;">:</span>
														<span style="width: 98%; display: inline-block;">Premier Automotive Ltd reserves the unconditional right to revise this Vehicle Order, and the Buyer unconditionally agrees, that any future increases in tax rates on Customs Duty, Commercial Tax, Special Goods Tax, Registration fees, and/or any new or additional taxes,processing fees or other charges imposed by Government Regulation on the importation and trading in motor vehicles, will be borne solely by the Buyer. In the case that the tax amount of a vehicle reduces, Premier Automotive Ltd will refund the reduction in amount to the Buyer.</span>
													</p>
												</td>
											</tr>
										</thead>
									</table>
								</div>
							</div>
						</div> 
					</div>
				</div>
				<div class="col-md-12">
					<div class="card card-outline card-primary">
						<div class="card-header">
							<h3 class="card-title">Customer Signature</h3>
							<button type="button" class="btn btn-primary btn-sm" onclick="goToPrint(this);" style='min-width: 44px;float: right;margin-right: 8px;' title="Order Confirmation Print">Order Confirmation Print <i class="fa fa-solid fa-print"></i></button>
						</div>
						<div class="overlay white" id="loading" style="display: none; position: absolute; width: 100%; height: 100%; z-index: 1000;">
							<i class="fas fa-3x fa-sync-alt rotate360" style="margin: 70px 45%;"></i>
						</div>
						<div class="card-body" style="padding-left: 80px; padding-right: 80px;">
							<div class="row">
								<div class="col-md-1">
									<div class="input-group mb-6" style="margin-bottom: 0px !important;">	
										<div class="checkbox">
											<label class="checkbox-inline"  style="padding-left: 20px;">
												<input type="checkbox" data-toggle="toggle" id="chkSignagure" data-on="Sign" data-off="Upload" data-onstyle="success" data-offstyle="primary" checked>
											</label>
										</div>
									</div>
								</div>
								<div class="col-md-2" style="display:none;" id="uPLOAD">
									<span class="input-group-btn"><input type="file" accept="application/pdf" class="signUpload" id="OID' + dataVal[0] + '" data-id="' + dataVal[0] + '" name="file" hidden /><label class="btn btn-success" for="OID' + dataVal[0] + '" title="Signature Upload" style="margin-bottom: 0px; cursor: pointer; padding: 4px 8px; font-size: 14px; font-weight: normal;float: right;">Signature Upload <i class="fa fa-solid fa-upload"></i></label></span>
								</div>
							</div>
							<div class="row" style="display:none;" id="sIGN">
								<div class="col-md-4 col-sm-6">
									<div class="form-group row" id="drawSignature">
										<div class="sigPad" id="smoothed" style="width:404px;">
											<ul class="sigNav">
												<li class="drawIt"><a href="#draw-it" >Draw It</a></li>
												<li class="clearButton"><button type="button">Clear</button></li>
											</ul>
										<div class="sig sigWrapper" style="height:auto;">
											<div class="typed"></div>
											<canvas class="pad" width="400" height="250" id="canvas"></canvas>
											<img src="" id="img">
											<input type="hidden" name="output-2" class="output">
										</div>
										</div>
									</div>
									<div class="form-group row">
										<button type="button" class="btn btn-success" onclick="validateAndSave()" style="padding-left: 25px; padding-right: 25px;" id="btnConfirm">Confirm</button>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
</div> 
<?php include '../footer.php'; ?> 
<script>
	var oc_no = '<?=$oc_no;?>';

	$(function () {
		$("body").addClass("sidebar-collapse");

		$('#smoothed').signaturePad({
			drawOnly:true,
			lineTop:200,
			lineColour : '#fff'
		});

		if(oc_no){
			getOneOrder();
		}

		//wppp
		if(!$("#chkSignagure").parent().hasClass("off")){
			$("#uPLOAD").css("display","none");
			$("#sIGN").css("display","block");
		}else{
			$("#uPLOAD").css("display","block");
			$("#sIGN").css("display","none");
		}
		//wppp
	});	

	//wppp

	$("#chkSignagure").change(function(){
		if(!$(this).parent().hasClass("off")){
			$("#uPLOAD").css("display","none");
			$("#sIGN").css("display","block");
		}else{
			$("#uPLOAD").css("display","block");
			$("#sIGN").css("display","none");
		}
	});

	function goToPrint(){
	    window.open(APP_URL + "print/order_confirmation_print.php?act=print&oc_no=" + oc_no);
	} 

	$(document).on('change', ".signUpload", function(){
	    uploadOCSign(this);
	});

	function uploadOCSign(obj){
	    var property = document.getElementById($(obj).attr("id")).files[0];
	    var file_name = property.name;
	    var file_extension = file_name.split(".").pop().toLowerCase();
	    
	    if(property.type!="application/pdf"){
	        bootbox.alert("Invalid File");
	    }else{
	        var file_size = parseInt(property.size/1000000);//convert bytes to mb
	        if(file_size>25){
	            bootbox.alert("Exceed File Size.");
	        }else{
	            $("#loading").css("display", "block");
	            var form_data = new FormData();
	            form_data.append($(obj).attr("name"), property);

	            $.ajax({
	                url: APP_URL + "api/sales/sales/upload_oc_signature_pdf.php?oc_no=" + oc_no,
	                type: "POST",
	                data: form_data,
	                contentType: false,
	                cache: false,
	                processData: false,
	                success:function(data){
	                    $("#loading").css("display", "none");
	                }
	            });
	            alert("Signature Upload Complete");
	        }
	        document.location = APP_URL + "sales/sales_list.php";
	    }
	}

	//wppp

	function getOneOrder(){
		$("#myTable").find("tbody").find("tr").remove();
		$.ajax({
			url: APP_URL + "api/sales/order/get_one_order_confirm.php",
			type: "POST",
			data: JSON.stringify({ oc_no: oc_no })
		}).done(function(data) {	
			$("#txtCustomerName").text(data.customer_name);
			$("#txtNRCNO").text(data.nrc_no);
			$("#txtAddress").text(data.address);
			$("#txtEmail").text(data.email);
			$("#txtContactNumber").text(data.mobile_no);

			$("#txtOrderConfirmationNo").text(data.oc_no);	
			$("#txtOrderDate").text(data.date); 
			$("#txtSalesExecutive").text(data.staff_name);

			$("#txtBrandName").text(data.brand);
			$("#txtModelName").text(data.model_name);
			$("#txtProductVin").text(data.vin_no); 
			$("#txtGrade").text(data.grade);
			$("#txtModelYear").text(data.model_year);
			$("#txtEnginePower").text(data.engine_no);
			$("#txtBodyColor").text(data.exterior_color);

			$("#txtUnitPrice").text(data.vehicle_price);
			$("#txtTotalPrice").text(data.vehicle_price);
			$("#txtCommercialTax ").text(data.commercial_tax);
			$("#txtRetailPrice").text(data.retail_price);

			$("#txtRegistrationTaxFees").text(data.rtad_tax);
			$("#txtTotalPriceC").text(data.total_price_c);
			$("#txtPromotion").text(data.promotion_discount);
			$("#txtSellingPrice").text(data.selling_price);

			if(data.payment_type=="Cash"){
				$("#chkCash").prop("checked", true);
				$("#chkHP").prop("checked", false);
			}else{
				$("#chkCash").prop("checked", false);
				$("#chkHP").prop("checked", true);
			}

			if(data.same_as_buyer==1){
				$("#chkSameAsBuyer").prop("checked", true);
			}else{
				$("#chkSameAsBuyer").prop("checked", false);
			}

			// $("#txtDepositAmountMMK").text(data.deposit); 

			$("#txtRTADName").text(data.rtad_name);
			$("#txtRTADNRCNo").text(data.rtad_nrc_no);
			$("#txtRTADContactNo").text(data.rtad_mobile_no);
			$("#txtRTADAddress").text(data.rtad_township);

			$("#txtReference").text(data.oc_no);
			$("#txtVinNo").text(data.vin_no);
		});
	} 

	function validateAndSave(){  

		if($(".output").val()==""){
			bootbox.alert("Please sign signature.");
		}else{
			var img = document.querySelector("#img");
	        var canvas = document.getElementById('canvas');
	        canvas.getContext("2d");
	        img.src = canvas.toDataURL("image/webp");

        	$("canvas").remove();
			var signature = $("#img").attr("src");
			
			$("#loading").css("display","block"); 
			$.ajax({
				url: APP_URL + "api/sales/sales/create_customer_signature.php",
				type: "POST",
				data: JSON.stringify({ oc_no: oc_no, signature: signature })
			}).done(function(data){	
				$("#loading").css("display","none");
				if(data.message=="updated"){	 
					bootbox.confirm({
						message: "<h4>Successfully signature upload. Do you want to print order confirmation?</h4>",
						buttons: {
							cancel: {
								label: '<span class="glyphicon glyphicon-ok"></span> No',
								className: 'btn-danger'
							},
							confirm: {
								label: '<span class="glyphicon glyphicon-ok"></span> Yes',
								className: 'btn-primary'
							}
						},
						callback: function (result) {
							if(result){
								document.location = APP_URL + "print/order_confirmation_print.php?oc_no=" + oc_no; 
							}else{
								document.location = APP_URL + "sales/sales_list.php";
							}
						}
					});
				}else if(data.message=="session expire"){
					bootbox.alert("Session Expire! Please refresh the browser and login again.");
				}else{
					bootbox.alert("Error on server side.");
				}
			});
		}   
	}
</script>