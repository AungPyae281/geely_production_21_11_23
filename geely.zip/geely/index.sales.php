<?php include 'header.php'; ?>   
<div class="content-wrapper">
	<div class="content-header">
		<h3>Dashboard</h3>
	</div>
	<section class="content">
		<div class="container-fluid">
		</div>
	</section>
</div>	

<?php if($_SESSION['position']=="Sales Executive" && $_SESSION["sales_center"]==""){ ?>
<div class="card" id="ChooseShowroomCampaign" style="position: fixed; height: 100%; width: 100%; top: 55px; z-index: 5000; margin-bottom: 0px !important; background-image: url('<?=$app_url?>img/bg_img.png'); background-position: center center; background-repeat: no-repeat; background-size: 50%;">
	<div class="card-body login-card-body" style="padding-top: 50px; margin: 0 auto; background-color: transparent;">	
		<div style="display: inline-block;">
			<select class="form-control" id="cboSalesCenter" style="width: 400px; padding-top: 1px;"></select>
			<button type="button" class="btn btn-primary btn-block" style="margin-top: 15px;" onclick="gotoIndex();">Enter</button>
		</div>
	</div>
</div>
<?php } ?>

<?php include 'footer.php'; ?>

<script>
	$(function() {
		// $("body").addClass("sidebar-collapse"); 
		fillSalesCenter();
	});	  

	function fillSalesCenter(){
		$("#cboSalesCenter").find("option").remove(); 
		$.ajax({
			url: APP_URL + "api/sales/staff_sales_center/get_all_rows_by_staff.php"
		}).done(function(data) {
			$.each(data.records, function(i, v) { 
				$("#cboSalesCenter").append("<option value='" + v.sales_center + "'>" + v.sales_center + "</option>");		
			});
		});
	}

	function gotoIndex(){
		var sales_center = $("#cboSalesCenter").val();

		if(sales_center){ 
			$.ajax({
				url: APP_URL + "set_session_sales_center.php?sales_center=" + $("#cboSalesCenter").val()
			}).done(function(data) {
				if(data=="ok"){
					$("#ChooseShowroomCampaign").css("display", "none");
				}
			});	
		}else{
			alert('Please choose showroom!');
		}
	}
</script>