<?php include '../header.php'; ?>
<style>
    .form-group{
        margin-bottom: 5px !important;
    }
    .col-form-label{
        padding-top: 5px !important;
        padding-bottom: 2px !important;
    }
</style>

<div class="content-wrapper" style="min-height: 1203.6px;"> 
	<section class="content-header">
		<div class="container-fluid">
			<div class="row mb-2">
				<div class="col-md-6">
					<h1>Promotion - Entry</h1>
				</div>
				<div class="col-md-6"></div>
			</div>
		</div>
	</section> 
	<section class="content"> 
        <div class="container-fluid">
			<div class="row">
				<div class="col-md-12">
                    <div class="card card-outline card-primary">
                        <div class="overlay white" id="loading" style="display: none; position: absolute; width: 100%; height: 100%; z-index: 1000;">
                            <i class="fas fa-3x fa-sync-alt rotate360"  style="margin: 70px 45%;"></i>
                        </div>
                        <form role="form" id="frmEntry">
                            <div class="card-header">
                                <h3 class="card-title">Info</h3>
                            </div>
                            <div class="card-body" style="padding-top: 10px;">
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group row">
                                            <label class="col-md-4 col-form-label" style="text-align: right;">Date From: </label>
                                            <div class="col-md-8">  
                                                <div class="input-group input-append date" id="datePicker1" data-date="2020-02-07" data-date-format="yyyy-mm-dd">
                                                    <div class="input-group-prepend">
                                                        <span class="input-group-addon input-group-text" style="width: 40px; display: table-cell;">
                                                            <i class="far fa-calendar-alt"></i>
                                                        </span>
                                                    </div>
                                                    <input type="text" class="form-control float-right" id="txtDatePicker1" value="1982-06-15">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label class="col-md-4 col-form-label" style="text-align: right;">Date To: </label>
                                            <div class="col-md-8">  
                                                <div class="input-group input-append date" id="datePicker2" data-date="2020-02-07" data-date-format="yyyy-mm-dd">
                                                    <div class="input-group-prepend">
                                                        <span class="input-group-addon input-group-text" style="width: 40px; display: table-cell;">
                                                            <i class="far fa-calendar-alt"></i>
                                                        </span>
                                                    </div>
                                                    <input type="text" class="form-control float-right" id="txtDatePicker2" value="1982-06-15">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label class="col-md-4 col-form-label" style="text-align: right;">Code :</label>
                                            <div class="col-md-8">
                                                <input type="text" class="form-control" id="txtPromotionCode">
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label class="col-md-4 col-form-label" style="text-align: right;">Name :</label>
                                            <div class="col-md-8">
                                                <input type="text" class="form-control" id="txtPromotionName">
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label class="col-md-4 col-form-label" style="text-align: right;">Discount :</label>
                                            <div class="col-md-8">
                                                <input type="text" class="form-control" id="txtPromotionDiscount" onkeypress="return isNumber(event)" onkeyup="btozero(this);AddComma(this);" value="0" style="text-align:right;" maxlength="8" value="0">
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label class="col-md-4 col-form-label" style="text-align: right;">Terms & Conditions :</label>
                                            <div class="col-md-8">
                                                <textarea class="form-control" id="txtTermsNConditions" rows="2"></textarea>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group row">
                                            <label class="col-md-4 col-form-label" style="text-align: right;">Signature: </label>
                                            <div class="col-md-8">
                                                <input style="display:none" name="file" id="input-image-hidden" onchange="document.getElementById('previewing').src = window.URL.createObjectURL(this.files[0])" type="file" accept="image/jpeg, image/png" >
                                                <img id="previewing" name="previewing" src="<?=$app_url;?>img/no_image.jpg" style="height:180px; width:auto;cursor:pointer;border: 1px solid #d4d9de;"onclick="HandleBrowseClick('input-image-hidden');" title="Click to Change the Photo.">
                                            </div>
                                        </div>
                                        <div class="form-group row" style="margin-bottom: 7px;">
                                            <label class="col-md-4 col-form-label" style="text-align: right;"></label>                                            
                                            <div class="col-md-4 btnSubmit">
                                                <button type="button" class="btn btn-success" id="btnSubmit" style="width: 180px;">Add</button>
                                            </div>
                                            <div class="col-md-2 btnEdit" style="display: none;">
                                                <button type="button" class="btn btn-danger btn-block" onclick="clearForm()"  style="width: 90px;">Cancel</button>
                                            </div>
                                            <div class="col-md-2 btnEdit" style="display: none;">
                                                <button type="button" class="btn btn-primary btn-block" id="btnUpdate" style="width: 90px;">Update</button>
                                            </div>
                                            <div class="col-md-4"></div>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
                <div class="col-md-12">
                    <div class="card card-outline card-primary">
                        <div class="card-header">
                            <h3 class="card-title">Promotion List <span id="total_records" style="font-weight:bold;"></span></h3>
                            <div class="card-tools">
                                <button type="button" class="btn btn-tool" data-card-widget="collapse"><i class="fas fa-minus"></i></button>
                                <button type="button" class="btn btn-tool" data-card-widget="remove"><i class="fas fa-remove"></i></button>
                            </div>
                        </div>
                        <div class="card-body p-0">
                            <table class="table table-responsive table-head-fixed table-striped table-bordered" id="myTable" style="max-height: 450px;">
                                <thead>                  
                                    <tr>
                                        <th style="width: 3%">#</th>
                                        <th>Date From</th>
                                        <th>Date To</th>
                                        <th>Code</th>
                                        <th>Name</th>
                                        <th>Discount</th>
                                        <th>Terms & Conditions</th>
                                        <th>Signature</th>
                                        <!-- <th style="width: 3%">Action</th> -->
                                    </tr>
                                </thead>
                                <tbody></tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div> 
	</section>
</div>
<?php include '../footer.php'; ?>
<script>
    var ID = "";
    var OBJ = "";
    var d = new Date();
    var mm = (d.getMonth("MM")+1);
    var dd = d.getDate();
    var customDate = d.getFullYear() + "-" + ((mm<10)?"0" + mm:mm) + "-" +  ((dd<10)?"0" + dd:dd);
    $('#datePicker1').attr("data-date",customDate);
    $("#txtDatePicker1").val(customDate);
    $('#datePicker2').attr("data-date",customDate);
    $("#txtDatePicker2").val(customDate);

	$(function(){
		$("body").addClass("sidebar-collapse");
        $('#datePicker1').datepicker();
        $('#datePicker2').datepicker();
        getAllRows();
	});

    function HandleBrowseClick(input_image){
        var fileinput = document.getElementById(input_image);
        fileinput.click();
    }

    function getAllRows(){
        $("#myTable").find("tbody").find("tr").remove();
        $.ajax({
            url: APP_URL + "api/payment_config/promotion/get_all_rows.php"
        }).done(function(data) {
            if(data.records.length>1){
                $("#total_records").text(" - " + data.records.length + " record(s) found.");
            }else{
                $("#total_records").text(" - " + data.records.length + " record found.");
            }

            $.each(data.records, function(i, v) {
                $("#myTable").find("tbody")
                .append($('<tr>')
                    .append("<td>" + (i + 1) + "</td>")
                    .append("<td>" + v.date_from + "</td>")
                    .append("<td>" + v.date_to + "</td>")
                    .append("<td>" + v.code + "</td>")
                    .append("<td>" + v.name + "</td>")
                    .append("<td style='text-align:right;'>" + v.discount + "</td>")
                    .append("<td>" + v.terms_n_conditions + "</td>")
                    .append("<td><img src='<?=$app_url;?>api/payment_config/promotion/" + v.signature_picture + "' style='width:60px;height:50px;cusor:pointer;' /></td>")
                    // .append("<td><button type='button' class='btn btn-block btn-success btn-sm fas fa-edit' onclick='edit(\"" + v.id + "\", this)' style='padding: 2px 2px;font-size: 16px; min-width: 37px'></button></td>")
                    // .append("<td style='display:none;'>" + v.signature_picture + "</td>")
                );
            });
       });
    }

    function edit(id, obj){
        ID = id;
        OBJ = obj;
        $("#txtPromotionCode").focus();
        var tr = $(obj).parent().parent();
        $("#txtDatePicker1").val(tr.find("td").eq(1).text());
        $("#txtDatePicker2").val(tr.find("td").eq(2).text());
        $("#txtPromotionCode").val(tr.find("td").eq(3).text());
        $("#txtPromotionName").val(tr.find("td").eq(4).text());
        $("#txtPromotionDiscount").val(tr.find("td").eq(5).text());
        $("#txtTermsNConditions").val(tr.find("td").eq(6).text());
        var profilepicture = (tr.find("td").eq(9).text())?APP_URL + "api/payment_config/promotion/" + tr.find("td").eq(9).text():APP_URL + "img/no_image.jpg";
        $("#previewing").attr('src', profilepicture);
        $(".btnSubmit").css("display", "none");
        $(".btnEdit").css("display", "block");
        $("#txtPromotionCode").attr("disabled", true);
        $(".fa-edit").attr("disabled", true);
        $(obj).attr("disabled", false);
    }

     function clearForm(){
        $(".btnSubmit").css("display", "block");
        $(".btnEdit").css("display", "none");
        $("#txtPromotionCode").attr("disabled", false);
        $(".fa-edit").attr("disabled", false); 
        $("#txtDatePicker1").val(customDate);
        $("#txtDatePicker2").val(customDate);
        $("#txtPromotionCode").val("");
        $("#txtPromotionName").val("");
        $("#txtPromotionDiscount").val("");
        $("#txtTermsNConditions").val("");
        var profilepicture = APP_URL + "img/no_image.jpg";
        $("#previewing").attr('src', profilepicture);
    } 

    $("#btnSubmit").click(function(){
        submitTF = true;
        $("#frmEntry").submit();
        submitTF = false;
    });

    $("#btnUpdate").click(function(){
        submitTF = true;
        $("#frmEntry").submit();
        submitTF = false;
    });

    $("#frmEntry").on('submit',(function(e) {
        e.preventDefault();
        var formData = new FormData(this); 
        var code = $("#txtPromotionCode").val();
        var name = $("#txtPromotionName").val();
        var discount = ($("#txtPromotionDiscount").val().trim()=="")?0:parseInt($("#txtPromotionDiscount").val().replace(/,/g, ''));
        var df = $("#txtDatePicker1").val();
        var dt = $("#txtDatePicker2").val();
        var terms_n_conditions = $("#txtTermsNConditions").val();
        var pp = "<?=$app_url;?>img/no_image.jpg";
        var sig_pic = $("#previewing").attr("src");
        if(code.trim()==""){
            bootbox.alert("Please fill promotion code."); 
        }else if(name.trim()==""){
            bootbox.alert("Please fill promotion name."); 
        }else if(sig_pic==pp){
             bootbox.alert("Please upload signature."); 
      }else if(discount==0){
            bootbox.alert("Please fill promotion discount."); 
        }else{
            $("#loading").css("display", "block");
            var objArr = [];
            objArr.push({"id": ID, "code": code, "name": name, "discount": discount, "df": df, "dt": dt, "terms_n_conditions": terms_n_conditions}); 
            formData.append('objArr', JSON.stringify( objArr ));
            $.ajax({
                url: APP_URL + "api/payment_config/promotion/create.php",
                type:"POST",
                processData:false,
                contentType: false,
                data: formData,
                success: function(data){
                    $("#loading").css("display", "none");
                    if(data.message=="created"){
                        bootbox.alert("Successfully Added.");
                        $("#frmEntry")[0].reset();
                        getAllRows();
                        $("#txtDatePicker1").val(customDate);
                        $("#datePicker1").datepicker("setDate", customDate);
                        $("#txtDatePicker2").val(customDate);
                        $("#datePicker2").datepicker("setDate", customDate);
                        document.getElementById('previewing').src = "<?=$app_url;?>/img/no_image.jpg";
                    }else if(data.message=="updated"){
                        bootbox.alert("Successfully Updated.");
                        $("#frmEntry")[0].reset();
                        getAllRows();
                        $("#txtDatePicker1").val(customDate);
                        $("#datePicker1").datepicker("setDate", customDate);
                        $("#txtDatePicker2").val(customDate);
                        $("#datePicker2").datepicker("setDate", customDate);
                        document.getElementById('previewing').src = "<?=$app_url;?>/img/no_image.jpg";
                    }else if(data.message=="duplicate"){
                        bootbox.alert("This promotion code has already been exist!");
                    }else{
                        bootbox.alert("Error on server side.");
                    }
                }
            });
        }
    }));

    function isNumber(evt) {
        evt = (evt) ? evt : window.event;
        var charCode = (evt.which) ? evt.which : evt.keyCode;
        if ( (charCode > 31 && charCode < 48) || charCode > 57) {
            return false;
        }
        return true;
    }

    function AddComma(obj) {
        var amount = $(obj).val().replace(/,/g, '');
        $(obj).val(parseInt(amount).toLocaleString());
    }

    function btozero(obj){
        if($(obj).val() == "")$(obj).val(0);
    }

</script>   