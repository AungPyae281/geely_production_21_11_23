<?php 
	header("Access-Control-Allow-Origin: *");
	header("Content-Type: application/json; charset=UTF-8");
	header("Access-Control-Max-Age: 3600");
	header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
	  
	include_once '../../config/database.php';
	include_once '../../objects/payment_percent.php';
	  
	$database = new Database();
	$db = $database->getConnection();
	
	$payment_percents = new PaymentPercent($db);
	$data = json_decode(file_get_contents("php://input"));

	$stmt = $payment_percents->getAllRows();
	$num = $stmt->rowCount();
	
	$arr = array();
	$arr["records"] = array();

	if($num>0){	
		while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
			extract($row);
			$detail = array(
				"id" => (int)$id,
				"payment_percent" => $payment_percent
			);	
			array_push($arr["records"], $detail);
		}	
	}
	echo json_encode($arr);
?>