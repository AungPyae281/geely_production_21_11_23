<?php
// required headers
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

include_once '../../config/database.php';
include_once '../../objects/test_drive.php';

date_default_timezone_set('Asia/Rangoon'); 
session_start();

$database = new Database();
$db = $database->getConnection();
 
$test_drive = new TestDrive($db);
$data = json_decode(file_get_contents("php://input"));

$test_drive->id = $data->id;

if($data->signature){
    if (!is_dir('./upload/' . $test_drive->id)) {
        mkdir('./upload/' . $test_drive->id, 0777, true);
    }
    if(file_exists("./upload/" . $test_drive->id . "/signature.png")){
        unlink("./upload/" . $test_drive->id . "/signature.png");
    }
    $img = $data->signature;
    $img_data = base64_decode(explode(',', $img)[1]);
    $file = "./upload/" . $test_drive->id . "/signature.png";
    $success = file_put_contents($file, $img_data);
}

if($test_drive->updateAgree()){
	$msg_arr = array(
        "message" => "updated",
        "id" => $data->id
    );
}else{
	$msg_arr = array(
        "message" => "error"
    );
}
echo json_encode($msg_arr);
?>