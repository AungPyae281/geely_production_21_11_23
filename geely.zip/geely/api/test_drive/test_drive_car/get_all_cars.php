<?php
// required headers
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

include_once '../../config/database.php';
include_once '../../objects/test_drive_car.php';
date_default_timezone_set('Asia/Rangoon'); 

$database = new Database();
$db = $database->getConnection();
 
$test_drive_car = new TestDriveCar($db);
$data = json_decode(file_get_contents("php://input"));

$test_drive_car->date = $data->date;
$test_drive_car->model = $data->model;

$stmt = $test_drive_car->getAllCars();
$num = $stmt->rowCount();

$arr=array();
$arr["records"]=array();

if($num>0){
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
        extract($row);
        $detail = array(
            "id" => ($id)?$id:"",
            "plate_no" => $plate_no, 
            "time" => ($time)?date('h:i A', strtotime($time)):""
        );  
        array_push($arr["records"], $detail);
    }
}
echo json_encode($arr);
?>