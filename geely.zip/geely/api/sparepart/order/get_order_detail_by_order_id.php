<?php
	header("Access-Control-Allow-Origin: *");
	header("Content-Type: application/json; charset=UTF-8");
	header("Access-Control-Allow-Methods: POST");
	header("Access-Control-Max-Age: 3600");
	header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
	 
	include_once '../../config/database.php';
	include_once '../../objects/sparepart_order_detail.php';
	 
	$database = new Database();
	$db = $database->getConnection();
	 
	$sparepart_order_detail = new SparepartOrderDetail($db);
	$data = json_decode(file_get_contents("php://input"));

	$sparepart_order_detail->sparepart_order_id = $data->id;

	$stmt = $sparepart_order_detail->getAllOrderDetailByOrderID();
	$num = $stmt->rowCount();

	$arr = array();
	$arr["records"] = array();

	if($num>0){
		while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
			extract($row);
			$detail = array(
				"sparepart_order_detail_id" => $id, 
				"sparepart_pre_order_id" => $sparepart_pre_order_id, 
				"sparepart_code" => $sparepart_code,
				"sparepart_name" => $sparepart_name, 
				"order_quantity" => (int)$order_quantity,
				"receive_quantity" => (int)$receive_quantity,
				"wl_id" => $wl_id
			);
			array_push($arr["records"], $detail);
		}
	}
	echo json_encode($arr);
?>