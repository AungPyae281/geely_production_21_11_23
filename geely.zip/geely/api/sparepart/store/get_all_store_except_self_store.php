<?php 
	header("Access-Control-Allow-Origin: *");
	header("Content-Type: application/json; charset=UTF-8");
	header("Access-Control-Allow-Methods: POST");
	header("Access-Control-Max-Age: 3600");
	header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
	  
	include_once '../../config/database.php';
	include_once '../../objects/sparepart_store.php';

	session_start();
	  
	$database = new Database();
	$db = $database->getConnection();
	  
	$sparepart_store = new SparepartStore($db);
	$data = json_decode(file_get_contents("php://input"));

	$arr = array();
	$arr["records"] = array();
	
	if($_SESSION['store_name']!=""){

		$sparepart_store->store_name = $data->store_name;

		$stmt = $sparepart_store->getAllStoreExceptSelfStore();
		$num = $stmt->rowCount();

		if($num>0){ 
			while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
				extract($row);
				$detail = array(
					"id" => (int)$id,
					"name" => $name
				);
				array_push($arr["records"], $detail);
			} 
		} 
	}
	echo json_encode($arr);
?>