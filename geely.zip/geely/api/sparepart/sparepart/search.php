<?php
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
    header("Access-Control-Allow-Methods: POST");
    header("Access-Control-Max-Age: 3600");
    header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

    include_once '../../config/database.php';
    include_once '../../objects/sparepart.php';

    $database = new Database();
    $db = $database->getConnection();
     
    $sparepart = new Sparepart($db);
    $data = json_decode(file_get_contents("php://input"));

    $sparepart->group_name = $data->group_name;   
    $sparepart->sub_group_name = $data->sub_group_name;  
    $sparepart->code = $data->code;
    $sparepart->name = $data->name;
    $sparepart->category = $data->category;

    $stmt = $sparepart->search();
    $num = $stmt->rowCount();

    $arr = array();
    $arr["records"] = array();

    if($num>0){
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
            extract($row);
            $detail = array(
                "id" => (int)$id,
                "group_name" => ($group_name)?$group_name:"",
                "sub_group_name" => ($sub_group_name)?$sub_group_name:"", 
                "code" => ($code)?$code:"", 
                "name" => ($name)?$name:"",     
                "category" => ($category)?$category:"",         
                "origin" => ($origin)?$origin:"",
                "unit" => ($unit)?$unit:"",
                "sales_price" => ($sales_price)?number_format($sales_price):0,
                "dealer_price" => ($dealer_price)?number_format($dealer_price):0,
                "description" => ($description)?$description:""
            );  
            array_push($arr["records"], $detail);
        }
    }
    echo json_encode($arr);
?>