<?php
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
    header("Access-Control-Allow-Methods: POST");
    header("Access-Control-Max-Age: 3600");
    header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

    include_once '../../config/database.php';
    include_once '../../objects/sparepart.php';

    date_default_timezone_set('Asia/Rangoon');
    session_start();

    $database = new Database();
    $db = $database->getConnection();
     
    $sparepart = new Sparepart($db);
    $data = json_decode(file_get_contents("php://input"));

    if($_SESSION['user']!=""){

        $sparepart->group_name = $data->group_name;
        $sparepart->sub_group_name = $data->sub_group_name;
        $sparepart->code = $data->code;
        $sparepart->name = $data->name;
        $sparepart->category = $data->category;
        $sparepart->origin = $data->origin;
        $sparepart->unit = $data->unit;
        $sparepart->sales_price = $data->sales_price;
        $sparepart->dealer_price = $data->dealer_price;
        $sparepart->description = $data->description;
        $sparepart->entry_by = $_SESSION['user'];
        $sparepart->entry_date_time = date("Y-m-d H:i:s");

        if($data->action=="Update"){
            if($sparepart->update()){
                $msg_arr = array(
                    "message" => "updated"
                );
            }else{
                $msg_arr = array(
                    "message" => "errorU"
                );
            }
        }else{
            if($sparepart->isExist()){
                $msg_arr = array(
                    "message" => "duplicate"
                );
            }else{
                if($sparepart->create()){
                    $msg_arr = array(
                        "message" => "created"
                    );
                }else{
                    $msg_arr = array(
                        "message" => "errorC"
                    );
                }
            }
        }
    }else{
        $msg_arr = array(
            "message" => "session expire"
        );
    }
    echo json_encode($msg_arr);
?>