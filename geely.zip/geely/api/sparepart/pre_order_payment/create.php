<?php
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
    header("Access-Control-Allow-Methods: POST");
    header("Access-Control-Max-Age: 3600");
    header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

    include_once '../../config/database.php';
    include_once '../../objects/sparepart_pre_order_payment.php';

    date_default_timezone_set('Asia/Rangoon'); 
    session_start();

    $database = new Database();
    $db = $database->getConnection();
     
    $sparepart_pre_order_payment = new SparepartPreOrderPayment($db);
    $data = json_decode($_POST['objArr']);

    if($_SESSION['user']!=""){

        $targetPath = "";
        $newname = "";

        if(!empty($_FILES['file']))
        {
            $ext = pathinfo($_FILES['file']['name'], PATHINFO_EXTENSION);
            $newname = date("Y-m-d H-i-s") .  "." . $ext;
            $targetPath = './upload/' . $newname;
            copy($_FILES['file']['tmp_name'], $targetPath);
        }
        $sparepart_pre_order_payment->upload_receipt = $newname;  

        $sparepart_pre_order_payment->sparepart_pre_order_id = $data[0]->id;
        $sparepart_pre_order_payment->date = $data[0]->date;
        $sparepart_pre_order_payment->gl_code = $data[0]->gl_code;
        $sparepart_pre_order_payment->gl_code_bank_or_cash = $data[0]->gl_code_bank_or_cash;
        $sparepart_pre_order_payment->amount = $data[0]->amount;
        $sparepart_pre_order_payment->paid_by = $data[0]->paid_by; 
        $sparepart_pre_order_payment->description = $data[0]->description;

        $sparepart_pre_order_payment->entry_by = $_SESSION['user'];
        $sparepart_pre_order_payment->entry_date_time = date("Y-m-d H:i:s");

        if($sparepart_pre_order_payment->create()){
            $msg_arr = array(
                "message" => "created"
            );
        }else{
            $msg_arr = array(
                "message" => "error"
            );
        }
    }else{
        $msg_arr = array(
            "message" => "session expire"
        );
    }
    echo json_encode($msg_arr);
?>