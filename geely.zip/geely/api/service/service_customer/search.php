<?php 
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
    header("Access-Control-Allow-Methods: POST");
    header("Access-Control-Max-Age: 3600");
    header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

    include_once '../../config/database.php';
    include_once '../../objects/service_customer.php';

    $database = new Database();
    $db = $database->getConnection();
     
    $service_customer = new ServiceCustomer($db);
    $data = json_decode(file_get_contents("php://input"));

    $service_customer->registration_no = $data->registration_no;   
    $service_customer->name = $data->name;  
    $service_customer->phone_no = $data->phone_no;
    $service_customer->township = $data->township;
    $service_customer->nrc_no = $data->nrc_no;

    $stmt = $service_customer->search();
    $num = $stmt->rowCount();

    $arr = array();
    $arr["records"] = array();

    if($num>0){
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
            extract($row);
            $detail = array(
                "id" => (int)$id,
                "registration_no" => ($registration_no)?$registration_no:"",
                "name" => ($name)?$name:"", 
                "nrc_no" => ($nrc_no)?$nrc_no:"", 
                "phone_no" => ($phone_no)?$phone_no:"",
                "alternative_phone_no" => ($alternative_phone_no)?$alternative_phone_no:"",
                "email" => ($email)?$email:"",
                "township" => ($township)?$township:"",
                "address" => ($address)?$address:"",
                "no_of_vehicle" => $no_of_vehicle
            );  
            array_push($arr["records"], $detail);
        }
    }
    echo json_encode($arr);
?>