<?php 
	header("Access-Control-Allow-Origin: *");
	header("Content-Type: application/json; charset=UTF-8");
	header("Access-Control-Allow-Methods: POST");
	header("Access-Control-Max-Age: 3600");
	header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

	include_once '../../config/database.php';
	include_once '../../objects/service_car.php';
	include_once '../../objects/service_customer_car.php';

	date_default_timezone_set('Asia/Rangoon'); 
    session_start();

	$database = new Database();
	$db = $database->getConnection();

	$service_car = new ServiceCar($db);
	$service_customer_car = new ServiceCustomerCar($db);
	$data = json_decode(file_get_contents("php://input"));

	if($_SESSION['user']!=""){
		$service_customer_car->service_car_id = $data->service_car_id;
		$service_customer_car->service_customer_id = $data->service_customer_id; 
		$service_customer_car->plate_no = $data->plate_no;
		$service_customer_car->entry_by = $_SESSION['user'];
	    $service_customer_car->entry_date_time = date("Y-m-d H:i:s");

	    $service_car->service_customer_id = $data->service_customer_id;
	    $service_car->id = $data->service_car_id;

		if($service_customer_car->create()){

			$service_car->updateOwner();
			$msg_arr = array(
				"message" => "created"
			);
		}else{
			$msg_arr = array(
				"message" => "error"
			);
		}
	}else{
		$msg_arr = array(
			"message" => "session expire"
		);
	}
	echo json_encode($msg_arr);
?>