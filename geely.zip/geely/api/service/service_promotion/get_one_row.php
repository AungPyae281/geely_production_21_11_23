<?php
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
    header("Access-Control-Allow-Methods: POST");
    header("Access-Control-Max-Age: 3600");
    header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

    include_once '../../config/database.php';
    include_once '../../objects/service_promotion.php';
    include_once '../../objects/service_promotion_package.php';
    include_once '../../objects/service_promotion_gift.php';
    include_once '../../objects/service_promotion_sparepart.php';

    $database = new Database();
    $db = $database->getConnection();
     
    $service_promotion = new ServicePromotion($db);
    $service_promotion_package = new ServicePromotionPackage($db);
    $service_promotion_gift = new ServicePromotionGift($db);
    $service_promotion_sparepart = new ServicePromotionSparepart($db);
    $data = json_decode(file_get_contents("php://input"));

    $service_promotion->id = $data->id;
    $service_promotion_package->service_promotion_id = $data->id;
    $service_promotion_gift->service_promotion_id = $data->id;
    $service_promotion_sparepart->service_promotion_id = $data->id;

    $service_promotion->getOneRow();

    $service_promotion_packages = array();
    $stmt1 = $service_promotion_package->getServicePromotionPackage();
    $num1 = $stmt1->rowCount();

    if($num1>0){
        while ($row = $stmt1->fetch(PDO::FETCH_ASSOC)){
            extract($row);
    		$detail = array(
                "service_package_id" => (int)$service_package_id,
                "package_name" => $package_name,
                "discount_percent" => (int)$discount_percent
            );
            array_push($service_promotion_packages, $detail);
        }
    }

    $service_promotion_gifts = array();
    $stmt2 = $service_promotion_gift->getServicePromotionGift();
    $num2 = $stmt2->rowCount();

    if($num2>0){
        while ($row = $stmt2->fetch(PDO::FETCH_ASSOC)){
            extract($row);
            $detail = array(
                "service_gift_id" => (int)$service_gift_id,
                "name" => $name,
                "quantity" => (int)$quantity
            );
            array_push($service_promotion_gifts, $detail);
        }
    }

    $service_promotion_spareparts = array();
    $stmt3 = $service_promotion_sparepart->getServicePromotionSparepart();
    $num3 = $stmt3->rowCount();

    if($num3>0){
        while ($row = $stmt3->fetch(PDO::FETCH_ASSOC)){
            extract($row);
            $detail = array(
                "sparepart_code" => $sparepart_code,
                "name" => $name,
                "discount_percent" => (int)$discount_percent
            );
            array_push($service_promotion_spareparts, $detail);
        }
    }

    $arr = array(    
        "promotion_name" => $service_promotion->promotion_name,
        "start_date" => $service_promotion->start_date,
        "end_date" => $service_promotion->end_date,
        "service_promotion_packages" => $service_promotion_packages,
        "service_promotion_gifts" => $service_promotion_gifts,
        "service_promotion_spareparts" => $service_promotion_spareparts
    );
    echo json_encode($arr);
?>