<?php 
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
    header("Access-Control-Allow-Methods: POST");
    header("Access-Control-Max-Age: 3600");
    header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

    include_once '../../config/database.php';
    include_once '../../objects/warranty_car.php';

    $database = new Database();
    $db = $database->getConnection();
     
    $warranty_car = new WarrantyCar($db);
    $data = json_decode(file_get_contents("php://input"));

    $warranty_car->plate_no = $data->plate_no;   
    $warranty_car->warranty_status = $data->warranty_status;

    $stmt = $warranty_car->search();
    $num = $stmt->rowCount();

    $arr = array();
    $arr["records"] = array();

    if($num>0){
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
            extract($row);
            $detail = array(
                "plate_no" => $plate_no,
                "kilometer" => number_format($kilometer),
                "last_visited_date" => $last_visited_date,
                "warranty1" => $A,
                "warranty2" => $B,
                "warranty3" => $C,
                "warranty4" => $D,
                "warranty5" => $E
            );  
            array_push($arr["records"], $detail);
        }
    }
    echo json_encode($arr);
?>