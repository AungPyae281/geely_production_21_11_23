<?php
class Department{
    // database connection and table name
	private $conn;
	private $table_name = "department";

	// object properties 
	public $id;
	public $department;

	public function __construct($db){
		$this->conn = $db;
	}

	function getAllRows(){
		$query = "SELECT department.*, IFNULL(position, '') AS position FROM " . $this->table_name . " LEFT JOIN position ON department.department=position.department GROUP BY department.department ORDER BY department.department";
		$stmt = $this->conn->prepare( $query );
		$stmt->execute();
		return $stmt;
	}

	function isExist(){
		$query = "SELECT id FROM " . $this->table_name . " WHERE department = :department LIMIT 0,1";
		$stmt = $this->conn->prepare( $query );
		$this->department=htmlspecialchars(strip_tags($this->department));
		$stmt->bindParam(":department", $this->department);
		$stmt->execute();
		if($stmt->rowCount()>0){
			return true;
		}
		return false;
	}

	function create(){
		$query = "INSERT INTO " . $this->table_name . " SET department=:department";
		$stmt = $this->conn->prepare($query);
		$stmt->bindParam(":department", $this->department);
		if($stmt->execute()){
			return true;
		}
		return false;		
	} 

	function delete(){
		$query = "DELETE FROM " . $this->table_name . " WHERE id = :id";
		$stmt = $this->conn->prepare($query);
		$stmt->bindParam(":id", $this->id);
		if($stmt->execute()){
			return true;
		}
		return false;
	}
}
?>