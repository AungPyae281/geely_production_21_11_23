<?php
class ServiceBayServices{ 
	private $conn;
	private $table_name = "service_bay_services"; 

	public $id;
	public $service_center_bay_id;
	public $service_item_id;
	public $entry_by;
	public $entry_date_time;

	public function __construct($db){
		$this->conn = $db;
	}

	function delete(){
		$query = "DELETE FROM " . $this->table_name . " WHERE service_center_bay_id=:service_center_bay_id";
		$stmt = $this->conn->prepare($query);
		$stmt->bindParam(":service_center_bay_id", $this->service_center_bay_id);
		if($stmt->execute()){
			return true;
		}
		return false;		
	}

	function create(){
		$query = "INSERT INTO " . $this->table_name . " SET service_center_bay_id=:service_center_bay_id, service_item_id=:service_item_id, entry_by=:entry_by, entry_date_time=:entry_date_time";

		$stmt = $this->conn->prepare($query);

		$stmt->bindParam(":service_center_bay_id", $this->service_center_bay_id);
		$stmt->bindParam(":service_item_id", $this->service_item_id);
		$stmt->bindParam(":entry_by", $this->entry_by);
		$stmt->bindParam(":entry_date_time", $this->entry_date_time);

		if($stmt->execute()){
			return true;
		}
		return false;		
	}

	function getServiceBayServicesDetail(){
		$query = "SELECT sbs.*, sc.name, scb.bay_no, si.code, si.`name` AS service_item FROM " . $this->table_name . " AS sbs
LEFT JOIN service_center_bay AS scb ON sbs.service_center_bay_id=scb.id
LEFT JOIN service_center AS sc ON scb.service_center_id=sc.id
LEFT JOIN service_item AS si ON sbs.service_item_id=si.id WHERE sbs.service_center_bay_id=:service_center_bay_id ORDER BY sbs.id";
		$stmt = $this->conn->prepare($query);
		$stmt->bindParam(":service_center_bay_id", $this->service_center_bay_id);
		$stmt->execute();
		return $stmt;
	}

	function getAvailableServicesBySC(){
		$query = "SELECT si.*, COUNT(sbs.service_center_bay_id) AS aval_qty FROM service_bay_services AS sbs
		LEFT JOIN service_center_bay AS scb ON sbs.service_center_bay_id=scb.id
		LEFT JOIN service_center AS sc ON scb.service_center_id=sc.id
		LEFT JOIN service_item AS si ON sbs.service_item_id=si.id WHERE sc.name=:service_center GROUP BY si.id";
		$stmt = $this->conn->prepare( $query );
		$stmt->bindParam(":service_center", $this->service_center);
		$stmt->execute();
		return $stmt;
	}
}
?>