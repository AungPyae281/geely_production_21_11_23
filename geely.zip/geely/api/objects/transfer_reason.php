<?php
class TransferReason{
	private $conn;
	private $table_name = "transfer_reason";

	public $id;
	public $reason;

	public function __construct($db){
		$this->conn = $db;
	}	

	function getAllRows(){
		$query = "SELECT * FROM " . $this->table_name . "  ORDER BY id, reason";
		$stmt = $this->conn->prepare($query);
		$stmt->execute();
		return $stmt;
	}
}
?>