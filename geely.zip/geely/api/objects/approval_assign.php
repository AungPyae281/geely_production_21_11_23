<?php
class ApprovalAssign{
    // database connection and table name
	private $conn;
	private $table_name = "approval_assign";

	// object properties 
	public $id;
	public $process;
	public $staff_id;
	public $approval_staff_id;
	public $permission_edit;
	public $order_no;
	public $condition;

	public function __construct($db){
		$this->conn = $db;
	}

	function delete(){
		$query = "DELETE FROM " . $this->table_name . " WHERE staff_id=:staff_id";
		$stmt = $this->conn->prepare($query);
		$stmt->bindParam(":staff_id", $this->staff_id);
		if($stmt->execute()){
			return true;
		}
		return false;
	}

	function create(){
		$query = "INSERT INTO " . $this->table_name . " SET `process`=:process, staff_id=:staff_id, approval_staff_id=:approval_staff_id, permission_edit=:permission_edit, order_no=:order_no, `condition`=:condition";
		$stmt = $this->conn->prepare($query);

		$stmt->bindParam(":process", $this->process);
		$stmt->bindParam(":staff_id", $this->staff_id);
		$stmt->bindParam(":approval_staff_id", $this->approval_staff_id);
		$stmt->bindParam(":permission_edit", $this->permission_edit);
		$stmt->bindParam(":order_no", $this->order_no);
		$stmt->bindParam(":condition", $this->condition);

		if($stmt->execute()){
			return true;
		}
		return false;		
	} 

	function getApprovalAssignByStaff(){
		$query = "SELECT aa.*, IFNULL(sender.name, '') AS staff_name, IFNULL(approver.name, '') AS approval_staff_name FROM " . $this->table_name . " AS aa LEFT JOIN staff AS sender ON aa.staff_id=sender.id LEFT JOIN staff AS approver ON aa.approval_staff_id=approver.id WHERE aa.staff_id=:staff_id";
		$stmt = $this->conn->prepare($query);
		$stmt->bindParam(":staff_id", $this->staff_id);
		$stmt->execute();
		return $stmt;		
	}
}
?>