<?php
class Township{
	private $conn;
	private $table_name = "township";

	public $id;
	public $state_division;
	public $city;
	public $township;

	public function __construct($db){
		$this->conn = $db;
	}

	function getAllRows(){
		$query = "SELECT * FROM " . $this->table_name . " ORDER BY state_division, city, township";
		$stmt = $this->conn->prepare($query);
		$stmt->execute();
		return $stmt;
	}
}
?>