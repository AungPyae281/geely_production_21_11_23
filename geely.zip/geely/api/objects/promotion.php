<?php
class Promotion{
    private $conn;
    private $table_name = "promotion";

	public $id;
	public $code;
    public $name;
	public $discount;
	public $date_from;
    public $date_to; 
    public $terms_n_conditions;	
    public $signature_picture;
    public $entry_by;
    public $entry_date_time;

    public function __construct($db){
        $this->conn = $db;
    }

    // function getOnePromotionBK(){
	// 	$query = "SELECT * FROM " . $this->table_name . " WHERE	code=:code AND :date BETWEEN date_from AND date_to LIMIT 0,1";

	// 	$stmt = $this->conn->prepare( $query );
	// 	$stmt->bindParam(":code", $this->code);
	// 	$stmt->bindParam(":date", $this->date);
	// 	$stmt->execute();

	// 	if($stmt->rowCount()>0){
	// 		$row = $stmt->fetch(PDO::FETCH_ASSOC);
	// 		$this->discount = (int)$row['discount'];
	// 	}else{
	// 		$this->discount = 0;
	// 	}
	// } 

	 function getPromotionByDate(){
		$query = "SELECT * FROM " . $this->table_name . " WHERE	:date BETWEEN date_from AND date_to";

		$stmt = $this->conn->prepare( $query );
		$stmt->bindParam(":date", $this->date);
		$stmt->execute();
		return $stmt;
	} 

	function checkPromotion(){
		$query = "SELECT * FROM " . $this->table_name . " WHERE code=:code LIMIT 0,1";
		$stmt = $this->conn->prepare( $query );
		$stmt->bindParam(":code", $this->code);
		$stmt->execute();
		if($stmt->rowCount()>0){
			return true;
		}
		return false;
	}

	function create(){
		$condition = "";
		if($this->signature_picture){
			$condition = " , signature_picture=:signature_picture ";
		}
		$query = "INSERT INTO " . $this->table_name . " SET 
		code=:code
		, name=:name
		, discount=:discount
		, date_from=:date_from
		, date_to=:date_to
		, terms_n_conditions=:terms_n_conditions
        , entry_by=:entry_by
        , entry_date_time=:entry_date_time" . $condition;
		 
		$stmt = $this->conn->prepare($query);
		
		$stmt->bindParam(":code", $this->code);
		$stmt->bindParam(":name", $this->name);
		$stmt->bindParam(":discount", $this->discount);
		$stmt->bindParam(":date_from", $this->date_from);
		$stmt->bindParam(":date_to", $this->date_to);
        $stmt->bindParam(":terms_n_conditions", $this->terms_n_conditions);	
		$stmt->bindParam(":entry_by", $this->entry_by);
		$stmt->bindParam(":entry_date_time", $this->entry_date_time);
		if($this->signature_picture) $stmt->bindParam(":signature_picture", $this->signature_picture);

		if($stmt->execute()){
			return true;
		}
		return false;
    }


    function update(){
    	$condition = "";
		if($this->signature_picture){
			$condition = " , signature_picture=:signature_picture ";
		}
		$query = "UPDATE " . $this->table_name . " SET code=:code
		, name=:name
		, discount=:discount
		, date_from=:date_from
		, date_to=:date_to
		, terms_n_conditions=:terms_n_conditions
        , entry_by=:entry_by
        , entry_date_time=:entry_date_time" . $condition . " WHERE id=:id";
		$stmt = $this->conn->prepare($query);

		$stmt->bindParam(":id", $this->id);
		$stmt->bindParam(":code", $this->code);
		$stmt->bindParam(":name", $this->name);
		$stmt->bindParam(":discount", $this->discount);
		$stmt->bindParam(":date_from", $this->date_from);
		$stmt->bindParam(":date_to", $this->date_to);
        $stmt->bindParam(":terms_n_conditions", $this->terms_n_conditions);	
		$stmt->bindParam(":entry_by", $this->entry_by);
		$stmt->bindParam(":entry_date_time", $this->entry_date_time);
		if($this->signature_picture) $stmt->bindParam(":signature_picture", $this->signature_picture);

		if($stmt->execute()){
			return true;
		}	 
		return false;
	}

    function getAllRows(){
		$query = "SELECT * FROM " . $this->table_name . " ORDER BY date_from desc";
		$stmt = $this->conn->prepare( $query );
		$stmt->execute();
		return $stmt;
	} 
}
?>