<?php
class NRCCode{
    private $conn;
    private $table_name = "nrc_code";
 
	public $id;
	public $states_divisions_code;
	public $townships_code;
 
    public function __construct($db){
        $this->conn = $db;
    }

	function getNRCBySDCode(){
		$condition = "";
		if($this->states_divisions_code){
			$condition = " WHERE states_divisions_code =:states_divisions_code ";
		}
		$query = "SELECT * FROM " . $this->table_name . $condition . " ORDER BY states_divisions_code, townships_code";
		$stmt = $this->conn->prepare($query);	
		if($this->states_divisions_code) $stmt->bindParam(":states_divisions_code", $this->states_divisions_code);
		$stmt->execute();
		return $stmt;
	}
}
?>