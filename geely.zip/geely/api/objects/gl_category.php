<?php
class GLCategory{ 
	private $conn;
	private $table_name = "gl_category";
 
	public $id;
	public $type;
	public $category;

	public function __construct($db){
		$this->conn = $db;
	}

	function getCategoriesByType(){
		$query = "SELECT * FROM " . $this->table_name . " WHERE `type`=:type ORDER BY category";
		$stmt = $this->conn->prepare( $query );
		$stmt->bindParam(":type", $this->type);
		$stmt->execute();
		return $stmt;
	}
}
?>