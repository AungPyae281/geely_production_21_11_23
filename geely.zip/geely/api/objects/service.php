<?php
class Service{ 
	private $conn;
	private $table_name = "service";

	public $id;
	public $registration_no;
	public $appointment_id;
	public $service_car_id;
	public $service_customer_id;
	public $plate_no;
	public $service_center;
	public $inspection_date_time;
	public $service_entry_date_time;
	public $invoice_date;
	public $payment_due_date_time;
	public $kilometer;
	public $car_receive_date;
	public $car_receive_time;
	public $car_return_time;
	public $car_inspection_img;
	public $insp_service_booklet;
	public $insp_jack_and_handle;
	public $insp_paking_sign;
	public $insp_spare_wheel;
	public $insp_mobile_charger;
	public $insp_car_key;
	public $insp_wheel_tax;
	public $insp_fuel_level;
	public $insp_other_items;
	public $insp_remark;
	public $sa_id;
	public $main_technician_id;  
	public $visit_type;
	public $promotion;
	public $total_waiting_time;
	public $service_remark;
	public $test_drive_agree; 
	public $discount;
	public $status;
	public $complain;
	public $complain_date_time;

	public function __construct($db){
		$this->conn = $db;
	}

	function getGenerateRegNo($prefix){
		$query = "SELECT registration_no FROM `" . $this->table_name . "` WHERE registration_no like ? ORDER BY registration_no DESC LIMIT 0, 1";
		$stmt = $this->conn->prepare($query);
		$keywords = htmlspecialchars(strip_tags($prefix));
		$keywords = "{$keywords}%";
		
		$stmt->bindParam(1, $keywords);
		$stmt->execute();
		if($stmt->rowCount()>0){
			$row = $stmt->fetch(PDO::FETCH_ASSOC);
			return $prefix . sprintf("%05d", ((int)str_replace($prefix, "", $row['registration_no']) + 1));
		}else{
			return $prefix . "00001";
		}
	}
 
	function getLastKilometer(){
		$query = "SELECT kilometer FROM " . $this->table_name . " WHERE registration_no=(SELECT MAX(registration_no) AS reg_no FROM service LEFT JOIN service_appointment ON service.appointment_id=service_appointment.id WHERE service.plate_no=:plate_no)";
		$stmt = $this->conn->prepare($query);
			
		$stmt->bindParam(":plate_no", $this->plate_no);

		$stmt->execute();
		if($stmt->rowCount()>0){
			$row = $stmt->fetch(PDO::FETCH_ASSOC);
			return (int)$row['kilometer'];	
		}else{
			return 0;
		}
	}

	function create(){
		$statement = "";
		if($this->car_inspection_img!=""){
			$statement = ", car_inspection_img=:car_inspection_img";
		}
		$query = "INSERT INTO " . $this->table_name . " SET registration_no=:registration_no, appointment_id=:appointment_id, service_car_id=:service_car_id, plate_no=:plate_no, service_center=:service_center, inspection_date_time=:inspection_date_time, kilometer=:kilometer, car_receive_date=:car_receive_date, car_receive_time=:car_receive_time, insp_service_booklet=:insp_service_booklet, insp_jack_and_handle=:insp_jack_and_handle, insp_paking_sign=:insp_paking_sign, insp_spare_wheel=:insp_spare_wheel, insp_mobile_charger=:insp_mobile_charger, insp_car_key=:insp_car_key, insp_wheel_tax=:insp_wheel_tax, insp_fuel_level=:insp_fuel_level, insp_other_items=:insp_other_items, insp_remark=:insp_remark, `status`=:status" . $statement;

		$stmt = $this->conn->prepare($query);

		$stmt->bindParam(":registration_no", $this->registration_no);
		$stmt->bindParam(":appointment_id", $this->appointment_id);
		$stmt->bindParam(":service_car_id", $this->service_car_id);
		$stmt->bindParam(":plate_no", $this->plate_no);
		$stmt->bindParam(":service_center", $this->service_center);
		$stmt->bindParam(":inspection_date_time", $this->inspection_date_time);
		$stmt->bindParam(":kilometer", $this->kilometer);
		$stmt->bindParam(":car_receive_date", $this->car_receive_date);
		$stmt->bindParam(":car_receive_time", $this->car_receive_time);
		if($this->car_inspection_img!="") $stmt->bindParam(":car_inspection_img", $this->car_inspection_img);
		$stmt->bindParam(":insp_service_booklet", $this->insp_service_booklet);
		$stmt->bindParam(":insp_jack_and_handle", $this->insp_jack_and_handle);
		$stmt->bindParam(":insp_paking_sign", $this->insp_paking_sign);
		$stmt->bindParam(":insp_spare_wheel", $this->insp_spare_wheel);
		$stmt->bindParam(":insp_mobile_charger", $this->insp_mobile_charger);
		$stmt->bindParam(":insp_car_key", $this->insp_car_key);
		$stmt->bindParam(":insp_wheel_tax", $this->insp_wheel_tax);
		$stmt->bindParam(":insp_fuel_level", $this->insp_fuel_level);
		$stmt->bindParam(":insp_other_items", $this->insp_other_items);
		$stmt->bindParam(":insp_remark", $this->insp_remark);
		$stmt->bindParam(":status", $this->status);

		if($stmt->execute()){
			$this->id = $this->conn->lastInsertId();
			return true;
		}
		return false;
	}

	function getOneService(){
		$query = "SELECT service.*, IFNULL(tech.`name`, '') AS main_technician_name, IFNULL(sa.`name`, '') AS sa_name, scc.name AS owner_name, scc.phone_no AS owner_phone, service_appointment.contact_person AS appt_contact_person, service_appointment.contact_phone AS appt_contact_phone, IFNULL(service_customer.name, '') AS contact_person, IFNULL(service_customer.phone_no, '') AS contact_phone, service.plate_no, scc.model, scc.vin_no, scc.engine_no FROM " . $this->table_name . "
LEFT JOIN service_appointment ON service.appointment_id=service_appointment.id
LEFT JOIN (SELECT service_car.*, service_customer.name, service_customer.phone_no FROM service_car LEFT JOIN service_customer ON service_car.service_customer_id=service_customer.id) AS scc ON service.service_car_id=scc.id
LEFT JOIN service_customer ON service.service_customer_id=service_customer.id
LEFT JOIN staff AS tech ON service.main_technician_id=tech.id
LEFT JOIN staff AS sa ON service.sa_id=sa.id WHERE service.id=:id";

		$stmt = $this->conn->prepare($query);
			
		$stmt->bindParam(":id", $this->id);

		$stmt->execute();
		if($stmt->rowCount()>0){
			$row = $stmt->fetch(PDO::FETCH_ASSOC);
			$this->id = $row['id'];	
			$this->appointment_id = $row['appointment_id'];		
			$this->service_center = $row['service_center'];	
			$this->registration_no = $row['registration_no'];
			$this->owner_name = $row['owner_name'];
			$this->owner_phone = $row['owner_phone'];	
			$this->appt_contact_person = $row['appt_contact_person'];
			$this->appt_contact_phone = $row['appt_contact_phone'];	
			$this->service_customer_id = $row['service_customer_id'];
			$this->contact_person = $row['contact_person'];
			$this->contact_phone = $row['contact_phone'];	
			$this->service_car_id = $row['service_car_id'];		
			$this->plate_no = $row['plate_no'];		
			$this->model = $row['model'];	
			$this->vin_no = $row['vin_no'];		
			$this->engine_no = $row['engine_no'];
			$this->kilometer = $row['kilometer'];
			$this->invoice_date = $row['invoice_date'];
			$this->payment_due_date_time = $row['payment_due_date_time'];
			$this->car_receive_date = $row['car_receive_date'];
			$this->car_receive_time = $row['car_receive_time'];
			$this->car_return_date = $row['car_return_date'];
			$this->car_return_time = $row['car_return_time'];
			$this->insp_service_booklet = $row['insp_service_booklet'];
			$this->insp_jack_and_handle = $row['insp_jack_and_handle'];
			$this->insp_paking_sign = $row['insp_paking_sign'];
			$this->insp_spare_wheel = $row['insp_spare_wheel'];
			$this->insp_mobile_charger = $row['insp_mobile_charger'];
			$this->insp_car_key = $row['insp_car_key'];
			$this->insp_wheel_tax = $row['insp_wheel_tax'];
			$this->insp_fuel_level = $row['insp_fuel_level'];
			$this->insp_other_items = $row['insp_other_items'];
			$this->insp_remark = $row['insp_remark'];
			$this->car_inspection_img = $row['car_inspection_img'];
			$this->main_technician_id = $row['main_technician_id'];
			$this->main_technician_name = $row['main_technician_name'];
			$this->sa_id = $row['sa_id'];
			$this->sa_name = $row['sa_name'];
			$this->visit_type = $row['visit_type'];
			$this->promotion = $row['promotion'];
			$this->total_waiting_time = $row['total_waiting_time'];
			$this->service_remark = $row['service_remark'];
			$this->test_drive_agree = $row['test_drive_agree']; 
			$this->discount = $row['discount'];
			$this->status = $row['status'];
		}
	}  

	function update(){
		$statement = "";
		if($this->car_inspection_img!=""){
			$statement = ", car_inspection_img=:car_inspection_img";
		}
		$query = "UPDATE " . $this->table_name . " SET kilometer=:kilometer, car_receive_date=:car_receive_date, car_receive_time=:car_receive_time, insp_service_booklet=:insp_service_booklet, insp_jack_and_handle=:insp_jack_and_handle, insp_paking_sign=:insp_paking_sign, insp_spare_wheel=:insp_spare_wheel, insp_mobile_charger=:insp_mobile_charger, insp_car_key=:insp_car_key, insp_wheel_tax=:insp_wheel_tax, insp_fuel_level=:insp_fuel_level, insp_other_items=:insp_other_items, insp_remark=:insp_remark" . $statement . " WHERE id=:id";

		$stmt = $this->conn->prepare($query);

		$stmt->bindParam(":id", $this->id); 
		$stmt->bindParam(":kilometer", $this->kilometer);
		$stmt->bindParam(":car_receive_date", $this->car_receive_date);
		$stmt->bindParam(":car_receive_time", $this->car_receive_time);
		if($this->car_inspection_img!="") $stmt->bindParam(":car_inspection_img", $this->car_inspection_img);
		$stmt->bindParam(":insp_service_booklet", $this->insp_service_booklet);
		$stmt->bindParam(":insp_jack_and_handle", $this->insp_jack_and_handle);
		$stmt->bindParam(":insp_paking_sign", $this->insp_paking_sign);
		$stmt->bindParam(":insp_spare_wheel", $this->insp_spare_wheel);
		$stmt->bindParam(":insp_mobile_charger", $this->insp_mobile_charger);
		$stmt->bindParam(":insp_car_key", $this->insp_car_key);
		$stmt->bindParam(":insp_wheel_tax", $this->insp_wheel_tax);
		$stmt->bindParam(":insp_fuel_level", $this->insp_fuel_level);
		$stmt->bindParam(":insp_other_items", $this->insp_other_items);
		$stmt->bindParam(":insp_remark", $this->insp_remark);

		if($stmt->execute()){
			return true;
		}
		return false;
	}

	function getAllServicingList(){	
		$query = "SELECT service.id, service.registration_no, service.plate_no, service_car.vin_no, if(service_customer.id IS NOT NULL, service_customer.name, service_appointment.contact_person) AS contact_person, if(service_customer.id IS NOT NULL, service_customer.phone_no, service_appointment.contact_phone) AS contact_phone, service.kilometer, service.total_waiting_time, total_services, finish_services, service.`status` FROM " . $this->table_name . "
			LEFT JOIN service_appointment ON service.appointment_id=service_appointment.id
			LEFT JOIN service_car ON service.service_car_id=service_car.id
			LEFT JOIN service_customer ON service.service_customer_id=service_customer.id
			LEFT JOIN (SELECT ts.service_id, total_services, IFNULL(finish_services, 0) AS finish_services FROM (SELECT service_id, COUNT(DISTINCT(item_code)) AS total_services FROM service_detail_service_item GROUP BY service_id) AS ts
			LEFT JOIN (SELECT service_id, COUNT(DISTINCT(item_code)) AS finish_services FROM service_detail_service_item WHERE end_time<>'' GROUP BY service_id) AS fs ON ts.service_id=fs.service_id) AS fsv ON service.id=fsv.service_id WHERE service.`status`<>'Final Inspection' AND service.service_center=:service_center";
		$stmt = $this->conn->prepare( $query );
		$stmt->bindParam(":service_center", $this->service_center);
		$stmt->execute();
		return $stmt;
	}

	function getAllServicingListForFN(){	
		$condition = "";
		if($this->df){
			$condition .= " AND LEFT(service_entry_date_time, 10) >= :df ";
		}

		if($this->dt){
			$condition .= " AND LEFT(service_entry_date_time, 10) <= :dt ";
		}

		$query = "SELECT service.id, service.registration_no, LEFT(service_entry_date_time, 10) AS service_date, service.plate_no, service_customer.name AS contact_person, service_customer.phone_no AS contact_phone, total_waiting_time, total_services, finish_services, IFNULL(amount, 0) AS total_amount, service.discount FROM service
		LEFT JOIN service_customer ON service.service_customer_id=service_customer.id
		LEFT JOIN (SELECT ts.service_id, total_services, IFNULL(finish_services, 0) AS finish_services FROM (SELECT service_id, COUNT(DISTINCT(item_code)) AS total_services FROM service_detail_service_item GROUP BY service_id) AS ts
			LEFT JOIN (SELECT service_id, COUNT(DISTINCT(item_code)) AS finish_services FROM service_detail_service_item WHERE end_time<>'' GROUP BY service_id) AS fs ON ts.service_id=fs.service_id) AS fsv ON service.id=fsv.service_id
		LEFT JOIN (SELECT service_id, SUM(amount) AS amount FROM (SELECT service_id, SUM(if(warranty=0, qty * sparepart.sales_price, 0)) AS amount FROM service_detail_sparepart LEFT JOIN sparepart ON service_detail_sparepart.code=sparepart.code UNION ALL SELECT service_id, SUM(item_price) AS amount FROM (SELECT service_id, package_price AS item_price FROM service_detail_service_item where package_id<>0 GROUP BY service_id, package_id UNION ALL SELECT service_id, SUM(item_price) AS item_price FROM service_detail_service_item where package_id=0 GROUP BY service_id) AS sdsi GROUP BY service_id) AS spsi GROUP BY service_id) AS spsi1 ON service.id=spsi1.service_id WHERE service.status NOT IN ('Arrival Inspection', 'Final Inspection')" . $condition;
		$stmt = $this->conn->prepare( $query );
		if($this->df) $stmt->bindParam(":df", $this->df);
		if($this->dt) $stmt->bindParam(":dt", $this->dt);
		$stmt->execute();
		return $stmt;
	}

	function updateService(){
		$statement = "";
		if($this->status!=""){
			$statement .= ", `status`=:status";
		}
		if($this->service_entry_date_time!=""){
			$statement .= ", service_entry_date_time=:service_entry_date_time";
		}
		$query = "UPDATE " . $this->table_name . " SET service_customer_id=:service_customer_id, sa_id=:sa_id, main_technician_id=:main_technician_id, visit_type=:visit_type, promotion=:promotion, total_waiting_time=:total_waiting_time, service_remark=:service_remark, test_drive_agree=:test_drive_agree, discount=:discount" . $statement . " WHERE id=:id";

		$stmt = $this->conn->prepare($query);

		$stmt->bindParam(":id", $this->id);
		$stmt->bindParam(":service_customer_id", $this->service_customer_id);
		$stmt->bindParam(":sa_id", $this->sa_id);
		$stmt->bindParam(":main_technician_id", $this->main_technician_id);
		$stmt->bindParam(":visit_type", $this->visit_type);
		$stmt->bindParam(":promotion", $this->promotion);
		$stmt->bindParam(":total_waiting_time", $this->total_waiting_time);
		$stmt->bindParam(":service_remark", $this->service_remark);
		$stmt->bindParam(":test_drive_agree", $this->test_drive_agree); 
		$stmt->bindParam(":discount", $this->discount);
		if($this->status!="") $stmt->bindParam(":status", $this->status);
		if($this->service_entry_date_time!="") $stmt->bindParam(":service_entry_date_time", $this->service_entry_date_time);

		if($stmt->execute()){
			return true;
		}
		return false;
	}

	function updateStatus(){
		$query = "UPDATE " . $this->table_name . " SET `status`=:status WHERE id=:id";
		$stmt = $this->conn->prepare($query);

		$stmt->bindParam(":id", $this->id);
		$stmt->bindParam(":status", $this->status);

		if($stmt->execute()){
			return true;
		}
		return false;
	} 

	function getAllServicingListByIN(){	//HHYS
		$query = "SELECT service.id, service.registration_no, service.service_center, LEFT(service_entry_date_time, 10) AS service_date, service.plate_no, service_customer.name, service_customer.phone_no, IFNULL(staff.name, '') AS sa_name, car_receive_date, car_receive_time, scs.sparepart_store_id AS store_id, scs.store_name FROM " . $this->table_name . "
			RIGHT JOIN (SELECT service_id FROM service_detail_sparepart WHERE qty>receive_qty GROUP BY service_id) AS sd ON service.id=sd.service_id
			LEFT JOIN service_customer ON service.service_customer_id=service_customer.id
			LEFT JOIN staff ON service.sa_id=staff.id
			LEFT JOIN service_center_store AS scs ON service.service_center=scs.service_center WHERE service.service_entry_date_time<>'' AND service.status<>'Final Inspection' AND service.service_center=:service_center ORDER BY service.registration_no";
		$stmt = $this->conn->prepare( $query );
		$stmt->bindParam(":service_center", $this->service_center);
		$stmt->execute();
		return $stmt;
	}

	function autocompleteRegistrationNo(){
		$condition = "";
		
		if($this->registration_no){
			$condition .= " AND (registration_no LIKE  :registration_no '%' or registration_no LIKE '%' :registration_no '%' or registration_no Like '%' :registration_no )";
		} 

		$query = "SELECT * FROM " . $this->table_name . " WHERE service_center=:service_center " . $condition . " ORDER BY registration_no";
		$stmt = $this->conn->prepare($query);
		if($this->registration_no) $stmt->bindParam(":registration_no", $this->registration_no);
		$stmt->bindParam(":service_center", $this->service_center);
		$stmt->execute();
		return $stmt;
	}

	function autocompletePlateNo(){
		$condition = "";
		
		if($this->plate_no){ 
			$condition .= " AND (plate_no LIKE  :plate_no '%' or plate_no LIKE '%' :plate_no '%' or plate_no Like '%' :plate_no )";
		} 

		$query = "SELECT * FROM " . $this->table_name . " WHERE service_center=:service_center " . $condition . " GROUP BY plate_no ORDER BY plate_no";
		$stmt = $this->conn->prepare($query);
		if($this->plate_no) $stmt->bindParam(":plate_no", $this->plate_no);
		$stmt->bindParam(":service_center", $this->service_center);
		$stmt->execute();
		return $stmt;
	}

	function autocompleteCustomer(){
		$condition = "";
		
		if($this->customer_name){ 
			$condition .= " AND (service_customer.name LIKE  :customer_name '%' or service_customer.name LIKE '%' :customer_name '%' or service_customer.name Like '%' :customer_name )";
		}

		$query = "SELECT * FROM " . $this->table_name . " LEFT JOIN service_customer ON service.service_customer_id=service_customer.id WHERE service.service_center=:service_center" . $condition . " GROUP BY service_customer.id ORDER BY service_customer.name";
		$stmt = $this->conn->prepare($query);
		if($this->customer_name) $stmt->bindParam(":customer_name", $this->customer_name);
		$stmt->bindParam(":service_center", $this->service_center);
		$stmt->execute();
		return $stmt;
	}

	function search(){
		$condition = "";
		
		if($this->date){
			if($condition!=""){
				$condition .= " AND ";
			}
			$condition .= " service.car_receive_date=:date ";
		}

		if($this->registration_no){
			if($condition!=""){
				$condition .= " AND ";
			}
			$condition .= " (service.registration_no LIKE  :registration_no '%' or service.registration_no LIKE '%' :registration_no '%' or service.registration_no Like '%' :registration_no ) ";
		} 

		if($this->plate_no){
			if($condition!=""){
				$condition .= " AND ";
			}
			$condition .= " (service.plate_no LIKE  :plate_no '%' or service.plate_no LIKE '%' :plate_no '%' or service.plate_no Like '%' :plate_no ) ";
		}

		if($this->customer_name){
			if($condition!=""){
				$condition .= " AND ";
			}
			$condition .= " (service_customer.name LIKE  :customer_name '%' or service_customer.name LIKE '%' :customer_name '%' or service_customer.name Like '%' :customer_name ) ";
		}

		if($this->customer_phone){
			if($condition!=""){
				$condition .= " AND ";
			}
			$condition .= " (service_customer.phone_no LIKE  :customer_phone '%' or service_customer.phone_no LIKE '%' :customer_phone '%' or service_customer.phone_no Like '%' :customer_phone ) ";
		}

		if($condition!=""){
			$condition = " WHERE " . $condition;
		}

		$query = "SELECT service.*, IFNULL(service_customer.name, '') AS customer_name, IFNULL(service_customer.phone_no, '') AS customer_phone, total_services FROM " . $this->table_name . " LEFT JOIN service_customer ON service.service_customer_id=service_customer.id LEFT JOIN (SELECT service_id, COUNT(DISTINCT(item_code)) AS total_services FROM service_detail_service_item GROUP BY service_id) AS sdsi ON service.id=sdsi.service_id " . $condition . " ORDER BY service.registration_no";
		$stmt = $this->conn->prepare($query);

		if($this->date) $stmt->bindParam(":date", $this->date);
		if($this->registration_no) $stmt->bindParam(":registration_no", $this->registration_no);
		if($this->plate_no) $stmt->bindParam(":plate_no", $this->plate_no);
		if($this->customer_name) $stmt->bindParam(":customer_name", $this->customer_name);
		if($this->customer_phone) $stmt->bindParam(":customer_phone", $this->customer_phone);

		$stmt->execute();
		return $stmt;
	}

	function updateComplain(){
		$query = "UPDATE " . $this->table_name . " SET complain=:complain, complain_date_time=:complain_date_time WHERE id=:id";
		$stmt = $this->conn->prepare($query);

		$stmt->bindParam(":id", $this->id); 
		$stmt->bindParam(":complain", $this->complain);
		$stmt->bindParam(":complain_date_time", $this->complain_date_time);
		
		if($stmt->execute()){
			return true;
		}
		return false;
	}

	function updateByPayment(){
		$query = "UPDATE " . $this->table_name . " SET car_return_date=:car_return_date, car_return_time=:car_return_time, `status`=:status WHERE id=:id";
		$stmt = $this->conn->prepare($query);

		$stmt->bindParam(":id", $this->id); 
		$stmt->bindParam(":car_return_date", $this->car_return_date);
		$stmt->bindParam(":car_return_time", $this->car_return_time);
		$stmt->bindParam(":status", $this->status);
		
		if($stmt->execute()){
			return true;
		}
		return false;
	}
}
?>