<?php
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
    header("Access-Control-Allow-Methods: POST");
    header("Access-Control-Max-Age: 3600");
    header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

    include_once '../../config/database.php';
    include_once '../../objects/staff.php';

    $database = new Database();
    $db = $database->getConnection();
     
    $staff = new Staff($db);
    $data = json_decode(file_get_contents("php://input"));

    $staff->card_no = $data->card_no;   
    $staff->name = $data->name;
    $staff->department = $data->department;
    $staff->position = $data->position;
    $staff->nrc_no = $data->nrc_no;

    $stmt = $staff->search();
    $num = $stmt->rowCount();

    $arr = array();
    $arr["records"] = array();

    if($num>0){
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
            extract($row);
            $detail = array(
                "id" => (int)$id,
                "join_date" => ($join_date)?$join_date:"",
                "card_no" => ($card_no)?$card_no:"",
                "name" => ($name)?$name:"",
    			"nrc_no" => ($nrc_no)?$nrc_no:"",            
                "dob" => ($dob)?$dob:"",
                "nrc_no" => ($nrc_no)?$nrc_no:"",	
                "department" => ($department)?$department:"",
                "position" => ($position)?$position:"",
                "phone" => ($phone)?$phone:""
            );  
            array_push($arr["records"], $detail);
        }
    }
    echo json_encode($arr);
?>