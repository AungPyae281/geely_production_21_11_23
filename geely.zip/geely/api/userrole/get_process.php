<?php
	session_start();
	$rolename = $_SESSION['userrole'];
	// required headers 
	header("Access-Control-Allow-Origin: *");
	header("Content-Type: application/json; charset=UTF-8");
	header("Access-Control-Allow-Methods: POST");
	header("Access-Control-Max-Age: 3600");
	header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

	// include database and object files
	include_once '../config/database.php';
	include_once '../objects/user_role.php';
	 
	// instantiate database
	$database = new Database();
	$db = $database->getConnection();
	 
	// initialize object
	$userrole = new UserRole($db); 
	$data = json_decode(file_get_contents("php://input"));

	$arr = array();
	$arr["records"] = array();
	
	if($_SESSION['user']!=""){
		if(!empty($data->role_name)){
			$userrole->role_name = $data->role_name;
		}else{
			$userrole->role_name = $rolename;
		}

		$stmt = $userrole->getProcess();
		$num = $stmt->rowCount();

		if($num>0){
			while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
				extract($row);
				$r = array(
					"id" => (int)$id,
					"dashboard" => $dashboard,
					"role_name" => $role_name,
					"process" => $process,
					"create" => $create,
					"read" => $read,
					"update" => $update,
					"delete" => $delete,
					"export" => $export,
					"print" => $print
				);
				array_push($arr["records"], $r);
			}
		}
	}
	echo json_encode($arr);
?>