<?php 
	header("Access-Control-Allow-Origin: *");
	header("Content-Type: application/json; charset=UTF-8");
	header("Access-Control-Allow-Methods: POST");
	header("Access-Control-Max-Age: 3600");
	header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

	include_once '../../config/database.php';
	include_once '../../objects/customer.php';
	 
	$database = new Database();
	$db = $database->getConnection();

	$customer = new Customer($db);
	$data = json_decode(file_get_contents("php://input"));

	$customer->id = $data->id;
	$customer->getOneRow();	

	$arr = array(
	    "id" =>  $customer->id,
	    "registration_no" =>  $customer->registration_no,
		"staff_id" => $customer->staff_id,
		"staff_name" => $customer->staff_name,
		"sales_center" => $customer->sales_center,
		"gender" => $customer->gender,
		"name" => $customer->name,
		"nrc_no" => $customer->nrc_no,
		"mobile_no" => $customer->mobile_no,
		"dob" => $customer->dob,
		"vehicle_of_interest" => $customer->vehicle_of_interest,
		"btc_am" => $customer->btc_am,
		"btc_pm" => $customer->btc_pm,	
		"soi_phone_inout" => $customer->soi_phone_inout,
		"soi_facebook" => $customer->soi_facebook,
		"soi_advert" => $customer->soi_advert,
		"soi_road_show" => $customer->soi_road_show,
		"soi_television" => $customer->soi_television,
		"soi_website" => $customer->soi_website,
		"soi_existing_customer" => $customer->soi_existing_customer,
		"soi_review" => $customer->soi_review,
		"soi_walkin" => $customer->soi_walkin,
		"soi_car_magazine" => $customer->soi_car_magazine,
		"soi_broker" => $customer->soi_broker,		
		"soi_other" => $customer->soi_other,	
		"soi_other_remark" => $customer->soi_other_remark,	
		"sales_status" => $customer->sales_status,
		"needs_requirements" => $customer->needs_requirements,
		"estimate_delivery_date" => $customer->estimate_delivery_date,
		"close_date" => $customer->close_date,
		"case_close" => $customer->case_close,
		"alternative_telephone_no" => $customer->alternative_telephone_no,
		"email" => $customer->email,
		"home_phone" => $customer->home_phone,
		"pcm_mobile" => $customer->pcm_mobile,
		"pcm_email" => $customer->pcm_email,
		"pcm_other" => $customer->pcm_other,
		"business" => $customer->business,
		"township" => $customer->township,
		"address" => $customer->address,
		"vip" => $customer->vip,
		"customer_history" => $customer->customer_history,
		"cv_brand" => $customer->cv_brand,
		"cv_model_year" => $customer->cv_model_year,
		"cv_rtad_no" => $customer->cv_rtad_no,
		"cv_mileage" => $customer->cv_mileage,
		"cv_vehicle_as_commercial" => $customer->cv_vehicle_as_commercial,
		"cvd_outstanding_payments" => $customer->cvd_outstanding_payments,
		"cv_private" => $customer->cv_private,
		"cv_business" => $customer->cv_business,
		"cv_off_road" => $customer->cv_off_road,
		"cv_travelling" => $customer->cv_travelling,
		"cv_dislike_about_car" => $customer->cv_dislike_about_car,
		"cv_would_you_like_to_have_that_not_already_have" => $customer->cv_would_you_like_to_have_that_not_already_have,
		"cv_annual_usage" => $customer->cv_annual_usage,
		"cv_who_will_be_using_vehicle" => $customer->cv_who_will_be_using_vehicle,
		"lifestyle_family_members" => $customer->lifestyle_family_members,
		"lifestyle_dream_brand" => $customer->lifestyle_dream_brand,
		"lifestyle_dream_car" => $customer->lifestyle_dream_car,
		"lifestyle_interested_model" => $customer->lifestyle_interested_model,
		"lifestyle_hobbies_interests" => $customer->lifestyle_hobbies_interests,
		"lifestyle_expectations_of_new_vehicle" => $customer->lifestyle_expectations_of_new_vehicle,
		"entry_by" => $customer->entry_by,
		"entry_date_time" => $customer->entry_date_time
	);
	echo json_encode($arr);
?>