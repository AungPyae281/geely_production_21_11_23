<?php 
	header("Access-Control-Allow-Origin: *");
	header("Content-Type: application/json; charset=UTF-8");
	header("Access-Control-Allow-Methods: POST");
	header("Access-Control-Max-Age: 3600");
	header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

	include_once '../../config/database.php';
	include_once '../../objects/customer.php';	

	date_default_timezone_set('Asia/Rangoon'); 
	session_start();

	$database = new Database();
	$db = $database->getConnection();
	 
	$customer = new Customer($db);
	$data = json_decode(file_get_contents("php://input"));

	$customer->id = $data->id;
	$customer->sales_center = $data->sales_center;

	$customer->gender = $data->gender;
	$customer->name = $data->name;
	$customer->mobile_no = str_replace("+95", "0", str_replace("-", "", str_replace("/", "", $data->mobile_no)));
	$customer->dob = $data->dob;

	$customer->btc_am = $data->btc_am;
	$customer->btc_pm = $data->btc_pm;

	$customer->soi_phone_inout = $data->soi_phone_inout;
	$customer->soi_facebook = $data->soi_facebook;
	$customer->soi_advert = $data->soi_advert;
	$customer->soi_road_show = $data->soi_road_show;
	$customer->soi_television = $data->soi_television;
	$customer->soi_website = $data->soi_website;
	$customer->soi_existing_customer = $data->soi_existing_customer;
	$customer->soi_review = $data->soi_review;
	$customer->soi_walkin = $data->soi_walkin;
	$customer->soi_car_magazine = $data->soi_car_magazine;
	$customer->soi_broker = $data->soi_broker;
	$customer->soi_other = $data->soi_other;
	$customer->soi_other_remark = $data->soi_other_remark;

	$customer->vehicle_of_interest = $data->vehicle_of_interest;

	$customer->sales_status = $data->sales_status;

	$customer->needs_requirements = $data->needs_requirements;
	$customer->estimate_delivery_date = $data->estimate_delivery_date;
	$customer->close_date = $data->close_date;
	$customer->alternative_telephone_no = $data->alternative_telephone_no;
	$customer->email = $data->email;
	$customer->home_phone = $data->home_phone;

	$customer->pcm_mobile = $data->pcm_mobile;
	$customer->pcm_email = $data->pcm_email;
	$customer->pcm_other = $data->pcm_other;

	$customer->business = $data->business;
	$customer->township = $data->township;
	$customer->address = $data->address;
	$customer->vip = $data->vip;
	$customer->customer_history = $data->customer_history;

	$customer->cv_brand = $data->cv_brand;
	$customer->cv_model_year = $data->cv_model_year;
	$customer->cv_rtad_no = $data->cv_rtad_no;
	$customer->cv_mileage = $data->cv_mileage;
	$customer->cv_vehicle_as_commercial = $data->cv_vehicle_as_commercial;
	$customer->cvd_outstanding_payments = $data->cvd_outstanding_payments;
	$customer->cv_private = $data->cv_private;
	$customer->cv_business = $data->cv_business;
	$customer->cv_off_road = $data->cv_off_road;
	$customer->cv_travelling = $data->cv_travelling;
	$customer->cv_dislike_about_car = $data->cv_dislike_about_car;
	$customer->cv_would_you_like_to_have_that_not_already_have = $data->cv_would_you_like_to_have_that_not_already_have;
	$customer->cv_annual_usage = $data->cv_annual_usage;
	$customer->cv_who_will_be_using_vehicle = $data->cv_who_will_be_using_vehicle;

	$customer->lifestyle_family_members = $data->lifestyle_family_members;
	$customer->lifestyle_dream_brand = $data->lifestyle_dream_brand;
	$customer->lifestyle_dream_car = $data->lifestyle_dream_car;
	$customer->lifestyle_interested_model = $data->lifestyle_interested_model;
	$customer->lifestyle_hobbies_interests = $data->lifestyle_hobbies_interests;
	$customer->lifestyle_expectations_of_new_vehicle = $data->lifestyle_expectations_of_new_vehicle;

	if($customer->update()){
		$arr = array(
			"message" => "updated"
		);
	}else{
		$arr = array(
			"message" => "error"
		);
	}
	echo json_encode($arr);
?>