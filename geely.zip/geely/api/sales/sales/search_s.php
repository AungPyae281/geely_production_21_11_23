<?php 
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
    header("Access-Control-Allow-Methods: POST");
    header("Access-Control-Max-Age: 3600");
    header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

    include_once '../../config/database.php';
    include_once '../../objects/sales.php'; 

    $database = new Database();
    $db = $database->getConnection();

    $sales = new Sales($db);
    $data = json_decode(file_get_contents("php://input")); 

    $sales->df = $data->df;
    $sales->dt = $data->dt;
    $sales->oc_no = $data->oc_no;
    $sales->customer_name = $data->customer_name;
    $sales->customer_phone = $data->customer_phone;
    $sales->broker_name = $data->broker_name;
    $sales->sales_center = $data->sales_center;
    $sales->staff_name = $data->staff_name;

    $stmt = $sales->search_S();
    $num = $stmt->rowCount();

    $arr = array();
    $arr["records"] = array();

    if($num>0){
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
            extract($row); 
            $detail = array(
                "date" => $date,
                "oc_no" => $oc_no,
                "sales_center" => $sales_center,
                "customer_name" => $customer_name,
                "customer_phone" => $customer_phone,
                "broker_name" => $broker_name,
                "staff_name" => $staff_name,
                "vin_no" => $vin_no,
                "payment_type" => $payment_type,
                "deposit" => number_format($deposit),
                "rrp" => number_format($selling_price),
                "payment" => number_format($total_payment),
                "status" => $status
            );  
            array_push($arr["records"], $detail);
        }
    }
    echo json_encode($arr);
?>