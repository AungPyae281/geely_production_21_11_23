<?php 
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
    header("Access-Control-Allow-Methods: POST");
    header("Access-Control-Max-Age: 3600");
    header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

    include_once '../../config/database.php';
    include_once '../../objects/order.php';
    include_once '../../objects/approval.php';
    include_once '../../../config/_globle.php';
     
    $database = new Database();
    $db = $database->getConnection();

    $order = new Order($db);
    $approval = new Approval($db);
    $data = json_decode(file_get_contents("php://input"));

    $order->oc_no = $data->oc_no; 

    $order->getOneOrderConfirm();

    $approval->main_id = $data->oc_no;
    $approval->getMax2Approver();

    $stmt = $approval->getMax2Approver();
    $num = $stmt->rowCount();

    $approvers = array();
    $i = 0;

    if($num>0){
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
            extract($row);  
            $detail = array(
                "order" => ++$i,
                "position" => $position,
                "signature" => (($signature)?$app_url . "api/hr/staff/signature/" . $signature:"")
            );  
            array_push($approvers, $detail);
        }
    }

    $arr = array(
        "id" => $order->id,
        "date" =>  $order->date,
        "oc_no" => $order->oc_no,

        "customer_id" => $order->customer_id,
        "customer_name" => $order->customer_name,
        "nrc_no" => $order->nrc_no,
        "mobile_no" => $order->mobile_no,
        "email" => $order->email,
        "address" => $order->address,
        "cust_sig" => ($order->dc_due_date_time)?($app_url . "api/sales/sales/upload/" . $order->oc_no . "/signature.png"):"",

        "broker_id" => $order->broker_id,
        "broker_name" => $order->broker_name,

        "brand" => $order->brand,   
        "model" => $order->model,
        "grade" => $order->grade,   
        "model_year" => $order->model_year,  
        "vin_no" => $order->vin_no,
        "engine_no" => $order->engine_no,     
        "exterior_color" => $order->exterior_color,
        "interior_color" => $order->interior_color,

        "sales_center" => $order->sales_center,     
        "sales_type" => $order->sales_type,

        "vehicle_price" => number_format($order->vehicle_price),
        "commercial_tax" => number_format($order->commercial_tax),
        "rtad_tax" => number_format($order->rtad_tax),
        "promotion_code" => $order->promotion_code,
        "promotion_discount" => number_format($order->promotion_discount),
        "selling_price" => number_format($order->selling_price),
        "deposit" => number_format($order->deposit), 

        "payment_type" =>  $order->payment_type,
        "bank" =>  $order->bank,    
        "payment_percent" => $order->payment_percent,
        "payment_term" => $order->payment_term,

        "same_as_buyer" => (int)$order->same_as_buyer,
        "rtad_name" => $order->rtad_name,
        "rtad_nrc_no" => $order->rtad_nrc_no,
        "rtad_mobile_no" => $order->rtad_mobile_no,
        "rtad_township" => $order->rtad_township,

        "customer_type" => $order->customer_type,
        "company_name" => $order->company_name,
        "company_register_no" => $order->company_register_no,

        "staff_id" => $order->staff_id,
        "staff_sig" => $app_url . (($order->staff_sig)?("api/hr/staff/signature/" . $order->staff_sig):("img/signature_dummy.png")),
        "staff_name" => $order->staff_name,

        "retail_price" => number_format($order->vehicle_price + $order->commercial_tax),
        "total_price_c" => number_format($order->vehicle_price + $order->commercial_tax + $order->rtad_tax),

        "approvers" => $approvers
    );

    echo json_encode($arr);
?>