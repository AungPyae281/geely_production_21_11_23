<?php
	header("Access-Control-Allow-Origin: *");
	header("Content-Type: application/json; charset=UTF-8");
	 
	include_once '../config/database.php';
	include_once '../objects/user.php';
	 
	$database = new Database();
	$db = $database->getConnection();
	 
	$user = new User($db);

	$stmt = $user->getUsers();
	$num = $stmt->rowCount();

	$arr = array();
	$arr["records"] = array();

	if($num>0){
		while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
			extract($row);
			$detail = array(
				"id" => (int)$id,
				"staff_id" => $staff_id,
				"staff_name" => $staff_name,
				"username" => $username,
				"userrole" => $userrole,
				"dashboard" => $dashboard,
				"password" => $password,
				"profilepicture" => (($profilepicture)?explode("./", $profilepicture)[1]:"")
			);
			array_push($arr["records"], $detail);
		}	
	}
	echo json_encode($arr);
?>