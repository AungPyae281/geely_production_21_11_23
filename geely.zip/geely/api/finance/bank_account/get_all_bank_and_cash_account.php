<?php 
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
    header("Access-Control-Allow-Methods: POST");
    header("Access-Control-Max-Age: 3600");
    header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

    include_once '../../config/database.php';
    include_once '../../objects/bank_account.php'; 

    $database = new Database();
    $db = $database->getConnection();

    $bank_account = new BankAccount($db);
    $data = json_decode(file_get_contents("php://input")); 

    $stmt = $bank_account->getAllBankAndCashAccount();
    $num = $stmt->rowCount();

    $arr = array();
    $arr["records"] = array();

    if($num>0){
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
            extract($row); 
            $detail = array(
                "gl_code" => $gl_code,
                "category" => $category,
                "name" => $name,
                "balance" => (float)ROUND($balance, 2)
            );  
            array_push($arr["records"], $detail);
        }
    }
    echo json_encode($arr);
?>