<?php 
	header("Access-Control-Allow-Origin: *");
	header("Content-Type: application/json; charset=UTF-8");
	header("Access-Control-Allow-Methods: POST");
	  
	include_once '../../config/database.php';
	include_once '../../objects/gl_account.php';
	  
	$database = new Database();
	$db = $database->getConnection();
	  
	$gl_account = new GLAccount($db);
	$data = json_decode(file_get_contents("php://input"));

	$gl_account->type = (!empty($data->type))?$data->type:"";
	$gl_account->category = (!empty($data->category))?$data->category:"";
	
	$stmt = $gl_account->getAllRows();
	$num = $stmt->rowCount();

	$arr = array();
	$arr["records"] = array();

	if($num>0){
		while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
			extract($row);
			$detail = array(
				"id" => (int)$id,
				"type" => $type,
				"category" => $category,
				"gl_code" => $gl_code,
				"name" => $name,
				"min_amount" => (int)$min_amount,
				"max_amount" => (int)$max_amount
			);
			array_push($arr["records"], $detail);
		}
	}
	echo json_encode($arr);
?>