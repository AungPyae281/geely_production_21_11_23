<?php 
	header("Access-Control-Allow-Origin: *");
	header("Content-Type: application/json; charset=UTF-8");
	header("Access-Control-Allow-Methods: POST");
	  
	include_once '../../config/database.php';
	include_once '../../objects/gl_account.php';
	date_default_timezone_set('Asia/Rangoon');
	$database = new Database();
	$db = $database->getConnection();
	  
	$gl_account = new GLAccount($db);
	$data = json_decode(file_get_contents("php://input"));

	$gl_account->date = date("Y-m-d");
	
	$stmt = $gl_account->getAdvanceBalance();
	$num = $stmt->rowCount();

	$arr = array();
	$arr["records"] = array();

	if($num>0){
		while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
			extract($row);
			$detail = array(
				"gl_code" => $gl_code,
				"name" => $name,
				"balance" => round((float)$balance,2)
			);
			array_push($arr["records"], $detail);
		}
	}
	echo json_encode($arr);
?>