<?php 
	header("Access-Control-Allow-Origin: *");
	header("Content-Type: application/json; charset=UTF-8");
    header("Access-Control-Allow-Methods: POST");
	  
	include_once '../../config/database.php';
	include_once '../../objects/account_transfer.php';
	  
	$database = new Database();
	$db = $database->getConnection();
	  
	$account_transfer = new AccountTransfer($db);
	$data = json_decode(file_get_contents("php://input"));

	$account_transfer->date = (!empty($data->date))?$data->date:"";
	
	$stmt = $account_transfer->getAllRows();
	$num = $stmt->rowCount();

	$arr = array();
	$arr["records"] = array();

	if($num>0){ 
		while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
			extract($row);
			$detail = array(
				"id" => (int)$id,
				"date" => $date,
				"account_from" => $gl_code_from . ' (' . $name_from . ')',
				"account_to" => $gl_code_to . ' (' . $name_to . ')',
				"amount" => ROUND((float)$amount, 2),
				"transfer_by" => $transfer_by, 
				"upload_receipt" => $upload_receipt
			);
			array_push($arr["records"], $detail);
		} 
	} 
	echo json_encode($arr);
?>