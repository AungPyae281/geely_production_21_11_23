<?php
	header("Access-Control-Allow-Origin: *");
	header("Content-Type: application/json; charset=UTF-8");
	header("Access-Control-Allow-Methods: POST");
	header("Access-Control-Max-Age: 3600");
	header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

	include_once '../../config/database.php';
	include_once '../../objects/car_stock.php';
	include_once '../../objects/sales.php';
	
	session_start();
	date_default_timezone_set('Asia/Rangoon');

	$database = new Database();
	$db = $database->getConnection();
	 
	$car_stock = new CarStock($db);
	$sales = new Sales($db);
	$data = json_decode(file_get_contents("php://input"));

	foreach ($data->car_lists as $carlist) {
		$car_stock->car_list_id = $carlist->car_list_id;
		$car_stock->production_order_id = $carlist->production_order_id;
		$car_stock->brand = $carlist->brand;
		$car_stock->model = $carlist->model;
		$car_stock->model_year = $carlist->model_year;
		$car_stock->grade = $carlist->grade;
		$car_stock->engine_power = $carlist->engine_power;
		$car_stock->interior_color = $carlist->interior_color;
		$car_stock->exterior_color = $carlist->exterior_color;
		$car_stock->vin_no = $carlist->vin_no;
		$car_stock->engine_no = $carlist->engine_no;
		$car_stock->oc_no = $carlist->oc_no;
		$car_stock->sales_id = $carlist->sales_id;

		if($carlist->oc_no!=""){
			$sales->vin_no = $carlist->vin_no;
			$sales->engine_no = $carlist->engine_no;
			$sales->oc_no = $carlist->oc_no;

			if(!$sales->updateVNAssign()){
				$arr = array(
					"message" => "errorSalesUpdate"
				);
				echo json_encode($arr);
				die();
			}
		}
		
		$car_stock->stock_status = "Factory";
		$car_stock->entry_by = $_SESSION['user'];
		$car_stock->entry_date_time = date("Y-m-d H:i:s");

		if(!$car_stock->create()){
			$arr = array(
				"message" => "error"
			);
			echo json_encode($arr);
			die();
		}
	}
	$arr = array(
		"message" => "created"
	);
	echo json_encode($arr);
?>