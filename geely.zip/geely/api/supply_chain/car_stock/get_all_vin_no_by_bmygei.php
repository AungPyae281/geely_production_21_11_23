<?php 
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
    header("Access-Control-Max-Age: 3600");
    header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

    include_once '../../config/database.php';
    include_once '../../objects/car_list.php';
    include_once '../../objects/car_stock.php';

    $database = new Database();
    $db = $database->getConnection();
     
    $car_list = new CarList($db);
    $car_stock = new CarStock($db);
    $data = json_decode(file_get_contents("php://input"));

    $car_stock->status = $data->status;
    $car_stock->brand = $data->brand;
    $car_stock->model = $data->model;
    $car_stock->model_year = $data->model_year;
    $car_stock->grade = $data->grade;
    $car_stock->exterior_color = $data->exterior_color;
    $car_stock->interior_color = $data->interior_color;

    $car_list->brand = $data->brand;
    $car_list->model = $data->model;
    $car_list->model_year = $data->model_year;
    $car_list->grade = $data->grade;
    $car_list->exterior_color = $data->exterior_color;
    $car_list->interior_color = $data->interior_color;

    $car_list_id = $car_list->getCarListID();

    $interior_photo = "";
    $exterior_photo = "";

    $dir = "../../../upload/server/php/files/interior/" . $car_list_id . "/";

    if(file_exists($dir)){
        $dh  = opendir($dir);
        while (false !== ($filename = readdir($dh))) {
            $filesIn[] = $filename;
        }
        rsort($filesIn);
        foreach($filesIn as $fileIn) {
            if ($fileIn != "." && $fileIn != ".." && $fileIn != "design" && $fileIn != "thumbnail") {
                $filewithoutExt = preg_replace('/\\.[^.\\s]{3,4}$/', '', $fileIn);
                $interior_photo = $fileIn;
                break;
            }
        }
    }

    $dir = "../../../upload/server/php/files/exterior/" . $car_list_id . "/";

    if(file_exists($dir)){
        $dh  = opendir($dir);
        while (false !== ($filename = readdir($dh))) {
            $filesEx[] = $filename;
        }
        rsort($filesEx);
        foreach($filesEx as $fileEx) {
            if ($fileEx != "." && $fileEx != ".." && $fileEx != "design" && $fileEx != "thumbnail") {
                $filewithoutExt = preg_replace('/\\.[^.\\s]{3,4}$/', '', $fileEx);
                $exterior_photo = $fileEx;
                break;
            }
        }
    }

    $stmt = $car_stock->getAllVinNoByBMYGEI();
    $num = $stmt->rowCount();

    $cl = array();

    if($num>0){
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
            extract($row); 
            $detail = array(
                "vin_no" => $vin_no,
                "engine_no" => $engine_no
            );  
            array_push($cl, $detail);
        }
    }

    $arr = array(
        "car_list" => $cl,
        "car_list_id" => $car_list_id,
        "interior_photo" => $interior_photo,
        "exterior_photo" => $exterior_photo
    );
    echo json_encode($arr);
?>