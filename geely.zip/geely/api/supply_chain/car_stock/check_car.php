<?php 
	header("Access-Control-Allow-Origin: *");
	header("Content-Type: application/json; charset=UTF-8");
	header("Access-Control-Allow-Methods: POST");
	header("Access-Control-Max-Age: 3600");
	header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
	  
	include_once '../../config/database.php';
	include_once '../../objects/car_stock.php';
	  
	$database = new Database();
	$db = $database->getConnection();
	
	$car_stock = new CarStock($db);
	$data = json_decode(file_get_contents("php://input"));  

	if($car_stock->checkCar($data->vin_no, $data->engine_no)){
		$msg_arr = array(
			"message" => "duplicate",
			"vin_no" => $car_stock->vin_no,
			"engine_no" => $car_stock->engine_no
		);
	}else{
		$msg_arr = array(
			"message" => "not exist"
		);
	}
	echo json_encode($msg_arr);
?>