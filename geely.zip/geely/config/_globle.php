<?php
	$app_name = "Geely";
	$app_url = "http://premierauto.pal.com.mm/geely/"; 
	$current_url = $_SERVER['REQUEST_SCHEME'] . '://' . $_SERVER['HTTP_HOST'] .parse_url($_SERVER["REQUEST_URI"], PHP_URL_PATH);
?>
